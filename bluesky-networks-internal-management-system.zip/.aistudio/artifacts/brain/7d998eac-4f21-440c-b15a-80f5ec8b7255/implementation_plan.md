# Bluesky Networks Internal Management System

A private, enterprise-grade digital media operating system for Bluesky Networks, tailored for Founder & CEO Manuja Rathnayake, managers Danuji Rathnayake and Imasha Welivita, and authorized production specialists. The platform centralizes video pipeline workflows, strict role-based access, content scheduling across YouTube and Facebook, performance analytics, internal communications, and executive governance within an Apple Cupertino-inspired glassmorphic aesthetic.

## User Review & Critical Decisions

> [!IMPORTANT]
> The architectural and design foundations confirmed during clarification have been baked into this implementation plan.

- **Confirmed Decision 1 (Storage & Persistence)**: Full-Stack Express with local persistent storage (`/data/bluesky-store.json`) and rich realistic seed data for Bluesky Networks (channels, projects, team members, publishing calendar, and audit trails).
- **Confirmed Decision 2 (Authentication & Onboarding)**: Guided first-run setup wizard and instant role-switch simulator for testing CEO, Manager, and Team Member experiences, paired with secure session token management and zero plain-text password exposure.
- **Confirmed Decision 3 (Visual Style & Mood)**: Apple macOS / iOS Cupertino Clean with subtle glassmorphism (`backdrop-blur-md`, soft specular highlights, refined hairline borders) and seamless Light/Dark mode toggling.

---

## 1. Overview & Core Concept

- **What It Does**: Bluesky Networks operates high-volume video publishing across YouTube and Facebook. This internal operating system manages the complete media lifecycle: video prompt authoring, private project assignment, stage-by-stage pipeline tracking (Research → Scripting → Generation → Editing → Review → Export → Published), team member performance scoring with audit trails, historical publishing records, future content calendars, private 1-on-1 messaging, and CEO-level account change approvals.
- **Target Audience / Persona**:
  - **Founder & CEO (Manuja Rathnayake)**: Full visibility into all projects, employee performance ranking, publishing schedule, company revenue/output analytics, system settings, user management, and change request approvals.
  - **Managers (Danuji Rathnayake, Imasha Welivita)**: Departmental oversight, project review, revision requests, team progress tracking, and media asset management.
  - **Team Members (Editors, Scriptwriters, Prompt Engineers)**: Focused, distraction-free "Today's Focus" dashboard showing strictly their own assigned projects, deadlines, stage updates, performance points, and private direct messages.
- **Key Value**: Guarantees strict confidentiality (team members cannot view or search unassigned projects), eliminates production bottlenecks with real-time stage updates, and provides the CEO with complete operational transparency.

---

## 2. User Experience & Visual Design

### Key User Flows
1. **CEO Command Flow**: The CEO logs in (or switches to CEO mode), inspects the top-level KPI strip (Active Projects, Completed Today, Overdue, Published This Week, Average Score), reviews the live activity timeline, drills into the Project Matrix or Team Member dossiers, assigns a new video project with specific channel targets, and reviews pending change requests.
2. **Team Member Execution Flow**: An editor logs in, lands on "Today's Focus" highlighting their highest-priority task, updates their stage (e.g., from *Script Writing* to *Video Generation*), attaches submission links, and marks the task as *Waiting for Review*.
3. **Manager Review Flow**: A manager opens the submission review modal, inspects video links and prompt fidelity, either approves with automatic point rewards (+10 on-time, +5 zero-revision bonus) or issues a revision note returning the project to *Revision Required*.
4. **Content Operations Flow**: The media coordinator navigates to *Media Assets* (managing YouTube channels and Facebook pages), schedules upcoming releases on the multi-view *Content Planner* (Day/Week/Month), and records published metrics in the *Published Video Tracker*.
5. **Private Communication & Approvals Flow**: Staff send direct messages with read receipts; sensitive profile changes trigger a CEO approval notification with approve/deny actions logged to an immutable audit trail.

### Visual Identity & Theme
- **Aesthetic Direction**: Apple Cupertino OS — refined, luminous, purposeful. Elevated glass cards with hairline borders (`border-black/[0.08]` in light mode, `border-white/[0.12]` in dark mode), soft directional shadows, and smooth 150ms transitions.
- **Color Palette & Mood**:
  - Neutral Canvas: Light mode crisp porcelain (`#F8FAFC` / `#FFFFFF`), Dark mode deep obsidian slate (`#0B0F19` / `#111827`).
  - Structural Surfaces: Translucent elevated surfaces with `backdrop-blur-xl` and `bg-white/80` or `bg-slate-900/80`.
  - Brand Accent: Bluesky Royal Azure (`#0066FF` / `#2563EB`) evoking clean modern utility, balanced with Emerald (`#10B981`) for on-time/approved, Amber (`#F59E0B`) for reviews, and Crimson (`#EF4444`) for overdue alerts.
- **Typography & Hierarchy**:
  - Display Font: `Plus Jakarta Sans` for titles, navigation items, and section headlines.
  - Body Prose: `Plus Jakarta Sans` at 14px–15px for crisp scanning.
  - Telemetry & Metrics: Monospace tabular numbers (`tabular-nums`, `font-mono`) for dates, timestamps, point tallies, and KPI metrics.
- **Component Styling & Layout**:
  - Full 1440px desktop container with responsive collapsible glass sidebar (260px).
  - Single-elevation cards with subtle borders; zero card-in-card clutter.
  - Zero-pill discipline: quiet inline metadata separated by `·` or `/`; segmented interactive pill tabs only for active filtering controls.
- **Interactive Feedback & Motion**:
  - Animated tab transitions and slide-over drawers using `motion/react`.
  - Responsive modals with keyboard escape support.
  - Real-time notification banners and live activity timeline badges.

---

## 3. Key Product Decisions & Trade-Offs

- **Decision 1: Persistent Full-Stack Architecture via Vite + Express**:
  - *Chosen Approach*: Embed an Express API router inside the Vite development server on port 3000, backed by a persistent file-backed JSON database store (`server/data/store.json`).
  - *Why*: Provides real REST endpoints (`/api/auth`, `/api/projects`, `/api/users`, `/api/messages`, `/api/calendar`, `/api/audit`), realistic server-side authorization enforcement, and persistent data across page refreshes without requiring external database setups.
  - *Alternatives Considered*: Pure browser `localStorage` lacks server-authoritative privacy checks; Cloud SQL was not requested.
- **Decision 2: Strict Server-Side Access Control (Zero Client-Side Leaks)**:
  - *Chosen Approach*: Project and message endpoints enforce session identity. Team member queries filter out unassigned projects on the server before transmitting payloads to the client.
  - *Why*: Master prompt Section 6 strictly mandates that team members cannot discover project titles, prompts, or attachments of other employees even by tampering with API requests or browser state.
- **Decision 3: Demo Quick-Switch & Guided First-Run Wizard**:
  - *Chosen Approach*: Provide a clean floating Apple-style "Session Switcher" bar allowing instant toggling between Manuja (CEO), Danuji (Manager), and Nimna/Kaveen (Team Members), while also offering an authentic credential-based login screen with lockout protection.
  - *Why*: Allows instant inspection of how views and privacy rules differ across roles without tedious re-typing, while preserving production-grade auth logic.
- **Decision 4: Modular Tabbed Navigation for CEO vs. Streamlined View for Team**:
  - *Chosen Approach*: CEO sees all 12 operational views (Dashboard, Projects, Team, Messages, Calendar, Published, Media Assets, Performance, Insights, Notifications, Admin, Settings). Team members only see their 6 authorized views.

---

## 4. Technical Architecture & Data Strategy

### System & Component Architecture

```
┌────────────────────────────────────────────────────────────────────────┐
│                        Bluesky Networks Web UI                         │
│  (React 19 + TypeScript + Tailwind CSS v4 + Motion + Lucide Icons)     │
└───────────────────────────────────┬────────────────────────────────────┘
                                    │ HTTP / REST (/api/*)
                                    ▼
┌────────────────────────────────────────────────────────────────────────┐
│                        Express Full-Stack Server                       │
│    (Mounted on port 3000 via Vite dev server & server.ts runner)       │
├────────────────────────────────────────────────────────────────────────┤
│ • Auth & Session Controller (RBAC verification & lockout safeguards)   │
│ • Project Controller (Authoritative assignment filtering & stage logs) │
│ • Performance Engine (On-time calculation, point rules & audit logs)   │
│ • Media Assets & Calendar Engine (Channels, video releases, schedules) │
│ • Messaging Controller (Private 1-to-1 threads & read receipts)       │
│ • Admin & Audit Controller (Account changes, approvals & security log) │
└───────────────────────────────────┬────────────────────────────────────┘
                                    │ JSON File Read / Atomic Write
                                    ▼
┌────────────────────────────────────────────────────────────────────────┐
│                   Persistent Storage: data/store.json                  │
│  (Users, Projects, Channels, Videos, Schedules, Messages, Audit Logs)  │
└────────────────────────────────────────────────────────────────────────┘
```

### Data Model & Key Entities
- **User**: `id`, `name`, `username`, `email`, `role` (`ceo` | `manager` | `member`), `title`, `avatarUrl`, `status` (`active` | `suspended`), `points`, `onTimeRate`, `createdAt`.
- **Project**: `id`, `code` (e.g., `BSN-1042`), `title`, `description`, `prompt`, `platform` (`YouTube` | `Facebook`), `channelId`, `assignedTo` (`userId`), `priority` (`Low` | `Medium` | `High` | `Urgent`), `category`, `status` (`Not Started` | `In Progress` | `Waiting for Review` | `Revision Required` | `Completed` | `Overdue`), `stage` (`Research` | `Script Writing` | `Prompt Creation` | `Video Generation` | `Editing` | `Review` | `Export` | `Submitted` | `Completed`), `deadline`, `submittedAt`, `submissionLink`, `notes`, `revisionNotes`, `stageHistory[]`.
- **MediaAsset**: `id`, `name`, `platform`, `category`, `status`, `subscribersFollowers`, `notes`, `dateAdded`.
- **PublishedVideo**: `id`, `title`, `platform`, `channelId`, `publishedAt`, `projectId`, `videoUrl`, `category`, `views`, `engagementRate`, `notes`.
- **ContentPlan**: `id`, `title`, `platform`, `channelId`, `scheduledDate`, `concept`, `assignedTo`, `productionStatus`, `publishingStatus`.
- **Message**: `id`, `fromUserId`, `toUserId`, `content`, `attachmentUrl`, `readAt`, `createdAt`.
- **AccountChangeRequest**: `id`, `userId`, `requestedField`, `oldValue`, `newValue`, `reason`, `status` (`pending` | `approved` | `rejected`), `reviewedAt`, `reviewedBy`.
- **AuditLog**: `id`, `actorId`, `action`, `targetType`, `targetId`, `details`, `timestamp`, `ipAddress`.
- **PerformanceRule**: Scoring weights for early (+15), on-time (+10), zero-revision bonus (+5), minor late (-5), severe late (-10), missed (-20).

### Key Sequences
- **Stage Progression & Real-Time Sync**: When a team member advances a stage, the API writes a timestamped record to `stageHistory`, updates project status, generates an audit log entry, and broadcasts the event into the activity feed.
- **Review & Point Calculation**: Upon approval, the server compares `submittedAt` against `deadline`, automatically awards points to the user's profile, creates a point audit trail, and marks the project `Completed`.

---

## 5. Verification & Delivery Milestones

1. **Backend & Persistent Store**: Verify Express API endpoints for users, projects, channels, publishing records, messages, and audit logging with seeded data.
2. **Access Control Enforcement**: Confirm that non-assigned team members receive 403 or filtered results when querying projects.
3. **CEO & Team Workspaces**: Test all 12 CEO management views and the 6 streamlined Team Member views.
4. **Interactive Flows**: Validate project creation, stage updating, submission review, point adjustment, content scheduling, 1-on-1 messaging, and CEO account approval.
5. **Aesthetic & Theme Verification**: Confirm light/dark mode contrast, glassmorphism fidelity, responsive mobile layouts, and strict anti-slop guidelines.
6. **Lint & Build Pass**: Ensure `compile_applet` and `lint_applet` pass cleanly without errors.
