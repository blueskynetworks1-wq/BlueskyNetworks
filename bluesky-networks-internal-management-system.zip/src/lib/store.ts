import { useState, useEffect } from 'react';
import {
  User,
  Project,
  MediaAsset,
  PublishedVideo,
  ContentPlanItem,
  Message,
  NotificationItem,
  AccountChangeRequest,
  AuditLog,
  ScoringRule,
  PointAuditEntry,
  ProductionStage,
  ProjectStatus,
  TimeLogEntry,
} from '../types';
import {
  INITIAL_USERS,
  INITIAL_MEDIA_ASSETS,
  INITIAL_PROJECTS,
  INITIAL_PUBLISHED_VIDEOS,
  INITIAL_CONTENT_PLANS,
  INITIAL_MESSAGES,
  INITIAL_NOTIFICATIONS,
  INITIAL_ACCOUNT_REQUESTS,
  INITIAL_AUDIT_LOGS,
  INITIAL_SCORING_RULES,
  INITIAL_POINT_AUDITS,
} from '../data/seedData';

const STORAGE_KEY = 'bluesky_networks_datastore_v2';
const SESSION_KEY = 'bluesky_networks_current_user_id';
const LOGIN_ATTEMPTS_KEY = 'bluesky_login_attempts';

interface DataStore {
  users: User[];
  projects: Project[];
  mediaAssets: MediaAsset[];
  publishedVideos: PublishedVideo[];
  contentPlans: ContentPlanItem[];
  messages: Message[];
  notifications: NotificationItem[];
  accountRequests: AccountChangeRequest[];
  auditLogs: AuditLog[];
  scoringRules: ScoringRule[];
  pointAudits: PointAuditEntry[];
}

function loadInitialStore(): DataStore {
  if (typeof window === 'undefined') {
    return {
      users: INITIAL_USERS,
      projects: INITIAL_PROJECTS,
      mediaAssets: INITIAL_MEDIA_ASSETS,
      publishedVideos: INITIAL_PUBLISHED_VIDEOS,
      contentPlans: INITIAL_CONTENT_PLANS,
      messages: INITIAL_MESSAGES,
      notifications: INITIAL_NOTIFICATIONS,
      accountRequests: INITIAL_ACCOUNT_REQUESTS,
      auditLogs: INITIAL_AUDIT_LOGS,
      scoringRules: INITIAL_SCORING_RULES,
      pointAudits: INITIAL_POINT_AUDITS,
    };
  }

  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      // Ensure all collections exist
      return {
        users: parsed.users || INITIAL_USERS,
        projects: parsed.projects || INITIAL_PROJECTS,
        mediaAssets: parsed.mediaAssets || INITIAL_MEDIA_ASSETS,
        publishedVideos: parsed.publishedVideos || INITIAL_PUBLISHED_VIDEOS,
        contentPlans: parsed.contentPlans || INITIAL_CONTENT_PLANS,
        messages: parsed.messages || INITIAL_MESSAGES,
        notifications: parsed.notifications || INITIAL_NOTIFICATIONS,
        accountRequests: parsed.accountRequests || INITIAL_ACCOUNT_REQUESTS,
        auditLogs: parsed.auditLogs || INITIAL_AUDIT_LOGS,
        scoringRules: parsed.scoringRules || INITIAL_SCORING_RULES,
        pointAudits: parsed.pointAudits || INITIAL_POINT_AUDITS,
      };
    }
  } catch (err) {
    console.error('Failed to parse local storage, loading seed data:', err);
  }

  const initial = {
    users: INITIAL_USERS,
    projects: INITIAL_PROJECTS,
    mediaAssets: INITIAL_MEDIA_ASSETS,
    publishedVideos: INITIAL_PUBLISHED_VIDEOS,
    contentPlans: INITIAL_CONTENT_PLANS,
    messages: INITIAL_MESSAGES,
    notifications: INITIAL_NOTIFICATIONS,
    accountRequests: INITIAL_ACCOUNT_REQUESTS,
    auditLogs: INITIAL_AUDIT_LOGS,
    scoringRules: INITIAL_SCORING_RULES,
    pointAudits: INITIAL_POINT_AUDITS,
  };
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(initial));
  } catch (e) {
    // Ignore storage quota errors in evaluation
  }
  return initial;
}

// In-memory singleton store
let currentStore: DataStore = loadInitialStore();
const listeners = new Set<() => void>();

function notify() {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(currentStore));
  } catch (e) {
    console.error('Failed to write to local storage', e);
  }
  listeners.forEach((listener) => listener());
}

export function getCurrentUser(): User {
  const currentUserId = typeof window !== 'undefined' ? localStorage.getItem(SESSION_KEY) || 'u-manuja' : 'u-manuja';
  const found = currentStore.users.find((u) => u.id === currentUserId && u.status !== 'suspended');
  return found || currentStore.users[0]; // defaults to Manuja Rathnayake (CEO)
}

export function setCurrentUser(userId: string): void {
  if (typeof window !== 'undefined') {
    localStorage.setItem(SESSION_KEY, userId);
  }
  notify();
}

export function useBlueskyStore() {
  const [, setTick] = useState(0);

  useEffect(() => {
    const handleUpdate = () => setTick((t) => t + 1);
    listeners.add(handleUpdate);
    return () => {
      listeners.delete(handleUpdate);
    };
  }, []);

  const currentUser = getCurrentUser();

  // STRICT PRIVACY FILTERING:
  // If user is a member, they can ONLY see projects assigned to them.
  const visibleProjects = currentStore.projects.filter((p) => {
    if (currentUser.role === 'ceo' || currentUser.role === 'manager') {
      return true;
    }
    return p.assignedToId === currentUser.id;
  });

  // Filter messages to only conversations involving current user (unless CEO viewing logs)
  const visibleMessages = currentStore.messages.filter((m) => {
    if (currentUser.role === 'ceo') {
      return true;
    }
    return m.senderId === currentUser.id || m.recipientId === currentUser.id;
  });

  return {
    currentUser,
    users: currentStore.users,
    projects: visibleProjects,
    allProjectsCount: currentStore.projects.length,
    mediaAssets: currentStore.mediaAssets,
    publishedVideos: currentStore.publishedVideos,
    contentPlans: currentStore.contentPlans,
    messages: visibleMessages,
    notifications: currentStore.notifications,
    accountRequests: currentStore.accountRequests,
    auditLogs: currentStore.auditLogs,
    scoringRules: currentStore.scoringRules,
    pointAudits: currentStore.pointAudits,

    // Store operations
    setCurrentUser,
    createProject,
    updateProjectStage,
    submitProject,
    reviewProject,
    deleteProject,
    adjustUserPoints,
    createUser,
    updateUserStatus,
    resetUserPasswordSecurely,
    requestAccountChange,
    reviewAccountChange,
    sendMessage,
    markMessageRead,
    createContentPlan,
    updateContentPlan,
    deleteContentPlan,
    createMediaAsset,
    updateMediaAsset,
    createPublishedVideo,
    updateScoringRule,
    markNotificationRead,
    clearAllNotifications,
    resetAllDataToDefaults,
    exportDataJson,
    startProjectTimer,
    stopProjectTimer,
  };
}

// ----------------- STORE OPERATIONS ----------------- //

function logAudit(
  actor: User,
  action: string,
  targetType: AuditLog['targetType'],
  targetId: string,
  targetName: string,
  details: string
) {
  const newLog: AuditLog = {
    id: `aud-${Date.now()}-${Math.random().toString(36).substr(2, 4)}`,
    actorId: actor.id,
    actorName: actor.name,
    actorRole: actor.role,
    action,
    targetType,
    targetId,
    targetName,
    details,
    timestamp: new Date().toISOString().replace('T', ' ').substring(0, 16),
  };
  currentStore.auditLogs = [newLog, ...currentStore.auditLogs];
}

function addNotification(
  type: NotificationItem['type'],
  title: string,
  message: string,
  linkTab?: string,
  targetId?: string
) {
  const notif: NotificationItem = {
    id: `notif-${Date.now()}-${Math.random().toString(36).substr(2, 4)}`,
    type,
    title,
    message,
    timestamp: new Date().toISOString().replace('T', ' ').substring(0, 16),
    isRead: false,
    linkTab,
    targetId,
  };
  currentStore.notifications = [notif, ...currentStore.notifications];
}

export function createProject(
  projectData: Omit<
    Project,
    'id' | 'code' | 'createdAt' | 'updatedAt' | 'stageHistory' | 'revisionHistory' | 'status'
  >,
  actor: User
): Project {
  const codeNum = 1085 + currentStore.projects.length + 1;
  const projectCode = `BSN-${codeNum}`;
  const now = new Date().toISOString().replace('T', ' ').substring(0, 16);

  const newProject: Project = {
    ...projectData,
    id: `proj-${Date.now()}`,
    code: projectCode,
    status: 'Assigned',
    currentStage: projectData.currentStage || 'Research',
    createdAt: now,
    updatedAt: now,
    stageHistory: [
      {
        id: `sh-${Date.now()}`,
        stage: projectData.currentStage || 'Research',
        updatedBy: actor.name,
        timestamp: now,
        notes: `Project initialized and assigned to ${projectData.assignedToName}`,
      },
    ],
    revisionHistory: [],
  };

  currentStore.projects = [newProject, ...currentStore.projects];

  // Update assigned user active project count
  currentStore.users = currentStore.users.map((u) => {
    if (u.id === projectData.assignedToId) {
      return { ...u, activeProjectsCount: (u.activeProjectsCount || 0) + 1 };
    }
    return u;
  });

  logAudit(
    actor,
    'CREATE_PROJECT',
    'Project',
    projectCode,
    newProject.title,
    `Project assigned to ${newProject.assignedToName} with deadline ${newProject.deadline}`
  );

  addNotification(
    'assignment',
    'New Project Assigned',
    `You have been assigned to ${projectCode}: "${newProject.title}"`,
    'projects',
    newProject.id
  );

  notify();
  return newProject;
}

export function updateProjectStage(
  projectId: string,
  newStage: ProductionStage,
  notes: string,
  actor: User
): void {
  const now = new Date().toISOString().replace('T', ' ').substring(0, 16);

  currentStore.projects = currentStore.projects.map((p) => {
    if (p.id !== projectId) return p;

    let newStatus: ProjectStatus = p.status;
    if (newStage === 'Submitted') {
      newStatus = 'Waiting for Review';
    } else if (newStage === 'Completed') {
      newStatus = 'Completed';
    } else {
      newStatus = 'In Progress';
    }

    const newHistoryItem = {
      id: `sh-${Date.now()}`,
      stage: newStage,
      updatedBy: actor.name,
      timestamp: now,
      notes: notes || undefined,
    };

    logAudit(
      actor,
      'STAGE_UPDATE',
      'Project',
      p.code,
      p.title,
      `Updated stage from ${p.currentStage} to ${newStage}. Notes: ${notes || 'None'}`
    );

    addNotification(
      'system',
      'Project Stage Updated',
      `${actor.name} advanced ${p.code} to stage: ${newStage}`,
      'projects',
      p.id
    );

    return {
      ...p,
      currentStage: newStage,
      status: newStatus,
      updatedAt: now,
      stageHistory: [...p.stageHistory, newHistoryItem],
    };
  });

  notify();
}

export function startProjectTimer(projectId: string, actor: User): void {
  const now = new Date().toISOString();

  currentStore.projects = currentStore.projects.map((p) => {
    if (p.id !== projectId) return p;
    return {
      ...p,
      activeTimerStartedAt: now,
      updatedAt: now.replace('T', ' ').substring(0, 16),
    };
  });

  const proj = currentStore.projects.find((p) => p.id === projectId);
  if (proj) {
    logAudit(
      actor,
      'TIMER_START',
      'Project',
      proj.code,
      proj.title,
      `Timer started by ${actor.name} in stage: ${proj.currentStage}`
    );
  }

  notify();
}

export function stopProjectTimer(projectId: string, actor: User, notes?: string): void {
  const now = new Date();
  const nowIso = now.toISOString();
  const nowStr = nowIso.replace('T', ' ').substring(0, 16);

  let loggedDurationSec = 0;
  let targetCode = '';
  let targetTitle = '';
  let targetStage: ProductionStage = 'Editing';

  currentStore.projects = currentStore.projects.map((p) => {
    if (p.id !== projectId || !p.activeTimerStartedAt) return p;

    const startMs = new Date(p.activeTimerStartedAt).getTime();
    const durationSec = Math.max(1, Math.round((now.getTime() - startMs) / 1000));
    loggedDurationSec = durationSec;
    targetCode = p.code;
    targetTitle = p.title;
    targetStage = p.currentStage;

    const startStr = new Date(p.activeTimerStartedAt).toISOString().replace('T', ' ').substring(0, 16);

    const newLog: TimeLogEntry = {
      id: `tl-${Date.now()}`,
      userId: actor.id,
      userName: actor.name,
      startedAt: startStr,
      stoppedAt: nowStr,
      durationSeconds: durationSec,
      stageAtTime: p.currentStage,
      notes: notes || undefined,
    };

    const newTotalSeconds = (p.timeSpentSeconds || 0) + durationSec;

    return {
      ...p,
      timeSpentSeconds: newTotalSeconds,
      activeTimerStartedAt: undefined,
      timeLogs: [newLog, ...(p.timeLogs || [])],
      updatedAt: nowStr,
    };
  });

  if (loggedDurationSec > 0) {
    const durationHours = loggedDurationSec / 3600;

    currentStore.users = currentStore.users.map((u) => {
      if (u.id === actor.id) {
        return {
          ...u,
          totalHoursLogged: Number(((u.totalHoursLogged || 0) + durationHours).toFixed(1)),
        };
      }
      return u;
    });

    const mins = Math.round(loggedDurationSec / 60);
    const hours = Math.floor(mins / 60);
    const remMins = mins % 60;
    const formatted = hours > 0 ? `${hours}h ${remMins}m` : `${remMins}m`;

    logAudit(
      actor,
      'TIMER_STOP',
      'Project',
      targetCode,
      targetTitle,
      `Timer stopped by ${actor.name}. Session logged: ${formatted}. Stage: ${targetStage}.`
    );

    addNotification(
      'system',
      'Task Session Logged',
      `${actor.name} logged ${formatted} on ${targetCode} "${targetTitle}"`,
      'projects',
      projectId
    );
  }

  notify();
}

export function submitProject(
  projectId: string,
  submissionLink: string,
  submissionNotes: string,
  actor: User
): void {
  const now = new Date().toISOString().replace('T', ' ').substring(0, 16);

  currentStore.projects = currentStore.projects.map((p) => {
    if (p.id !== projectId) return p;

    const newHistoryItem = {
      id: `sh-${Date.now()}`,
      stage: 'Submitted' as ProductionStage,
      updatedBy: actor.name,
      timestamp: now,
      notes: submissionNotes || 'Final delivery submitted for review.',
    };

    logAudit(
      actor,
      'SUBMIT_PROJECT',
      'Project',
      p.code,
      p.title,
      `Submitted final video link: ${submissionLink}`
    );

    addNotification(
      'submission',
      'Video Awaiting Review',
      `${actor.name} submitted ${p.code} "${p.title}" for approval.`,
      'projects',
      p.id
    );

    return {
      ...p,
      status: 'Waiting for Review' as ProjectStatus,
      currentStage: 'Submitted' as ProductionStage,
      finalSubmissionLink: submissionLink,
      submissionNotes,
      submittedAt: now,
      updatedAt: now,
      stageHistory: [...p.stageHistory, newHistoryItem],
    };
  });

  notify();
}

export function reviewProject(
  projectId: string,
  decision: 'approve' | 'revise',
  feedback: string,
  actor: User
): void {
  const now = new Date().toISOString().replace('T', ' ').substring(0, 16);
  const targetProject = currentStore.projects.find((p) => p.id === projectId);
  if (!targetProject) return;

  if (decision === 'approve') {
    // Calculate performance points
    let pointsAwarded = 10; // base on-time
    const deadlineDate = new Date(targetProject.deadline).getTime();
    const submissionDate = targetProject.submittedAt ? new Date(targetProject.submittedAt).getTime() : Date.now();
    const diffHours = (deadlineDate - submissionDate) / (1000 * 60 * 60);

    if (diffHours >= 6) {
      pointsAwarded = 15; // Ahead of schedule
    } else if (diffHours < 0 && diffHours >= -6) {
      pointsAwarded = -5; // Slightly late
    } else if (diffHours < -6) {
      pointsAwarded = -10; // Significantly late
    }

    // Zero revision bonus (+5)
    if (targetProject.revisionHistory.length === 0) {
      pointsAwarded += 5;
    }

    currentStore.projects = currentStore.projects.map((p) => {
      if (p.id !== projectId) return p;
      return {
        ...p,
        status: 'Completed',
        currentStage: 'Completed',
        completedAt: now,
        awardedPoints: pointsAwarded,
        updatedAt: now,
        stageHistory: [
          ...p.stageHistory,
          {
            id: `sh-${Date.now()}`,
            stage: 'Completed',
            updatedBy: actor.name,
            timestamp: now,
            notes: `Approved by ${actor.name}. Awarded ${pointsAwarded} pts. Feedback: ${feedback || 'Approved.'}`,
          },
        ],
      };
    });

    // Award points to user profile and update project counts
    currentStore.users = currentStore.users.map((u) => {
      if (u.id === targetProject.assignedToId) {
        return {
          ...u,
          points: (u.points || 0) + pointsAwarded,
          completedProjectsCount: (u.completedProjectsCount || 0) + 1,
          activeProjectsCount: Math.max(0, (u.activeProjectsCount || 1) - 1),
        };
      }
      return u;
    });

    // Record point audit
    currentStore.pointAudits = [
      {
        id: `pa-${Date.now()}`,
        userId: targetProject.assignedToId,
        userName: targetProject.assignedToName,
        projectCode: targetProject.code,
        points: pointsAwarded,
        reason: `Completed project approval (${pointsAwarded > 0 ? '+' : ''}${pointsAwarded} pts). Zero-rev bonus included if applicable.`,
        adjustedBy: actor.name,
        timestamp: now,
      },
      ...currentStore.pointAudits,
    ];

    logAudit(
      actor,
      'APPROVE_PROJECT',
      'Project',
      targetProject.code,
      targetProject.title,
      `Approved project. Awarded ${pointsAwarded} points to ${targetProject.assignedToName}.`
    );

    addNotification(
      'approval',
      'Project Approved!',
      `${actor.name} approved ${targetProject.code}. You earned ${pointsAwarded} performance points!`,
      'projects',
      targetProject.id
    );
  } else {
    // Request Revision
    currentStore.projects = currentStore.projects.map((p) => {
      if (p.id !== projectId) return p;
      return {
        ...p,
        status: 'Revision Required',
        currentStage: 'Editing',
        updatedAt: now,
        revisionHistory: [
          ...p.revisionHistory,
          {
            id: `rev-${Date.now()}`,
            requestedBy: actor.name,
            timestamp: now,
            feedback,
          },
        ],
        stageHistory: [
          ...p.stageHistory,
          {
            id: `sh-${Date.now()}`,
            stage: 'Editing',
            updatedBy: actor.name,
            timestamp: now,
            notes: `Revision Requested: ${feedback}`,
          },
        ],
      };
    });

    logAudit(
      actor,
      'REQUEST_REVISION',
      'Project',
      targetProject.code,
      targetProject.title,
      `Revision requested by ${actor.name}: ${feedback}`
    );

    addNotification(
      'revision',
      'Revision Requested',
      `${actor.name} requested changes on ${targetProject.code}: "${feedback.substring(0, 80)}..."`,
      'projects',
      targetProject.id
    );
  }

  notify();
}

export function deleteProject(projectId: string, actor: User): void {
  const target = currentStore.projects.find((p) => p.id === projectId);
  if (!target) return;

  currentStore.projects = currentStore.projects.filter((p) => p.id !== projectId);

  logAudit(
    actor,
    'DELETE_PROJECT',
    'Project',
    target.code,
    target.title,
    `Deleted by ${actor.name}`
  );

  notify();
}

export function adjustUserPoints(
  userId: string,
  delta: number,
  reason: string,
  actor: User
): void {
  const targetUser = currentStore.users.find((u) => u.id === userId);
  if (!targetUser) return;
  const now = new Date().toISOString().replace('T', ' ').substring(0, 16);

  currentStore.users = currentStore.users.map((u) => {
    if (u.id === userId) {
      return { ...u, points: (u.points || 0) + delta };
    }
    return u;
  });

  currentStore.pointAudits = [
    {
      id: `pa-${Date.now()}`,
      userId,
      userName: targetUser.name,
      points: delta,
      reason,
      adjustedBy: actor.name,
      timestamp: now,
    },
    ...currentStore.pointAudits,
  ];

  logAudit(
    actor,
    'ADJUST_POINTS',
    'User',
    userId,
    targetUser.name,
    `Adjusted points by ${delta > 0 ? '+' : ''}${delta}. Reason: ${reason}`
  );

  addNotification(
    'system',
    'Performance Points Adjustment',
    `Your points were adjusted by ${delta > 0 ? '+' : ''}${delta} points. Reason: ${reason}`,
    'performance',
    userId
  );

  notify();
}

export function createUser(
  userData: Omit<User, 'id' | 'points' | 'onTimeRate' | 'completedProjectsCount' | 'activeProjectsCount' | 'joinDate'>,
  initialPasswordSecurelyGiven: string,
  actor: User
): User {
  const id = `u-${Date.now()}`;
  const now = new Date().toISOString().substring(0, 10);

  const newUser: User = {
    ...userData,
    id,
    points: 100, // baseline onboarding points
    onTimeRate: 100,
    completedProjectsCount: 0,
    activeProjectsCount: 0,
    joinDate: now,
    forcePasswordChange: true, // forces password update on first login
  };

  currentStore.users = [...currentStore.users, newUser];

  // Note: we never store or display plaintext password.
  logAudit(
    actor,
    'CREATE_USER',
    'User',
    id,
    newUser.name,
    `Created user account with role: ${newUser.role}, job title: ${newUser.jobTitle}. Initial password provisioned securely (masked).`
  );

  notify();
  return newUser;
}

export function updateUserStatus(
  userId: string,
  status: User['status'],
  actor: User
): void {
  const user = currentStore.users.find((u) => u.id === userId);
  if (!user) return;

  currentStore.users = currentStore.users.map((u) => {
    if (u.id === userId) return { ...u, status };
    return u;
  });

  logAudit(
    actor,
    'UPDATE_USER_STATUS',
    'User',
    userId,
    user.name,
    `Account status changed to: ${status}`
  );

  notify();
}

export function resetUserPasswordSecurely(
  userId: string,
  actor: User
): { tempResetToken: string } {
  const user = currentStore.users.find((u) => u.id === userId);
  if (!user) throw new Error('User not found');

  const tempResetToken = `BSN-RST-${Math.random().toString(36).substring(2, 8).toUpperCase()}`;

  currentStore.users = currentStore.users.map((u) => {
    if (u.id === userId) return { ...u, forcePasswordChange: true };
    return u;
  });

  logAudit(
    actor,
    'RESET_PASSWORD',
    'Security',
    userId,
    user.name,
    `Issued secure single-use reset token. Forced password reset on next authentication.`
  );

  notify();
  return { tempResetToken };
}

export function requestAccountChange(
  userId: string,
  requestType: AccountChangeRequest['requestType'],
  requestedChanges: AccountChangeRequest['requestedChanges'],
  reason: string
): void {
  const user = currentStore.users.find((u) => u.id === userId);
  if (!user) return;

  const newRequest: AccountChangeRequest = {
    id: `req-${Date.now()}`,
    userId,
    userName: user.name,
    userRole: user.role,
    requestType,
    requestedChanges,
    reason,
    status: 'Pending',
    requestedAt: new Date().toISOString().replace('T', ' ').substring(0, 16),
  };

  currentStore.accountRequests = [newRequest, ...currentStore.accountRequests];

  addNotification(
    'account_request',
    'Sensitive Account Change Request',
    `${user.name} submitted an account change request (${requestType}) requiring CEO approval.`,
    'admin',
    newRequest.id
  );

  notify();
}

export function reviewAccountChange(
  requestId: string,
  approved: boolean,
  notes: string,
  actor: User
): void {
  const req = currentStore.accountRequests.find((r) => r.id === requestId);
  if (!req) return;
  const now = new Date().toISOString().replace('T', ' ').substring(0, 16);

  currentStore.accountRequests = currentStore.accountRequests.map((r) => {
    if (r.id !== requestId) return r;
    return {
      ...r,
      status: approved ? 'Approved' : 'Rejected',
      reviewedAt: now,
      reviewedBy: actor.name,
      reviewNotes: notes,
    };
  });

  if (approved) {
    // Apply changes to target user
    currentStore.users = currentStore.users.map((u) => {
      if (u.id !== req.userId) return u;
      const updatedUser = { ...u };
      req.requestedChanges.forEach((ch) => {
        (updatedUser as any)[ch.field] = ch.newValue;
      });
      return updatedUser;
    });
  }

  logAudit(
    actor,
    approved ? 'APPROVE_ACCOUNT_CHANGE' : 'REJECT_ACCOUNT_CHANGE',
    'AccountRequest',
    requestId,
    req.userName,
    `Decision: ${approved ? 'APPROVED' : 'REJECTED'}. Notes: ${notes}`
  );

  addNotification(
    'system',
    `Account Change ${approved ? 'Approved' : 'Rejected'}`,
    `Your request for ${req.requestType} was ${approved ? 'approved' : 'rejected'} by ${actor.name}.`,
    'profile',
    req.userId
  );

  notify();
}

export function sendMessage(
  sender: User,
  recipientId: string,
  content: string,
  attachmentName?: string,
  attachmentUrl?: string
): Message {
  const recipient = currentStore.users.find((u) => u.id === recipientId);
  const now = new Date().toISOString().replace('T', ' ').substring(0, 16);

  const newMsg: Message = {
    id: `msg-${Date.now()}`,
    senderId: sender.id,
    senderName: sender.name,
    senderRole: sender.role,
    senderAvatar: sender.avatarUrl,
    recipientId,
    recipientName: recipient?.name || 'Team Member',
    content,
    attachmentName,
    attachmentUrl,
    createdAt: now,
    isRead: false,
  };

  currentStore.messages = [...currentStore.messages, newMsg];

  addNotification(
    'system',
    'New Direct Message',
    `${sender.name}: "${content.substring(0, 60)}..."`,
    'messages',
    newMsg.id
  );

  notify();
  return newMsg;
}

export function markMessageRead(messageId: string): void {
  currentStore.messages = currentStore.messages.map((m) => {
    if (m.id === messageId) return { ...m, isRead: true };
    return m;
  });
  notify();
}

export function createContentPlan(
  plan: Omit<ContentPlanItem, 'id'>,
  actor: User
): void {
  const newPlan: ContentPlanItem = {
    ...plan,
    id: `cp-${Date.now()}`,
  };

  currentStore.contentPlans = [newPlan, ...currentStore.contentPlans];

  logAudit(
    actor,
    'CREATE_CONTENT_PLAN',
    'ContentPlan',
    newPlan.id,
    newPlan.conceptTitle,
    `Scheduled for ${newPlan.date} on ${newPlan.channelName}`
  );

  notify();
}

export function updateContentPlan(
  plan: ContentPlanItem,
  actor: User
): void {
  currentStore.contentPlans = currentStore.contentPlans.map((cp) => (cp.id === plan.id ? plan : cp));

  logAudit(
    actor,
    'UPDATE_CONTENT_PLAN',
    'ContentPlan',
    plan.id,
    plan.conceptTitle,
    `Updated schedule status: ${plan.publishingStatus}`
  );

  notify();
}

export function deleteContentPlan(id: string, actor: User): void {
  const target = currentStore.contentPlans.find((cp) => cp.id === id);
  if (!target) return;

  currentStore.contentPlans = currentStore.contentPlans.filter((cp) => cp.id !== id);

  logAudit(
    actor,
    'DELETE_CONTENT_PLAN',
    'ContentPlan',
    id,
    target.conceptTitle,
    'Removed from calendar'
  );

  notify();
}

export function createMediaAsset(
  asset: Omit<MediaAsset, 'id' | 'dateAdded'>,
  actor: User
): void {
  const newAsset: MediaAsset = {
    ...asset,
    id: `chan-${Date.now()}`,
    dateAdded: new Date().toISOString().substring(0, 10),
  };

  currentStore.mediaAssets = [...currentStore.mediaAssets, newAsset];

  logAudit(
    actor,
    'CREATE_MEDIA_ASSET',
    'MediaAsset',
    newAsset.id,
    newAsset.name,
    `Added ${newAsset.platform} channel`
  );

  notify();
}

export function updateMediaAsset(
  asset: MediaAsset,
  actor: User
): void {
  currentStore.mediaAssets = currentStore.mediaAssets.map((a) => (a.id === asset.id ? asset : a));

  logAudit(
    actor,
    'UPDATE_MEDIA_ASSET',
    'MediaAsset',
    asset.id,
    asset.name,
    `Updated metrics / status`
  );

  notify();
}

export function createPublishedVideo(
  video: Omit<PublishedVideo, 'id'>,
  actor: User
): void {
  const newVideo: PublishedVideo = {
    ...video,
    id: `pub-${Date.now()}`,
  };

  currentStore.publishedVideos = [newVideo, ...currentStore.publishedVideos];

  logAudit(
    actor,
    'RECORD_PUBLISHED_VIDEO',
    'Project',
    newVideo.id,
    newVideo.title,
    `Recorded release on ${newVideo.channelName}`
  );

  notify();
}

export function updateScoringRule(
  ruleId: string,
  pointsDelta: number,
  actor: User
): void {
  currentStore.scoringRules = currentStore.scoringRules.map((r) => {
    if (r.id === ruleId) return { ...r, pointsDelta };
    return r;
  });

  logAudit(
    actor,
    'UPDATE_SCORING_RULE',
    'Security',
    ruleId,
    'Performance Scoring Rules',
    `Updated rule weight to ${pointsDelta} pts`
  );

  notify();
}

export function markNotificationRead(id: string): void {
  currentStore.notifications = currentStore.notifications.map((n) => (n.id === id ? { ...n, isRead: true } : n));
  notify();
}

export function clearAllNotifications(): void {
  currentStore.notifications = currentStore.notifications.map((n) => ({ ...n, isRead: true }));
  notify();
}

export function resetAllDataToDefaults(): void {
  currentStore = {
    users: INITIAL_USERS,
    projects: INITIAL_PROJECTS,
    mediaAssets: INITIAL_MEDIA_ASSETS,
    publishedVideos: INITIAL_PUBLISHED_VIDEOS,
    contentPlans: INITIAL_CONTENT_PLANS,
    messages: INITIAL_MESSAGES,
    notifications: INITIAL_NOTIFICATIONS,
    accountRequests: INITIAL_ACCOUNT_REQUESTS,
    auditLogs: INITIAL_AUDIT_LOGS,
    scoringRules: INITIAL_SCORING_RULES,
    pointAudits: INITIAL_POINT_AUDITS,
  };
  if (typeof window !== 'undefined') {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(currentStore));
    localStorage.setItem(SESSION_KEY, 'u-manuja');
  }
  notify();
}

export function exportDataJson(): string {
  return JSON.stringify(currentStore, null, 2);
}
