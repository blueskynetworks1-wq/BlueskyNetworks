/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { useBlueskyStore } from './lib/store';
import { Header } from './components/common/Header';
import { Sidebar } from './components/common/Sidebar';
import { SessionSwitcher } from './components/common/SessionSwitcher';
import { CommandPalette } from './components/common/CommandPalette';
import { CeoDashboard } from './components/dashboard/CeoDashboard';
import { MemberDashboard } from './components/dashboard/MemberDashboard';
import { ProjectList } from './components/projects/ProjectList';
import { ProjectDetailModal } from './components/projects/ProjectDetailModal';
import { CreateProjectModal } from './components/projects/CreateProjectModal';
import { TeamRoster } from './components/team/TeamRoster';
import { PerformanceView } from './components/performance/PerformanceView';
import { ContentCalendarView } from './components/calendar/ContentCalendarView';
import { PublishedVideosView } from './components/publishing/PublishedVideosView';
import { MediaAssetsView } from './components/media/MediaAssetsView';
import { MessagingView } from './components/messaging/MessagingView';
import { AdminDashboard } from './components/admin/AdminDashboard';
import { NotificationCenter } from './components/notifications/NotificationCenter';
import { UserProfileView } from './components/profile/UserProfileView';
import { InsightsView } from './components/insights/InsightsView';
import { CompanySettingsView } from './components/settings/CompanySettingsView';
import { LoginModal } from './components/auth/LoginModal';

export default function App() {
  const store = useBlueskyStore();
  const { currentUser } = store;

  // Dark Mode State
  const [darkMode, setDarkMode] = useState<boolean>(() => {
    if (typeof window !== 'undefined') {
      const saved = localStorage.getItem('bluesky_theme');
      if (saved) return saved === 'dark';
      return window.matchMedia('(prefers-color-scheme: dark)').matches;
    }
    return false;
  });

  useEffect(() => {
    if (darkMode) {
      document.documentElement.classList.add('dark');
      localStorage.setItem('bluesky_theme', 'dark');
    } else {
      document.documentElement.classList.remove('dark');
      localStorage.setItem('bluesky_theme', 'light');
    }
  }, [darkMode]);

  const toggleDarkMode = () => setDarkMode(!darkMode);

  // Active Navigation Tab
  const [activeTab, setActiveTab] = useState<string>(() => {
    return currentUser.role === 'member' ? 'my-dashboard' : 'dashboard';
  });

  // Strict role guard: if user role changes or is a member attempting to view restricted tabs, redirect
  useEffect(() => {
    const ceoTabs = ['dashboard', 'projects', 'team', 'calendar', 'publishing', 'media', 'insights', 'admin', 'settings'];
    const memberTabs = ['my-dashboard', 'my-projects', 'messages', 'my-performance', 'notifications', 'profile'];

    if (currentUser.role === 'member' && !memberTabs.includes(activeTab)) {
      setActiveTab('my-dashboard');
    } else if (currentUser.role !== 'member' && activeTab === 'my-dashboard') {
      setActiveTab('dashboard');
    } else if (currentUser.role !== 'member' && activeTab === 'my-projects') {
      setActiveTab('projects');
    } else if (currentUser.role !== 'member' && activeTab === 'my-performance') {
      setActiveTab('performance');
    }
  }, [currentUser.role, activeTab]);

  // Modals state
  const [selectedProjectId, setSelectedProjectId] = useState<string | null>(null);
  const [isCreateProjectOpen, setIsCreateProjectOpen] = useState(false);
  const [isSessionSwitcherOpen, setIsSessionSwitcherOpen] = useState(false);
  const [isCommandPaletteOpen, setIsCommandPaletteOpen] = useState(false);
  const [isLoginModalOpen, setIsLoginModalOpen] = useState(false);

  // Selected project for dossier
  const selectedProject = store.projects.find((p) => p.id === selectedProjectId) || null;

  // Badge calculations
  const unreadNotifications = store.notifications.filter((n) => !n.isRead).length;
  const unreadMessages = store.messages.filter(
    (m) => m.recipientId === currentUser.id && !m.isRead
  ).length;
  const pendingReviews = store.projects.filter(
    (p) => p.status === 'Waiting for Review'
  ).length;

  return (
    <div className="flex h-screen w-full bg-slate-50 dark:bg-[#0b0f19] text-slate-900 dark:text-slate-100 antialiased overflow-hidden select-none font-sans">
      {/* Sidebar Navigation */}
      <Sidebar
        currentUser={currentUser}
        activeTab={activeTab}
        onSelectTab={setActiveTab}
        unreadMessagesCount={unreadMessages}
        unreadNotificationsCount={unreadNotifications}
        pendingReviewsCount={pendingReviews}
      />

      {/* Main Content Area */}
      <div className="flex-1 flex flex-col min-w-0 overflow-hidden">
        {/* Top Header */}
        <Header
          currentUser={currentUser}
          activeTab={activeTab}
          darkMode={darkMode}
          onToggleDarkMode={toggleDarkMode}
          onOpenCommandPalette={() => setIsCommandPaletteOpen(true)}
          onOpenNotifications={() => setActiveTab('notifications')}
          onOpenSessionSwitcher={() => setIsSessionSwitcherOpen(true)}
          onLogout={() => setIsLoginModalOpen(true)}
          unreadNotificationsCount={unreadNotifications}
          unreadMessagesCount={unreadMessages}
        />

        {/* Viewport Canvas */}
        <main className="flex-1 overflow-y-auto p-4 sm:p-6 lg:p-8">
          <div className="max-w-7xl mx-auto">
            {/* CEO Dashboard */}
            {activeTab === 'dashboard' && (
              <CeoDashboard
                projects={store.projects}
                users={store.users}
                publishedVideos={store.publishedVideos}
                contentPlans={store.contentPlans}
                auditLogs={store.auditLogs}
                accountRequests={store.accountRequests}
                onNavigateTab={setActiveTab}
                onOpenCreateProject={() => setIsCreateProjectOpen(true)}
                onSelectProject={(id) => setSelectedProjectId(id)}
              />
            )}

            {/* Team Member Dashboard */}
            {activeTab === 'my-dashboard' && (
              <MemberDashboard
                currentUser={currentUser}
                projects={store.projects}
                messages={store.messages}
                notifications={store.notifications}
                onSelectProject={(id) => setSelectedProjectId(id)}
                onNavigateTab={setActiveTab}
                onStartTimer={(id) => store.startProjectTimer(id, currentUser)}
                onStopTimer={(id, notes) => store.stopProjectTimer(id, currentUser, notes)}
              />
            )}

            {/* Projects Matrix / My Projects */}
            {(activeTab === 'projects' || activeTab === 'my-projects') && (
              <ProjectList
                projects={store.projects}
                currentUser={currentUser}
                onSelectProject={(id) => setSelectedProjectId(id)}
                onOpenCreateProject={() => setIsCreateProjectOpen(true)}
                onStartTimer={(id) => store.startProjectTimer(id, currentUser)}
                onStopTimer={(id, notes) => store.stopProjectTimer(id, currentUser, notes)}
              />
            )}

            {/* Team Dossiers (CEO / Manager) */}
            {activeTab === 'team' && (
              <TeamRoster
                users={store.users}
                projects={store.projects}
                pointAudits={store.pointAudits}
                currentUser={currentUser}
                onAdjustPoints={(userId, delta, reason) =>
                  store.adjustUserPoints(userId, delta, reason, currentUser)
                }
                onResetPassword={(userId) =>
                  store.resetUserPasswordSecurely(userId, currentUser)
                }
                onUpdateStatus={(userId, status) =>
                  store.updateUserStatus(userId, status, currentUser)
                }
                onSelectProject={(id) => setSelectedProjectId(id)}
              />
            )}

            {/* Content Calendar */}
            {activeTab === 'calendar' && (
              <ContentCalendarView
                contentPlans={store.contentPlans}
                mediaAssets={store.mediaAssets}
                users={store.users}
                currentUser={currentUser}
                onCreatePlan={(plan) => store.createContentPlan(plan, currentUser)}
                onUpdatePlan={(plan) => store.updateContentPlan(plan, currentUser)}
                onDeletePlan={(id) => store.deleteContentPlan(id, currentUser)}
              />
            )}

            {/* Published Video Tracker */}
            {activeTab === 'publishing' && (
              <PublishedVideosView
                publishedVideos={store.publishedVideos}
                mediaAssets={store.mediaAssets}
                currentUser={currentUser}
                onCreatePublishedVideo={(video) =>
                  store.createPublishedVideo(video, currentUser)
                }
              />
            )}

            {/* Media Assets Portfolio */}
            {activeTab === 'media' && (
              <MediaAssetsView
                mediaAssets={store.mediaAssets}
                currentUser={currentUser}
                onCreateMediaAsset={(asset) =>
                  store.createMediaAsset(asset, currentUser)
                }
                onUpdateMediaAsset={(asset) =>
                  store.updateMediaAsset(asset, currentUser)
                }
              />
            )}

            {/* Points & Performance */}
            {(activeTab === 'performance' || activeTab === 'my-performance') && (
              <PerformanceView
                users={store.users}
                scoringRules={store.scoringRules}
                pointAudits={store.pointAudits}
                projects={store.projects}
                currentUser={currentUser}
                onUpdateScoringRule={(id, delta) =>
                  store.updateScoringRule(id, delta, currentUser)
                }
              />
            )}

            {/* Internal Messaging */}
            {activeTab === 'messages' && (
              <MessagingView
                messages={store.messages}
                users={store.users}
                currentUser={currentUser}
                onSendMessage={(sender, recipientId, content, attachmentName, attachmentUrl) =>
                  store.sendMessage(sender, recipientId, content, attachmentName, attachmentUrl)
                }
                onMarkRead={(msgId) => store.markMessageRead(msgId)}
              />
            )}

            {/* Business Intelligence (CEO) */}
            {activeTab === 'insights' && (
              <InsightsView
                projects={store.projects}
                users={store.users}
                mediaAssets={store.mediaAssets}
                publishedVideos={store.publishedVideos}
              />
            )}

            {/* Admin Center & Audit Logs (CEO) */}
            {activeTab === 'admin' && (
              <AdminDashboard
                users={store.users}
                auditLogs={store.auditLogs}
                accountRequests={store.accountRequests}
                currentUser={currentUser}
                onCreateUser={(userData, password) =>
                  store.createUser(userData, password, currentUser)
                }
                onUpdateUserStatus={(userId, status) =>
                  store.updateUserStatus(userId, status, currentUser)
                }
                onResetPassword={(userId) =>
                  store.resetUserPasswordSecurely(userId, currentUser)
                }
                onReviewAccountRequest={(reqId, approved, notes) =>
                  store.reviewAccountChange(reqId, approved, notes, currentUser)
                }
              />
            )}

            {/* Notifications Center */}
            {activeTab === 'notifications' && (
              <NotificationCenter
                notifications={store.notifications}
                currentUser={currentUser}
                onMarkRead={(id) => store.markNotificationRead(id)}
                onClearAll={() => store.clearAllNotifications()}
                onNavigateTab={setActiveTab}
                onSelectProject={(id) => setSelectedProjectId(id)}
              />
            )}

            {/* Personal Profile (Team Members) */}
            {activeTab === 'profile' && (
              <UserProfileView
                currentUser={currentUser}
                projects={store.projects}
                onRequestAccountChange={(userId, type, changes, reason) =>
                  store.requestAccountChange(userId, type, changes, reason)
                }
              />
            )}

            {/* Company Settings */}
            {activeTab === 'settings' && (
              <CompanySettingsView
                currentUser={currentUser}
                onResetSeedData={() => store.resetAllDataToDefaults()}
                onExportJson={() => store.exportDataJson()}
              />
            )}
          </div>
        </main>
      </div>

      {/* Project Detail Modal */}
      <ProjectDetailModal
        project={selectedProject}
        currentUser={currentUser}
        onClose={() => setSelectedProjectId(null)}
        onUpdateStage={(projectId, stage, notes) =>
          store.updateProjectStage(projectId, stage, notes, currentUser)
        }
        onSubmitProject={(projectId, link, notes) =>
          store.submitProject(projectId, link, notes, currentUser)
        }
        onReviewProject={(projectId, decision, feedback) =>
          store.reviewProject(projectId, decision, feedback, currentUser)
        }
        onDeleteProject={
          currentUser.role === 'ceo'
            ? (projectId) => store.deleteProject(projectId, currentUser)
            : undefined
        }
        onStartTimer={(id) => store.startProjectTimer(id, currentUser)}
        onStopTimer={(id, notes) => store.stopProjectTimer(id, currentUser, notes)}
      />

      {/* Create Project Modal */}
      <CreateProjectModal
        isOpen={isCreateProjectOpen}
        onClose={() => setIsCreateProjectOpen(false)}
        users={store.users}
        mediaAssets={store.mediaAssets}
        currentUser={currentUser}
        onCreateProject={(data) => store.createProject(data, currentUser)}
      />

      {/* Interactive Role Switcher Modal */}
      <SessionSwitcher
        isOpen={isSessionSwitcherOpen}
        onClose={() => setIsSessionSwitcherOpen(false)}
        users={store.users}
        currentUser={currentUser}
        onSelectUser={(userId) => store.setCurrentUser(userId)}
        onOpenLoginModal={() => setIsLoginModalOpen(true)}
        onResetData={() => store.resetAllDataToDefaults()}
      />

      {/* Global Command Palette (Cmd+K) */}
      <CommandPalette
        isOpen={isCommandPaletteOpen}
        onClose={() => setIsCommandPaletteOpen(false)}
        projects={store.projects}
        users={store.users}
        onSelectTab={setActiveTab}
        onSelectProject={(id) => setSelectedProjectId(id)}
        onToggleDarkMode={toggleDarkMode}
        darkMode={darkMode}
      />

      {/* Authentic Secure Login Simulator */}
      <LoginModal
        isOpen={isLoginModalOpen}
        onClose={() => setIsLoginModalOpen(false)}
        users={store.users}
        onLoginSuccess={(userId) => store.setCurrentUser(userId)}
        onRequestPasswordReset={(username) => {
          const user = store.users.find(
            (u) =>
              u.username.toLowerCase() === username.toLowerCase() ||
              u.email.toLowerCase() === username.toLowerCase()
          );
          if (user) {
            store.requestAccountChange(
              user.id,
              'Password Reset',
              [{ field: 'password', oldValue: '[MASKED]', newValue: '[RESET_REQUESTED]' }],
              'Emergency password reset requested from login terminal.'
            );
          }
        }}
      />
    </div>
  );
}
