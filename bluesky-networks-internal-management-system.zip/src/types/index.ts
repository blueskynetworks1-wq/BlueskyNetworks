export type UserRole = 'ceo' | 'manager' | 'member';

export type UserStatus = 'active' | 'suspended' | 'locked';

export interface ManagerPermissions {
  canAssignProjects: boolean;
  canReviewSubmissions: boolean;
  canEditProjects: boolean;
  canViewAnalytics: boolean;
  canManageTeam: boolean;
  canScheduleContent: boolean;
}

export interface User {
  id: string;
  name: string;
  username: string;
  email: string;
  role: UserRole;
  jobTitle: string;
  department: string;
  avatarUrl?: string;
  status: UserStatus;
  joinDate: string;
  points: number;
  onTimeRate: number; // e.g. 96 (%)
  completedProjectsCount: number;
  activeProjectsCount: number;
  managerPermissions?: ManagerPermissions;
  forcePasswordChange?: boolean;
  lastLoginAt?: string;
  totalHoursLogged?: number;
}

export type PriorityLevel = 'Low' | 'Medium' | 'High' | 'Urgent';

export type ProjectStatus =
  | 'Not Started'
  | 'Assigned'
  | 'In Progress'
  | 'Waiting for Review'
  | 'Revision Required'
  | 'Completed'
  | 'Overdue'
  | 'Cancelled';

export type ProductionStage =
  | 'Research'
  | 'Script Writing'
  | 'Prompt Creation'
  | 'Video Generation'
  | 'Editing'
  | 'Review'
  | 'Final Export'
  | 'Submitted'
  | 'Completed';

export interface StageHistoryItem {
  id: string;
  stage: ProductionStage;
  updatedBy: string; // user name or id
  timestamp: string;
  notes?: string;
}

export interface RevisionHistoryItem {
  id: string;
  requestedBy: string;
  timestamp: string;
  feedback: string;
  resolvedAt?: string;
}

export interface TimeLogEntry {
  id: string;
  userId: string;
  userName: string;
  startedAt: string;
  stoppedAt: string;
  durationSeconds: number;
  stageAtTime: ProductionStage;
  notes?: string;
}

export interface Project {
  id: string;
  code: string; // e.g. BSN-1024
  title: string;
  description: string;
  videoPrompt: string;
  platform: 'YouTube' | 'Facebook' | 'Cross-Platform';
  channelId: string;
  channelName: string;
  startDate: string;
  startTime?: string;
  deadline: string;
  priority: PriorityLevel;
  category: string;
  assignedToId: string;
  assignedToName: string;
  assignedToAvatar?: string;
  status: ProjectStatus;
  currentStage: ProductionStage;
  notes: string;
  referenceLinks: string[];
  finalSubmissionLink?: string;
  submissionNotes?: string;
  submittedAt?: string;
  completedAt?: string;
  awardedPoints?: number;
  stageHistory: StageHistoryItem[];
  revisionHistory: RevisionHistoryItem[];
  timeSpentSeconds?: number;
  activeTimerStartedAt?: string;
  timeLogs?: TimeLogEntry[];
  createdAt: string;
  updatedAt: string;
}

export interface MediaAsset {
  id: string;
  name: string;
  platform: 'YouTube' | 'Facebook' | 'Instagram' | 'TikTok';
  category: string;
  status: 'Active' | 'Paused' | 'Growing' | 'Restricted';
  subscribersCount: string;
  monthlyReach: string;
  notes: string;
  url: string;
  dateAdded: string;
}

export interface PublishedVideo {
  id: string;
  title: string;
  platform: 'YouTube' | 'Facebook';
  channelId: string;
  channelName: string;
  publishedDate: string;
  publishedTime: string;
  projectCode: string;
  videoUrl: string;
  category: string;
  views: number;
  engagementRate: number;
  notes: string;
}

export interface ContentPlanItem {
  id: string;
  date: string;
  time: string;
  platform: 'YouTube' | 'Facebook';
  channelId: string;
  channelName: string;
  conceptTitle: string;
  assignedCreatorId: string;
  assignedCreatorName: string;
  productionStatus: 'Planned' | 'In Production' | 'Ready' | 'Delayed';
  publishingStatus: 'Scheduled' | 'Published' | 'Draft';
  notes?: string;
}

export interface Message {
  id: string;
  senderId: string;
  senderName: string;
  senderRole: UserRole;
  senderAvatar?: string;
  recipientId: string;
  recipientName: string;
  content: string;
  attachmentUrl?: string;
  attachmentName?: string;
  createdAt: string;
  isRead: boolean;
}

export interface NotificationItem {
  id: string;
  type: 'submission' | 'approval' | 'revision' | 'deadline' | 'account_request' | 'assignment' | 'system';
  title: string;
  message: string;
  timestamp: string;
  isRead: boolean;
  linkTab?: string;
  targetId?: string;
}

export interface AccountChangeRequest {
  id: string;
  userId: string;
  userName: string;
  userRole: UserRole;
  requestType: 'Username Change' | 'Password Reset' | 'Email Change' | 'Profile Update';
  requestedChanges: {
    field: string;
    oldValue: string;
    newValue: string;
  }[];
  reason: string;
  status: 'Pending' | 'Approved' | 'Rejected';
  requestedAt: string;
  reviewedAt?: string;
  reviewedBy?: string;
  reviewNotes?: string;
}

export interface AuditLog {
  id: string;
  actorId: string;
  actorName: string;
  actorRole: UserRole;
  action: string;
  targetType: 'Project' | 'User' | 'MediaAsset' | 'ContentPlan' | 'AccountRequest' | 'Security';
  targetId: string;
  targetName: string;
  details: string;
  timestamp: string;
  ipAddress?: string;
}

export interface ScoringRule {
  id: string;
  name: string;
  description: string;
  pointsDelta: number;
  condition: string;
}

export interface PointAuditEntry {
  id: string;
  userId: string;
  userName: string;
  projectCode?: string;
  points: number;
  reason: string;
  adjustedBy: string;
  timestamp: string;
}
