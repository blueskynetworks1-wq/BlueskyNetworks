import React, { useState } from 'react';
import {
  ShieldCheck,
  Users,
  KeyRound,
  UserPlus,
  Lock,
  CheckCircle2,
  XCircle,
  FileText,
  AlertTriangle,
  Search,
  Filter,
  Eye,
  Check,
  X,
  History,
  ShieldAlert,
} from 'lucide-react';
import { User, AuditLog, AccountChangeRequest, UserRole } from '../../types';

interface AdminDashboardProps {
  users: User[];
  auditLogs: AuditLog[];
  accountRequests: AccountChangeRequest[];
  currentUser: User;
  onCreateUser: (
    userData: Omit<User, 'id' | 'points' | 'onTimeRate' | 'completedProjectsCount' | 'activeProjectsCount' | 'joinDate'>,
    initialPasswordSecure: string
  ) => void;
  onUpdateUserStatus: (userId: string, status: User['status']) => void;
  onResetPassword: (userId: string) => { tempResetToken: string };
  onReviewAccountRequest: (requestId: string, approved: boolean, notes: string) => void;
}

export const AdminDashboard: React.FC<AdminDashboardProps> = ({
  users,
  auditLogs,
  accountRequests,
  currentUser,
  onCreateUser,
  onUpdateUserStatus,
  onResetPassword,
  onReviewAccountRequest,
}) => {
  const [activeSection, setActiveSection] = useState<'users' | 'requests' | 'audit'>('users');
  const [isAddUserModalOpen, setIsAddUserModalOpen] = useState(false);

  // New user form state
  const [newName, setNewName] = useState('');
  const [newUsername, setNewUsername] = useState('');
  const [newEmail, setNewEmail] = useState('');
  const [newRole, setNewRole] = useState<UserRole>('member');
  const [newJobTitle, setNewJobTitle] = useState('Production Specialist');
  const [newDepartment, setNewDepartment] = useState('Video Production');
  const [newPassword, setNewPassword] = useState('');

  // Password reset token feedback
  const [tokenAlert, setTokenAlert] = useState<{ name: string; token: string } | null>(null);

  // Audit log filter
  const [auditSearch, setAuditSearch] = useState('');
  const [auditActionFilter, setAuditActionFilter] = useState('all');

  // Request review state
  const [reviewNotes, setReviewNotes] = useState('');

  const activeUsers = users.filter((u) => u.status === 'active').length;
  const pendingRequests = accountRequests.filter((r) => r.status === 'Pending');

  const filteredLogs = auditLogs.filter((log) => {
    const matchesSearch =
      log.actorName.toLowerCase().includes(auditSearch.toLowerCase()) ||
      log.targetName.toLowerCase().includes(auditSearch.toLowerCase()) ||
      log.details.toLowerCase().includes(auditSearch.toLowerCase()) ||
      log.targetId.toLowerCase().includes(auditSearch.toLowerCase());
    const matchesAction = auditActionFilter === 'all' || log.action === auditActionFilter;
    return matchesSearch && matchesAction;
  });

  const handleCreateUser = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newName.trim() || !newUsername.trim() || !newEmail.trim() || !newPassword.trim()) return;

    onCreateUser(
      {
        name: newName,
        username: newUsername,
        email: newEmail,
        role: newRole,
        jobTitle: newJobTitle,
        department: newDepartment,
        status: 'active',
      },
      newPassword
    );

    setIsAddUserModalOpen(false);
    setNewName('');
    setNewUsername('');
    setNewEmail('');
    setNewPassword('');
  };

  const handleReset = (user: User) => {
    const res = onResetPassword(user.id);
    setTokenAlert({ name: user.name, token: res.tempResetToken });
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-200">
      {/* Reset Token Banner */}
      {tokenAlert && (
        <div className="p-4 rounded-2xl bg-amber-500/10 border border-amber-500/30 text-amber-900 dark:text-amber-200 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <KeyRound className="h-5 w-5 text-amber-600 dark:text-amber-400 shrink-0" />
            <div className="text-xs">
              <div className="font-bold">
                Temporary Password Reset Token Generated for {tokenAlert.name}
              </div>
              <div className="text-[11px] text-amber-800/80 dark:text-amber-300/80">
                Single-use credential: <strong className="font-mono bg-white/60 dark:bg-black/40 px-2 py-0.5 rounded">{tokenAlert.token}</strong>. In accordance with zero-leak protocols, plain-text passwords are never revealed or stored.
              </div>
            </div>
          </div>
          <button
            onClick={() => setTokenAlert(null)}
            className="text-xs font-semibold px-3 py-1 rounded-lg bg-amber-600 text-white hover:bg-amber-700"
          >
            Dismiss
          </button>
        </div>
      )}

      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-lg font-bold text-slate-900 dark:text-white flex items-center gap-2">
            <ShieldCheck className="h-5 w-5 text-amber-500" />
            <span>Executive Governance & Administration</span>
          </h2>
          <p className="text-xs text-slate-500 dark:text-slate-400">
            Founder & CEO root controls: Account provisioning, sensitive approvals & immutable audit trail
          </p>
        </div>

        {/* Action Toggle Pills */}
        <div className="flex items-center gap-1 p-1 bg-slate-100 dark:bg-slate-800 rounded-xl text-xs">
          <button
            onClick={() => setActiveSection('users')}
            className={`px-3 py-1.5 rounded-lg font-medium transition-colors ${
              activeSection === 'users'
                ? 'bg-white dark:bg-slate-700 text-slate-900 dark:text-white shadow-xs'
                : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
            }`}
          >
            User Accounts ({users.length})
          </button>
          <button
            onClick={() => setActiveSection('requests')}
            className={`relative px-3 py-1.5 rounded-lg font-medium transition-colors ${
              activeSection === 'requests'
                ? 'bg-white dark:bg-slate-700 text-slate-900 dark:text-white shadow-xs'
                : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
            }`}
          >
            <span>Change Requests</span>
            {pendingRequests.length > 0 && (
              <span className="ml-1.5 px-1.5 py-0.2 rounded-full bg-indigo-600 text-white text-[10px] font-bold">
                {pendingRequests.length}
              </span>
            )}
          </button>
          <button
            onClick={() => setActiveSection('audit')}
            className={`px-3 py-1.5 rounded-lg font-medium transition-colors ${
              activeSection === 'audit'
                ? 'bg-white dark:bg-slate-700 text-slate-900 dark:text-white shadow-xs'
                : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
            }`}
          >
            Audit Logs ({auditLogs.length})
          </button>
        </div>
      </div>

      {/* SECTION 1: USER MANAGEMENT */}
      {activeSection === 'users' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <div className="text-xs text-slate-500">
              Active Authorized Staff: <strong className="text-slate-900 dark:text-white">{activeUsers}</strong> / {users.length}
            </div>
            <button
              onClick={() => setIsAddUserModalOpen(true)}
              className="flex items-center gap-1.5 rounded-xl bg-blue-600 px-3.5 py-2 text-xs font-semibold text-white hover:bg-blue-700 shadow-md shadow-blue-600/20 transition-all"
            >
              <UserPlus className="h-4 w-4" />
              <span>Provision User Account</span>
            </button>
          </div>

          <div className="rounded-2xl glass-card border border-slate-200/80 dark:border-slate-800 overflow-hidden shadow-xs">
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs border-collapse">
                <thead>
                  <tr className="border-b border-slate-200/70 bg-slate-50/70 dark:border-slate-800 dark:bg-slate-800/40 text-slate-400 font-semibold uppercase text-[10px] tracking-wider">
                    <th className="py-3 px-4">User</th>
                    <th className="py-3 px-4">Job Title & Dept</th>
                    <th className="py-3 px-4">Role</th>
                    <th className="py-3 px-4">Last Login</th>
                    <th className="py-3 px-4">Account Status</th>
                    <th className="py-3 px-4 text-right">Security Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 dark:divide-slate-800/60 font-medium">
                  {users.map((u) => (
                    <tr key={u.id} className="hover:bg-slate-50/50 dark:hover:bg-slate-800/30">
                      <td className="py-3.5 px-4">
                        <div className="flex items-center gap-2.5">
                          {u.avatarUrl ? (
                            <img
                              src={u.avatarUrl}
                              alt={u.name}
                              className="h-8 w-8 rounded-full object-cover ring-1 ring-slate-200 dark:ring-slate-700"
                            />
                          ) : (
                            <div className="flex h-8 w-8 items-center justify-center rounded-full bg-slate-100 dark:bg-slate-800 font-bold text-slate-700 dark:text-slate-300 text-xs">
                              {u.name.charAt(0)}
                            </div>
                          )}
                          <div>
                            <div className="font-semibold text-slate-900 dark:text-white">
                              {u.name}
                            </div>
                            <div className="text-[11px] text-slate-400 font-mono">
                              @{u.username} · {u.email}
                            </div>
                          </div>
                        </div>
                      </td>

                      <td className="py-3.5 px-4 text-slate-700 dark:text-slate-300">
                        <div>{u.jobTitle}</div>
                        <div className="text-[11px] text-slate-400">{u.department}</div>
                      </td>

                      <td className="py-3.5 px-4">
                        <span
                          className={`inline-block text-[10px] font-bold px-2 py-0.5 rounded-full ${
                            u.role === 'ceo'
                              ? 'bg-amber-100 text-amber-800 dark:bg-amber-950/60 dark:text-amber-300'
                              : u.role === 'manager'
                              ? 'bg-indigo-100 text-indigo-800 dark:bg-indigo-950/60 dark:text-indigo-300'
                              : 'bg-slate-100 text-slate-700 dark:bg-slate-800 dark:text-slate-300'
                          }`}
                        >
                          {u.role.toUpperCase()}
                        </span>
                      </td>

                      <td className="py-3.5 px-4 font-mono text-[11px] text-slate-400">
                        {u.lastLoginAt || '2026-11-07 18:00'}
                      </td>

                      <td className="py-3.5 px-4">
                        <span
                          className={`inline-block text-[10px] font-bold px-2 py-0.5 rounded-full ${
                            u.status === 'active'
                              ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950/60 dark:text-emerald-300'
                              : 'bg-rose-100 text-rose-800 dark:bg-rose-950/60 dark:text-rose-300'
                          }`}
                        >
                          {u.status}
                        </span>
                      </td>

                      <td className="py-3.5 px-4 text-right space-x-1.5">
                        <button
                          onClick={() => handleReset(u)}
                          className="px-2 py-1 rounded-lg border border-slate-200 text-slate-700 hover:bg-slate-100 dark:border-slate-700 dark:text-slate-300 dark:hover:bg-slate-800 text-[11px]"
                          title="Generate single-use reset credential"
                        >
                          Reset Pass
                        </button>
                        {u.role !== 'ceo' && (
                          <button
                            onClick={() =>
                              onUpdateUserStatus(
                                u.id,
                                u.status === 'active' ? 'suspended' : 'active'
                              )
                            }
                            className={`px-2 py-1 rounded-lg text-[11px] font-semibold ${
                              u.status === 'active'
                                ? 'text-rose-600 hover:bg-rose-50 dark:hover:bg-rose-950/40'
                                : 'text-emerald-600 hover:bg-emerald-50 dark:hover:bg-emerald-950/40'
                            }`}
                          >
                            {u.status === 'active' ? 'Deactivate' : 'Activate'}
                          </button>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* SECTION 2: SENSITIVE ACCOUNT CHANGE APPROVALS */}
      {activeSection === 'requests' && (
        <div className="space-y-4">
          <div className="p-4 rounded-2xl glass-card border border-slate-200/80 dark:border-slate-800 space-y-2">
            <h3 className="text-sm font-semibold text-slate-900 dark:text-white flex items-center gap-2">
              <ShieldAlert className="h-4 w-4 text-indigo-500" />
              <span>Sensitive Account Change Approvals Queue</span>
            </h3>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              In accordance with security directives, team members cannot alter emails, usernames, or security credentials independently. The CEO must explicitly approve or deny each request.
            </p>
          </div>

          <div className="space-y-3">
            {accountRequests.length === 0 ? (
              <div className="p-8 rounded-2xl glass-card border border-slate-200/80 dark:border-slate-800 text-center text-xs text-slate-400">
                No account change requests pending review.
              </div>
            ) : (
              accountRequests.map((req) => (
                <div
                  key={req.id}
                  className="p-5 rounded-2xl glass-card border border-slate-200/80 dark:border-slate-800 space-y-3"
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <span className="text-xs font-bold text-slate-900 dark:text-white">
                        {req.userName}
                      </span>
                      <span className="text-[10px] text-slate-400 font-mono">
                        ({req.userRole.toUpperCase()})
                      </span>
                      <span className="text-xs text-slate-400">· Requested: {req.requestType}</span>
                    </div>
                    <span
                      className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                        req.status === 'Pending'
                          ? 'bg-indigo-100 text-indigo-800 dark:bg-indigo-950/60 dark:text-indigo-300'
                          : req.status === 'Approved'
                          ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950/60 dark:text-emerald-300'
                          : 'bg-rose-100 text-rose-800 dark:bg-rose-950/60 dark:text-rose-300'
                      }`}
                    >
                      {req.status}
                    </span>
                  </div>

                  <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/40 border border-slate-100 dark:border-slate-800 text-xs space-y-1">
                    <div className="font-semibold text-slate-700 dark:text-slate-300">
                      Proposed Modifications:
                    </div>
                    {req.requestedChanges.map((ch, idx) => (
                      <div key={idx} className="font-mono text-[11px] text-slate-600 dark:text-slate-400">
                        {ch.field}: <span className="line-through text-rose-500">{ch.oldValue}</span> → <span className="text-emerald-500 font-bold">{ch.newValue}</span>
                      </div>
                    ))}
                    <div className="text-[11px] text-slate-500 italic pt-1">
                      Reason: "{req.reason}"
                    </div>
                  </div>

                  {req.status === 'Pending' && (
                    <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-100 dark:border-slate-800">
                      <button
                        onClick={() => onReviewAccountRequest(req.id, false, 'Denied by CEO')}
                        className="px-3 py-1.5 rounded-xl border border-rose-300 bg-rose-50 text-rose-700 hover:bg-rose-100 dark:border-rose-900 dark:bg-rose-950/40 dark:text-rose-300 text-xs font-semibold"
                      >
                        Reject Request
                      </button>
                      <button
                        onClick={() => onReviewAccountRequest(req.id, true, 'Approved by CEO')}
                        className="px-4 py-1.5 rounded-xl bg-emerald-600 text-white hover:bg-emerald-700 text-xs font-semibold shadow-xs"
                      >
                        Approve & Apply Changes
                      </button>
                    </div>
                  )}
                </div>
              ))
            )}
          </div>
        </div>
      )}

      {/* SECTION 3: IMMUTABLE AUDIT LOGS */}
      {activeSection === 'audit' && (
        <div className="space-y-4">
          <div className="p-4 rounded-2xl glass-card border border-slate-200/80 dark:border-slate-800 flex flex-col sm:flex-row items-center justify-between gap-3">
            <div className="relative w-full sm:w-72">
              <Search className="absolute left-3 top-2.5 h-3.5 w-3.5 text-slate-400" />
              <input
                type="text"
                placeholder="Search audit trail..."
                value={auditSearch}
                onChange={(e) => setAuditSearch(e.target.value)}
                className="w-full rounded-xl border border-slate-200/80 bg-white pl-8 pr-3 py-1.5 text-xs text-slate-900 focus:outline-hidden dark:border-slate-700 dark:bg-slate-800 dark:text-white"
              />
            </div>

            <div className="flex items-center gap-2 self-start sm:self-auto text-xs">
              <span className="text-slate-400 font-medium">Action:</span>
              <select
                value={auditActionFilter}
                onChange={(e) => setAuditActionFilter(e.target.value)}
                className="rounded-xl border border-slate-200/80 bg-white px-3 py-1.5 text-xs text-slate-700 focus:outline-hidden dark:border-slate-700 dark:bg-slate-800 dark:text-slate-300"
              >
                <option value="all">All Actions</option>
                <option value="CREATE_PROJECT">Create Project</option>
                <option value="STAGE_UPDATE">Stage Update</option>
                <option value="SUBMIT_PROJECT">Submit Project</option>
                <option value="APPROVE_PROJECT">Approve Project</option>
                <option value="REQUEST_REVISION">Request Revision</option>
                <option value="CREATE_USER">Create User</option>
                <option value="RESET_PASSWORD">Reset Password</option>
                <option value="ADJUST_POINTS">Adjust Points</option>
              </select>
            </div>
          </div>

          <div className="rounded-2xl glass-card border border-slate-200/80 dark:border-slate-800 overflow-hidden shadow-xs">
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs border-collapse">
                <thead>
                  <tr className="border-b border-slate-200/70 bg-slate-50/70 dark:border-slate-800 dark:bg-slate-800/40 text-slate-400 font-semibold uppercase text-[10px] tracking-wider">
                    <th className="py-3 px-4">Timestamp</th>
                    <th className="py-3 px-4">Actor</th>
                    <th className="py-3 px-4">Action</th>
                    <th className="py-3 px-4">Target Ref</th>
                    <th className="py-3 px-4">Operational Details</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 dark:divide-slate-800/60 font-medium font-mono text-[11px]">
                  {filteredLogs.map((log) => (
                    <tr key={log.id} className="hover:bg-slate-50/50 dark:hover:bg-slate-800/30">
                      <td className="py-3 px-4 text-slate-400 whitespace-nowrap">
                        {log.timestamp}
                      </td>

                      <td className="py-3 px-4 text-slate-900 dark:text-white font-sans font-bold whitespace-nowrap">
                        {log.actorName} ({log.actorRole.toUpperCase()})
                      </td>

                      <td className="py-3 px-4">
                        <span className="font-bold text-blue-600 dark:text-blue-400">
                          {log.action}
                        </span>
                      </td>

                      <td className="py-3 px-4 text-slate-700 dark:text-slate-300">
                        {log.targetType}: <strong className="text-slate-900 dark:text-white">{log.targetId}</strong>
                      </td>

                      <td className="py-3 px-4 font-sans text-slate-600 dark:text-slate-300">
                        {log.details}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* Add User Modal */}
      {isAddUserModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-md animate-in fade-in duration-100">
          <div className="w-full max-w-lg rounded-2xl border border-slate-200/90 bg-white p-6 shadow-2xl dark:border-slate-800 dark:bg-slate-900">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800">
              <h3 className="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-2">
                <UserPlus className="h-4 w-4 text-blue-600" />
                <span>Provision New Employee Account</span>
              </h3>
              <button
                onClick={() => setIsAddUserModalOpen(false)}
                className="text-slate-400 hover:text-slate-600 dark:hover:text-slate-200"
              >
                <X className="h-4 w-4" />
              </button>
            </div>

            <form onSubmit={handleCreateUser} className="mt-4 space-y-3.5 text-xs">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-[11px] font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    Full Name *
                  </label>
                  <input
                    type="text"
                    placeholder="e.g. Ruwanthi Jayasuriya"
                    value={newName}
                    onChange={(e) => setNewName(e.target.value)}
                    required
                    className="w-full rounded-xl border border-slate-200 bg-white px-3 py-2 text-xs text-slate-900 focus:outline-hidden dark:border-slate-700 dark:bg-slate-800 dark:text-white"
                  />
                </div>
                <div>
                  <label className="block text-[11px] font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    System Username *
                  </label>
                  <input
                    type="text"
                    placeholder="e.g. ruwanthi"
                    value={newUsername}
                    onChange={(e) => setNewUsername(e.target.value)}
                    required
                    className="w-full rounded-xl border border-slate-200 bg-white px-3 py-2 text-xs text-slate-900 focus:outline-hidden dark:border-slate-700 dark:bg-slate-800 dark:text-white font-mono"
                  />
                </div>
              </div>

              <div>
                <label className="block text-[11px] font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  Company Email *
                </label>
                <input
                  type="email"
                  placeholder="ruwanthi@blueskynetworks.com"
                  value={newEmail}
                  onChange={(e) => setNewEmail(e.target.value)}
                  required
                  className="w-full rounded-xl border border-slate-200 bg-white px-3 py-2 text-xs text-slate-900 focus:outline-hidden dark:border-slate-700 dark:bg-slate-800 dark:text-white"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-[11px] font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    Job Title
                  </label>
                  <input
                    type="text"
                    value={newJobTitle}
                    onChange={(e) => setNewJobTitle(e.target.value)}
                    className="w-full rounded-xl border border-slate-200 bg-white px-3 py-2 text-xs text-slate-900 focus:outline-hidden dark:border-slate-700 dark:bg-slate-800 dark:text-white"
                  />
                </div>
                <div>
                  <label className="block text-[11px] font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    Role & Permissions
                  </label>
                  <select
                    value={newRole}
                    onChange={(e) => setNewRole(e.target.value as UserRole)}
                    className="w-full rounded-xl border border-slate-200 bg-white px-3 py-2 text-xs text-slate-900 focus:outline-hidden dark:border-slate-700 dark:bg-slate-800 dark:text-white"
                  >
                    <option value="member">Team Member (Private Assignments Only)</option>
                    <option value="manager">Manager (Production & Review Rights)</option>
                    <option value="ceo">CEO (Unrestricted Admin)</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-[11px] font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  Initial Password Provisioning (Masked) *
                </label>
                <input
                  type="password"
                  placeholder="Set initial password (user forced to change upon first login)"
                  value={newPassword}
                  onChange={(e) => setNewPassword(e.target.value)}
                  required
                  className="w-full rounded-xl border border-slate-200 bg-white px-3 py-2 text-xs text-slate-900 focus:outline-hidden dark:border-slate-700 dark:bg-slate-800 dark:text-white font-mono"
                />
                <p className="text-[10px] text-slate-400 mt-1">
                  Zero plain-text password policy: Initial password will be salted and forced to change on first login.
                </p>
              </div>

              <div className="pt-3 border-t border-slate-100 dark:border-slate-800 flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsAddUserModalOpen(false)}
                  className="rounded-xl border border-slate-200 px-3.5 py-2 text-slate-600 hover:bg-slate-100 dark:border-slate-700 dark:text-slate-300"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="rounded-xl bg-blue-600 px-4 py-2 font-semibold text-white hover:bg-blue-700 transition-colors shadow-xs"
                >
                  Create & Provision Account
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
