import React, { useState } from 'react';
import {
  Calendar as CalendarIcon,
  Plus,
  Clock,
  Tv,
  Users,
  ChevronLeft,
  ChevronRight,
  Video,
  Copy,
  Trash2,
  X,
  Edit2,
  CheckCircle2,
} from 'lucide-react';
import { ContentPlanItem, User, MediaAsset } from '../../types';

interface ContentCalendarViewProps {
  contentPlans: ContentPlanItem[];
  mediaAssets: MediaAsset[];
  users: User[];
  currentUser: User;
  onCreatePlan: (plan: Omit<ContentPlanItem, 'id'>) => void;
  onUpdatePlan: (plan: ContentPlanItem) => void;
  onDeletePlan: (id: string) => void;
}

export const ContentCalendarView: React.FC<ContentCalendarViewProps> = ({
  contentPlans,
  mediaAssets,
  users,
  currentUser,
  onCreatePlan,
  onUpdatePlan,
  onDeletePlan,
}) => {
  const [viewMode, setViewMode] = useState<'month' | 'week' | 'day'>('month');
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingPlan, setEditingPlan] = useState<ContentPlanItem | null>(null);

  // Form states
  const [conceptTitle, setConceptTitle] = useState('');
  const [platform, setPlatform] = useState<'YouTube' | 'Facebook'>('YouTube');
  const [channelId, setChannelId] = useState(mediaAssets[0]?.id || 'chan-1');
  const [date, setDate] = useState('2026-11-16');
  const [time, setTime] = useState('18:00');
  const [assignedCreatorId, setAssignedCreatorId] = useState(users.find((u) => u.role === 'member')?.id || 'u-kaveen');
  const [productionStatus, setProductionStatus] = useState<ContentPlanItem['productionStatus']>('Planned');
  const [publishingStatus, setPublishingStatus] = useState<ContentPlanItem['publishingStatus']>('Scheduled');
  const [notes, setNotes] = useState('');

  const openNewModal = () => {
    setEditingPlan(null);
    setConceptTitle('');
    setDate('2026-11-16');
    setTime('18:00');
    setNotes('');
    setProductionStatus('Planned');
    setPublishingStatus('Scheduled');
    setIsModalOpen(true);
  };

  const openEditModal = (plan: ContentPlanItem) => {
    setEditingPlan(plan);
    setConceptTitle(plan.conceptTitle);
    setPlatform(plan.platform);
    setChannelId(plan.channelId);
    setDate(plan.date);
    setTime(plan.time);
    setAssignedCreatorId(plan.assignedCreatorId);
    setProductionStatus(plan.productionStatus);
    setPublishingStatus(plan.publishingStatus);
    setNotes(plan.notes || '');
    setIsModalOpen(true);
  };

  const handleDuplicate = (plan: ContentPlanItem) => {
    onCreatePlan({
      ...plan,
      conceptTitle: `${plan.conceptTitle} (Duplicate)`,
      publishingStatus: 'Draft',
    });
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!conceptTitle.trim()) return;

    const channel = mediaAssets.find((m) => m.id === channelId);
    const creator = users.find((u) => u.id === assignedCreatorId);

    const payload = {
      conceptTitle,
      platform,
      channelId,
      channelName: channel?.name || 'Bluesky Channel',
      date,
      time,
      assignedCreatorId,
      assignedCreatorName: creator?.name || 'Creator',
      productionStatus,
      publishingStatus,
      notes,
    };

    if (editingPlan) {
      onUpdatePlan({ ...editingPlan, ...payload });
    } else {
      onCreatePlan(payload);
    }

    setIsModalOpen(false);
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-200">
      {/* Header and View Selector */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-lg font-bold text-slate-900 dark:text-white flex items-center gap-2">
            <CalendarIcon className="h-5 w-5 text-blue-600" />
            <span>Future Content Planner & Editorial Calendar</span>
          </h2>
          <p className="text-xs text-slate-500 dark:text-slate-400">
            Publishing schedules, creator allocation, and release pipelines
          </p>
        </div>

        <div className="flex items-center gap-2">
          {/* Daily/Weekly/Monthly Switcher */}
          <div className="flex items-center gap-1 p-1 bg-slate-100 dark:bg-slate-800 rounded-xl text-xs">
            <button
              onClick={() => setViewMode('day')}
              className={`px-3 py-1.5 rounded-lg font-medium transition-colors ${
                viewMode === 'day'
                  ? 'bg-white dark:bg-slate-700 text-slate-900 dark:text-white shadow-xs'
                  : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
              }`}
            >
              Daily
            </button>
            <button
              onClick={() => setViewMode('week')}
              className={`px-3 py-1.5 rounded-lg font-medium transition-colors ${
                viewMode === 'week'
                  ? 'bg-white dark:bg-slate-700 text-slate-900 dark:text-white shadow-xs'
                  : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
              }`}
            >
              Weekly
            </button>
            <button
              onClick={() => setViewMode('month')}
              className={`px-3 py-1.5 rounded-lg font-medium transition-colors ${
                viewMode === 'month'
                  ? 'bg-white dark:bg-slate-700 text-slate-900 dark:text-white shadow-xs'
                  : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
              }`}
            >
              Monthly
            </button>
          </div>

          <button
            onClick={openNewModal}
            className="flex items-center gap-1.5 rounded-xl bg-blue-600 px-3.5 py-2 text-xs font-semibold text-white hover:bg-blue-700 shadow-md shadow-blue-600/20 transition-all"
          >
            <Plus className="h-3.5 w-3.5" />
            <span>Schedule Release</span>
          </button>
        </div>
      </div>

      {/* Content Calendar List / Grid */}
      <div className="space-y-3">
        {contentPlans.map((plan) => (
          <div
            key={plan.id}
            className="p-4 rounded-2xl glass-card border border-slate-200/80 dark:border-slate-800 flex flex-col md:flex-row md:items-center justify-between gap-4 hover:border-blue-400 dark:hover:border-blue-600 transition-all"
          >
            <div className="flex items-start gap-3.5">
              <div className="flex flex-col items-center justify-center h-14 w-14 rounded-xl bg-blue-50 border border-blue-200/60 dark:bg-blue-950/40 dark:border-blue-900/40 shrink-0">
                <span className="text-[10px] uppercase font-bold text-blue-600 dark:text-blue-400">
                  {new Date(plan.date).toLocaleString('default', { month: 'short' })}
                </span>
                <span className="text-lg font-bold text-slate-900 dark:text-white font-mono tabular-nums leading-tight">
                  {new Date(plan.date).getDate()}
                </span>
              </div>

              <div className="space-y-1">
                <div className="flex items-center gap-2">
                  <span
                    className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                      plan.platform === 'YouTube'
                        ? 'bg-red-50 text-red-700 dark:bg-red-950/50 dark:text-red-300'
                        : 'bg-blue-50 text-blue-700 dark:bg-blue-950/50 dark:text-blue-300'
                    }`}
                  >
                    {plan.platform}
                  </span>
                  <span className="text-xs font-semibold text-slate-600 dark:text-slate-300">
                    {plan.channelName}
                  </span>
                  <span className="text-xs text-slate-400">· {plan.time}</span>
                </div>

                <h4 className="text-sm font-bold text-slate-900 dark:text-white">
                  {plan.conceptTitle}
                </h4>

                <div className="flex items-center gap-3 text-xs text-slate-500 dark:text-slate-400">
                  <span>Creator: <strong className="text-slate-700 dark:text-slate-200">{plan.assignedCreatorName}</strong></span>
                  {plan.notes && <span>· "{plan.notes}"</span>}
                </div>
              </div>
            </div>

            <div className="flex items-center gap-3 self-end md:self-center">
              {/* Production Status */}
              <span
                className={`text-[11px] font-semibold px-2.5 py-1 rounded-lg ${
                  plan.productionStatus === 'Ready'
                    ? 'bg-emerald-50 text-emerald-700 dark:bg-emerald-950/50 dark:text-emerald-300 border border-emerald-200 dark:border-emerald-800'
                    : plan.productionStatus === 'In Production'
                    ? 'bg-blue-50 text-blue-700 dark:bg-blue-950/50 dark:text-blue-300 border border-blue-200 dark:border-blue-800'
                    : 'bg-slate-100 text-slate-700 dark:bg-slate-800 dark:text-slate-300'
                }`}
              >
                {plan.productionStatus}
              </span>

              {/* Publishing Status */}
              <span
                className={`text-[11px] font-bold px-2.5 py-1 rounded-lg ${
                  plan.publishingStatus === 'Scheduled'
                    ? 'bg-indigo-50 text-indigo-700 dark:bg-indigo-950/50 dark:text-indigo-300 border border-indigo-200 dark:border-indigo-800'
                    : plan.publishingStatus === 'Published'
                    ? 'bg-emerald-600 text-white shadow-xs'
                    : 'bg-slate-100 text-slate-600 dark:bg-slate-800 dark:text-slate-400'
                }`}
              >
                {plan.publishingStatus}
              </span>

              {/* Quick Actions */}
              <div className="flex items-center gap-1 border-l border-slate-200 dark:border-slate-800 pl-3">
                <button
                  onClick={() => openEditModal(plan)}
                  className="p-1.5 rounded-lg text-slate-400 hover:text-slate-700 hover:bg-slate-100 dark:hover:bg-slate-800 dark:hover:text-slate-200"
                  title="Edit Plan"
                >
                  <Edit2 className="h-3.5 w-3.5" />
                </button>
                <button
                  onClick={() => handleDuplicate(plan)}
                  className="p-1.5 rounded-lg text-slate-400 hover:text-slate-700 hover:bg-slate-100 dark:hover:bg-slate-800 dark:hover:text-slate-200"
                  title="Duplicate Plan"
                >
                  <Copy className="h-3.5 w-3.5" />
                </button>
                <button
                  onClick={() => {
                    if (confirm('Delete this scheduled release?')) {
                      onDeletePlan(plan.id);
                    }
                  }}
                  className="p-1.5 rounded-lg text-slate-400 hover:text-rose-500 hover:bg-rose-50 dark:hover:bg-rose-950/40"
                  title="Delete Plan"
                >
                  <Trash2 className="h-3.5 w-3.5" />
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Schedule / Edit Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-md animate-in fade-in duration-100">
          <div className="w-full max-w-lg rounded-2xl border border-slate-200/90 bg-white p-6 shadow-2xl dark:border-slate-800 dark:bg-slate-900">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800">
              <h3 className="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-2">
                <CalendarIcon className="h-4 w-4 text-blue-600" />
                <span>{editingPlan ? 'Edit Content Schedule' : 'Schedule New Video Release'}</span>
              </h3>
              <button
                onClick={() => setIsModalOpen(false)}
                className="text-slate-400 hover:text-slate-600 dark:hover:text-slate-200"
              >
                <X className="h-4 w-4" />
              </button>
            </div>

            <form onSubmit={handleSubmit} className="mt-4 space-y-3.5 text-xs">
              <div>
                <label className="block text-[11px] font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  Video Concept Title *
                </label>
                <input
                  type="text"
                  placeholder="e.g. Next-Gen Nuclear Batteries: 50-Year Power Cells"
                  value={conceptTitle}
                  onChange={(e) => setConceptTitle(e.target.value)}
                  required
                  className="w-full rounded-xl border border-slate-200 bg-white px-3 py-2 text-xs text-slate-900 focus:outline-hidden dark:border-slate-700 dark:bg-slate-800 dark:text-white"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-[11px] font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    Platform
                  </label>
                  <select
                    value={platform}
                    onChange={(e) => setPlatform(e.target.value as any)}
                    className="w-full rounded-xl border border-slate-200 bg-white px-3 py-2 text-xs text-slate-900 focus:outline-hidden dark:border-slate-700 dark:bg-slate-800 dark:text-white"
                  >
                    <option value="YouTube">YouTube</option>
                    <option value="Facebook">Facebook</option>
                  </select>
                </div>
                <div>
                  <label className="block text-[11px] font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    Channel / Page
                  </label>
                  <select
                    value={channelId}
                    onChange={(e) => setChannelId(e.target.value)}
                    className="w-full rounded-xl border border-slate-200 bg-white px-3 py-2 text-xs text-slate-900 focus:outline-hidden dark:border-slate-700 dark:bg-slate-800 dark:text-white"
                  >
                    {mediaAssets.map((m) => (
                      <option key={m.id} value={m.id}>
                        {m.name}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-[11px] font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    Release Date
                  </label>
                  <input
                    type="date"
                    value={date}
                    onChange={(e) => setDate(e.target.value)}
                    required
                    className="w-full rounded-xl border border-slate-200 bg-white px-3 py-2 text-xs text-slate-900 focus:outline-hidden dark:border-slate-700 dark:bg-slate-800 dark:text-white"
                  />
                </div>
                <div>
                  <label className="block text-[11px] font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    Publish Time
                  </label>
                  <input
                    type="time"
                    value={time}
                    onChange={(e) => setTime(e.target.value)}
                    required
                    className="w-full rounded-xl border border-slate-200 bg-white px-3 py-2 text-xs text-slate-900 focus:outline-hidden dark:border-slate-700 dark:bg-slate-800 dark:text-white"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-[11px] font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    Assigned Creator
                  </label>
                  <select
                    value={assignedCreatorId}
                    onChange={(e) => setAssignedCreatorId(e.target.value)}
                    className="w-full rounded-xl border border-slate-200 bg-white px-3 py-2 text-xs text-slate-900 focus:outline-hidden dark:border-slate-700 dark:bg-slate-800 dark:text-white"
                  >
                    {users.map((u) => (
                      <option key={u.id} value={u.id}>
                        {u.name}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-[11px] font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    Publishing Status
                  </label>
                  <select
                    value={publishingStatus}
                    onChange={(e) => setPublishingStatus(e.target.value as any)}
                    className="w-full rounded-xl border border-slate-200 bg-white px-3 py-2 text-xs text-slate-900 focus:outline-hidden dark:border-slate-700 dark:bg-slate-800 dark:text-white"
                  >
                    <option value="Scheduled">Scheduled</option>
                    <option value="Draft">Draft</option>
                    <option value="Published">Published</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-[11px] font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  Editorial Notes
                </label>
                <textarea
                  rows={2}
                  placeholder="Promotional hooks, thumbnail guidelines, cross-posting reminders..."
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  className="w-full rounded-xl border border-slate-200 bg-white px-3 py-2 text-xs text-slate-900 focus:outline-hidden dark:border-slate-700 dark:bg-slate-800 dark:text-white"
                />
              </div>

              <div className="pt-3 border-t border-slate-100 dark:border-slate-800 flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="rounded-xl border border-slate-200 px-3.5 py-2 text-slate-600 hover:bg-slate-100 dark:border-slate-700 dark:text-slate-300"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="rounded-xl bg-blue-600 px-4 py-2 font-semibold text-white hover:bg-blue-700 transition-colors shadow-xs"
                >
                  {editingPlan ? 'Save Changes' : 'Schedule Content'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
