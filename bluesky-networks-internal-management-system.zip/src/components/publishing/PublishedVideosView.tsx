import React, { useState } from 'react';
import {
  Video,
  Plus,
  Search,
  ExternalLink,
  Eye,
  TrendingUp,
  Tv,
  Calendar,
  X,
} from 'lucide-react';
import { PublishedVideo, MediaAsset, User } from '../../types';

interface PublishedVideosViewProps {
  publishedVideos: PublishedVideo[];
  mediaAssets: MediaAsset[];
  currentUser: User;
  onCreatePublishedVideo: (video: Omit<PublishedVideo, 'id'>) => void;
}

export const PublishedVideosView: React.FC<PublishedVideosViewProps> = ({
  publishedVideos,
  mediaAssets,
  currentUser,
  onCreatePublishedVideo,
}) => {
  const [search, setSearch] = useState('');
  const [platformFilter, setPlatformFilter] = useState('all');
  const [isModalOpen, setIsModalOpen] = useState(false);

  // New video record form
  const [title, setTitle] = useState('');
  const [platform, setPlatform] = useState<'YouTube' | 'Facebook'>('YouTube');
  const [channelId, setChannelId] = useState(mediaAssets[0]?.id || 'chan-1');
  const [publishedDate, setPublishedDate] = useState(new Date().toISOString().substring(0, 10));
  const [publishedTime, setPublishedTime] = useState('16:00');
  const [projectCode, setProjectCode] = useState('BSN-1084');
  const [videoUrl, setVideoUrl] = useState('');
  const [category, setCategory] = useState('Tech Explainer');
  const [views, setViews] = useState(50000);
  const [engagementRate, setEngagementRate] = useState(8.5);
  const [notes, setNotes] = useState('');

  const filteredVideos = publishedVideos.filter((v) => {
    const matchesSearch =
      v.title.toLowerCase().includes(search.toLowerCase()) ||
      v.projectCode.toLowerCase().includes(search.toLowerCase()) ||
      v.channelName.toLowerCase().includes(search.toLowerCase());
    const matchesPlatform = platformFilter === 'all' || v.platform === platformFilter;
    return matchesSearch && matchesPlatform;
  });

  const totalViews = publishedVideos.reduce((a, b) => a + b.views, 0);
  const avgEngagement = (
    publishedVideos.reduce((a, b) => a + b.engagementRate, 0) / (publishedVideos.length || 1)
  ).toFixed(1);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim() || !videoUrl.trim()) return;

    const channel = mediaAssets.find((m) => m.id === channelId);

    onCreatePublishedVideo({
      title,
      platform,
      channelId,
      channelName: channel?.name || 'Bluesky Channel',
      publishedDate,
      publishedTime,
      projectCode,
      videoUrl,
      category,
      views,
      engagementRate,
      notes,
    });

    setIsModalOpen(false);
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-200">
      {/* Header and Stats */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-lg font-bold text-slate-900 dark:text-white flex items-center gap-2">
            <Video className="h-5 w-5 text-blue-600" />
            <span>Published Video Catalog & Release Archive</span>
          </h2>
          <p className="text-xs text-slate-500 dark:text-slate-400">
            Historical repository of public media deliverables and performance reach
          </p>
        </div>

        <button
          onClick={() => setIsModalOpen(true)}
          className="flex items-center gap-1.5 rounded-xl bg-blue-600 px-3.5 py-2 text-xs font-semibold text-white hover:bg-blue-700 shadow-md shadow-blue-600/20 transition-all self-start sm:self-auto"
        >
          <Plus className="h-4 w-4" />
          <span>Record Published Release</span>
        </button>
      </div>

      {/* KPI Top Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="p-4 rounded-2xl glass-card border border-slate-200/80 dark:border-slate-800">
          <div className="text-xs text-slate-400 font-medium">Total Catalog Releases</div>
          <div className="text-2xl font-bold text-slate-900 dark:text-white mt-1 tabular-nums">
            {publishedVideos.length} videos
          </div>
          <div className="text-[11px] text-slate-400 mt-1">Archived across all channels</div>
        </div>

        <div className="p-4 rounded-2xl glass-card border border-slate-200/80 dark:border-slate-800">
          <div className="text-xs text-slate-400 font-medium">Combined Organic Views</div>
          <div className="text-2xl font-bold text-blue-600 dark:text-blue-400 mt-1 tabular-nums">
            {(totalViews / 1000000).toFixed(2)}M
          </div>
          <div className="text-[11px] text-emerald-600 dark:text-emerald-400 mt-1">
            +18% month-over-month growth
          </div>
        </div>

        <div className="p-4 rounded-2xl glass-card border border-slate-200/80 dark:border-slate-800">
          <div className="text-xs text-slate-400 font-medium">Avg Viewer Engagement</div>
          <div className="text-2xl font-bold text-emerald-600 dark:text-emerald-400 mt-1 tabular-nums">
            {avgEngagement}%
          </div>
          <div className="text-[11px] text-slate-400 mt-1">Likes, comments & shares</div>
        </div>
      </div>

      {/* Search and Filters */}
      <div className="p-4 rounded-2xl glass-card border border-slate-200/80 dark:border-slate-800 flex flex-col sm:flex-row items-center justify-between gap-3">
        <div className="relative w-full sm:w-72">
          <Search className="absolute left-3 top-2.5 h-3.5 w-3.5 text-slate-400" />
          <input
            type="text"
            placeholder="Search published titles, codes..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full rounded-xl border border-slate-200/80 bg-white pl-8 pr-3 py-1.5 text-xs text-slate-900 focus:outline-hidden dark:border-slate-700 dark:bg-slate-800 dark:text-white"
          />
        </div>

        <div className="flex items-center gap-2 self-start sm:self-auto">
          <select
            value={platformFilter}
            onChange={(e) => setPlatformFilter(e.target.value)}
            className="rounded-xl border border-slate-200/80 bg-white px-3 py-1.5 text-xs text-slate-700 focus:outline-hidden dark:border-slate-700 dark:bg-slate-800 dark:text-slate-300"
          >
            <option value="all">All Platforms</option>
            <option value="YouTube">YouTube</option>
            <option value="Facebook">Facebook</option>
          </select>
        </div>
      </div>

      {/* Video Releases Table */}
      <div className="rounded-2xl glass-card border border-slate-200/80 dark:border-slate-800 overflow-hidden shadow-xs">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse">
            <thead>
              <tr className="border-b border-slate-200/70 bg-slate-50/70 dark:border-slate-800 dark:bg-slate-800/40 text-slate-400 font-semibold uppercase text-[10px] tracking-wider">
                <th className="py-3 px-4">Title & Project Ref</th>
                <th className="py-3 px-4">Channel / Page</th>
                <th className="py-3 px-4">Release Date</th>
                <th className="py-3 px-4">Category</th>
                <th className="py-3 px-4">Views</th>
                <th className="py-3 px-4">Engagement</th>
                <th className="py-3 px-4 text-right">Watch</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800/60 font-medium">
              {filteredVideos.map((video) => (
                <tr key={video.id} className="hover:bg-slate-50/50 dark:hover:bg-slate-800/30 transition-colors">
                  <td className="py-3.5 px-4 max-w-sm">
                    <div className="font-semibold text-slate-900 dark:text-white line-clamp-1 mb-0.5">
                      {video.title}
                    </div>
                    <div className="flex items-center gap-2 text-[11px] text-slate-400">
                      <span className="font-mono text-blue-600 dark:text-blue-400 font-bold">
                        {video.projectCode}
                      </span>
                      {video.notes && <span>· "{video.notes}"</span>}
                    </div>
                  </td>

                  <td className="py-3.5 px-4">
                    <div className="font-medium text-slate-800 dark:text-slate-200">
                      {video.channelName}
                    </div>
                    <span
                      className={`inline-block text-[9px] font-bold px-1.5 py-0.5 rounded-sm ${
                        video.platform === 'YouTube'
                          ? 'bg-red-50 text-red-700 dark:bg-red-950/50 dark:text-red-300'
                          : 'bg-blue-50 text-blue-700 dark:bg-blue-950/50 dark:text-blue-300'
                      }`}
                    >
                      {video.platform}
                    </span>
                  </td>

                  <td className="py-3.5 px-4 font-mono text-[11px] text-slate-500 dark:text-slate-400 tabular-nums">
                    {video.publishedDate} {video.publishedTime}
                  </td>

                  <td className="py-3.5 px-4 text-slate-600 dark:text-slate-300">
                    {video.category}
                  </td>

                  <td className="py-3.5 px-4 font-mono font-bold text-slate-900 dark:text-white tabular-nums">
                    {video.views.toLocaleString()}
                  </td>

                  <td className="py-3.5 px-4 font-mono font-bold text-emerald-600 dark:text-emerald-400 tabular-nums">
                    {video.engagementRate}%
                  </td>

                  <td className="py-3.5 px-4 text-right">
                    <a
                      href={video.videoUrl}
                      target="_blank"
                      rel="noreferrer"
                      className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg border border-slate-200 hover:bg-slate-100 dark:border-slate-700 dark:hover:bg-slate-800 text-slate-700 dark:text-slate-300 font-semibold"
                    >
                      <span>Link</span>
                      <ExternalLink className="h-3 w-3" />
                    </a>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Record Published Release Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-md animate-in fade-in duration-100">
          <div className="w-full max-w-lg rounded-2xl border border-slate-200/90 bg-white p-6 shadow-2xl dark:border-slate-800 dark:bg-slate-900">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800">
              <h3 className="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-2">
                <Video className="h-4 w-4 text-blue-600" />
                <span>Archive Published Video Release</span>
              </h3>
              <button
                onClick={() => setIsModalOpen(false)}
                className="text-slate-400 hover:text-slate-600 dark:hover:text-slate-200"
              >
                <X className="h-4 w-4" />
              </button>
            </div>

            <form onSubmit={handleSubmit} className="mt-4 space-y-3.5 text-xs">
              <div>
                <label className="block text-[11px] font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  Published Video Title *
                </label>
                <input
                  type="text"
                  placeholder="Official video title on platform..."
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  required
                  className="w-full rounded-xl border border-slate-200 bg-white px-3 py-2 text-xs text-slate-900 focus:outline-hidden dark:border-slate-700 dark:bg-slate-800 dark:text-white"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-[11px] font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    Platform
                  </label>
                  <select
                    value={platform}
                    onChange={(e) => setPlatform(e.target.value as any)}
                    className="w-full rounded-xl border border-slate-200 bg-white px-3 py-2 text-xs text-slate-900 focus:outline-hidden dark:border-slate-700 dark:bg-slate-800 dark:text-white"
                  >
                    <option value="YouTube">YouTube</option>
                    <option value="Facebook">Facebook</option>
                  </select>
                </div>
                <div>
                  <label className="block text-[11px] font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    Channel / Page
                  </label>
                  <select
                    value={channelId}
                    onChange={(e) => setChannelId(e.target.value)}
                    className="w-full rounded-xl border border-slate-200 bg-white px-3 py-2 text-xs text-slate-900 focus:outline-hidden dark:border-slate-700 dark:bg-slate-800 dark:text-white"
                  >
                    {mediaAssets.map((m) => (
                      <option key={m.id} value={m.id}>
                        {m.name}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-[11px] font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    Public Video URL *
                  </label>
                  <input
                    type="url"
                    placeholder="https://youtube.com/watch?v=..."
                    value={videoUrl}
                    onChange={(e) => setVideoUrl(e.target.value)}
                    required
                    className="w-full rounded-xl border border-slate-200 bg-white px-3 py-2 text-xs text-slate-900 focus:outline-hidden dark:border-slate-700 dark:bg-slate-800 dark:text-white"
                  />
                </div>
                <div>
                  <label className="block text-[11px] font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    Associated Project Code
                  </label>
                  <input
                    type="text"
                    placeholder="e.g. BSN-1084"
                    value={projectCode}
                    onChange={(e) => setProjectCode(e.target.value)}
                    required
                    className="w-full rounded-xl border border-slate-200 bg-white px-3 py-2 text-xs text-slate-900 focus:outline-hidden dark:border-slate-700 dark:bg-slate-800 dark:text-white font-mono"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-[11px] font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    Initial Views Count
                  </label>
                  <input
                    type="number"
                    value={views}
                    onChange={(e) => setViews(parseInt(e.target.value, 10) || 0)}
                    className="w-full rounded-xl border border-slate-200 bg-white px-3 py-2 text-xs text-slate-900 focus:outline-hidden dark:border-slate-700 dark:bg-slate-800 dark:text-white font-mono"
                  />
                </div>
                <div>
                  <label className="block text-[11px] font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    Engagement Rate (%)
                  </label>
                  <input
                    type="number"
                    step="0.1"
                    value={engagementRate}
                    onChange={(e) => setEngagementRate(parseFloat(e.target.value) || 0)}
                    className="w-full rounded-xl border border-slate-200 bg-white px-3 py-2 text-xs text-slate-900 focus:outline-hidden dark:border-slate-700 dark:bg-slate-800 dark:text-white font-mono"
                  />
                </div>
              </div>

              <div>
                <label className="block text-[11px] font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  Performance Notes
                </label>
                <textarea
                  rows={2}
                  placeholder="Audience feedback, retention spike timestamps, viral factors..."
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  className="w-full rounded-xl border border-slate-200 bg-white px-3 py-2 text-xs text-slate-900 focus:outline-hidden dark:border-slate-700 dark:bg-slate-800 dark:text-white"
                />
              </div>

              <div className="pt-3 border-t border-slate-100 dark:border-slate-800 flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="rounded-xl border border-slate-200 px-3.5 py-2 text-slate-600 hover:bg-slate-100 dark:border-slate-700 dark:text-slate-300"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="rounded-xl bg-blue-600 px-4 py-2 font-semibold text-white hover:bg-blue-700 transition-colors shadow-xs"
                >
                  Save to Archive
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
