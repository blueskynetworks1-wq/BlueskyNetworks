import React, { useState } from 'react';
import {
  Bell,
  CheckCheck,
  Video,
  CheckCircle2,
  RotateCcw,
  Clock,
  ShieldAlert,
  Layers,
  ChevronRight,
  Filter,
} from 'lucide-react';
import { NotificationItem, User } from '../../types';

interface NotificationCenterProps {
  notifications: NotificationItem[];
  currentUser: User;
  onMarkRead: (id: string) => void;
  onClearAll: () => void;
  onNavigateTab: (tab: string) => void;
  onSelectProject?: (projectId: string) => void;
}

export const NotificationCenter: React.FC<NotificationCenterProps> = ({
  notifications,
  currentUser,
  onMarkRead,
  onClearAll,
  onNavigateTab,
  onSelectProject,
}) => {
  const [filterType, setFilterType] = useState<string>('all');

  const filtered = notifications.filter(
    (n) => filterType === 'all' || n.type === filterType
  );

  const getIcon = (type: NotificationItem['type']) => {
    switch (type) {
      case 'submission':
        return <Video className="h-4 w-4 text-blue-500" />;
      case 'approval':
        return <CheckCircle2 className="h-4 w-4 text-emerald-500" />;
      case 'revision':
        return <RotateCcw className="h-4 w-4 text-rose-500" />;
      case 'deadline':
        return <Clock className="h-4 w-4 text-amber-500" />;
      case 'account_request':
        return <ShieldAlert className="h-4 w-4 text-indigo-500" />;
      case 'assignment':
        return <Layers className="h-4 w-4 text-blue-600" />;
      default:
        return <Bell className="h-4 w-4 text-slate-400" />;
    }
  };

  const handleItemClick = (item: NotificationItem) => {
    onMarkRead(item.id);
    if (item.linkTab) {
      onNavigateTab(item.linkTab);
      if (item.targetId && onSelectProject && (item.linkTab === 'projects' || item.linkTab === 'my-projects')) {
        onSelectProject(item.targetId);
      }
    }
  };

  return (
    <div className="space-y-6 max-w-4xl mx-auto animate-in fade-in duration-200">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-lg font-bold text-slate-900 dark:text-white flex items-center gap-2">
            <Bell className="h-5 w-5 text-blue-600" />
            <span>Centralized Notifications Center</span>
          </h2>
          <p className="text-xs text-slate-500 dark:text-slate-400">
            Real-time pipeline alerts, managerial approvals, and deadline trackers
          </p>
        </div>

        <button
          onClick={onClearAll}
          className="flex items-center gap-1.5 rounded-xl border border-slate-200 bg-white px-3.5 py-2 text-xs font-medium text-slate-700 hover:bg-slate-100 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-200 transition-colors self-start sm:self-auto"
        >
          <CheckCheck className="h-3.5 w-3.5 text-slate-500" />
          <span>Mark All Read</span>
        </button>
      </div>

      {/* Filter Tabs */}
      <div className="flex items-center gap-1 p-1 bg-slate-100 dark:bg-slate-800 rounded-xl text-xs overflow-x-auto">
        {[
          { label: 'All Alerts', val: 'all' },
          { label: 'Submissions', val: 'submission' },
          { label: 'Approvals', val: 'approval' },
          { label: 'Revisions', val: 'revision' },
          { label: 'Deadlines', val: 'deadline' },
          { label: 'Account Requests', val: 'account_request' },
        ].map((tab) => (
          <button
            key={tab.val}
            onClick={() => setFilterType(tab.val)}
            className={`px-3 py-1.5 rounded-lg font-medium whitespace-nowrap transition-colors ${
              filterType === tab.val
                ? 'bg-white dark:bg-slate-700 text-slate-900 dark:text-white shadow-xs'
                : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {/* Notifications List */}
      <div className="space-y-2.5">
        {filtered.length === 0 ? (
          <div className="p-8 rounded-2xl glass-card border border-slate-200/80 dark:border-slate-800 text-center text-xs text-slate-400">
            No notifications in this category.
          </div>
        ) : (
          filtered.map((item) => (
            <div
              key={item.id}
              onClick={() => handleItemClick(item)}
              className={`p-4 rounded-2xl border transition-all cursor-pointer flex items-start justify-between gap-4 ${
                !item.isRead
                  ? 'bg-blue-50/70 border-blue-200 dark:bg-blue-950/30 dark:border-blue-900/50 shadow-xs'
                  : 'glass-card border-slate-200/80 dark:border-slate-800'
              }`}
            >
              <div className="flex items-start gap-3.5">
                <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-white dark:bg-slate-800 shadow-2xs shrink-0 mt-0.5">
                  {getIcon(item.type)}
                </div>
                <div>
                  <div className="flex items-center gap-2 mb-0.5">
                    <span className="text-xs font-bold text-slate-900 dark:text-white">
                      {item.title}
                    </span>
                    {!item.isRead && (
                      <span className="h-2 w-2 rounded-full bg-blue-600" />
                    )}
                  </div>
                  <p className="text-xs text-slate-600 dark:text-slate-300">
                    {item.message}
                  </p>
                  <span className="text-[10px] font-mono text-slate-400 mt-1 block">
                    {item.timestamp}
                  </span>
                </div>
              </div>

              <ChevronRight className="h-4 w-4 text-slate-400 shrink-0 self-center" />
            </div>
          ))
        )}
      </div>
    </div>
  );
};
