import React, { useState } from 'react';
import {
  Tv,
  Plus,
  ExternalLink,
  Users,
  TrendingUp,
  X,
  CheckCircle2,
  AlertCircle,
  Calendar,
} from 'lucide-react';
import { MediaAsset, User } from '../../types';

interface MediaAssetsViewProps {
  mediaAssets: MediaAsset[];
  currentUser: User;
  onCreateMediaAsset: (asset: Omit<MediaAsset, 'id' | 'dateAdded'>) => void;
  onUpdateMediaAsset: (asset: MediaAsset) => void;
}

export const MediaAssetsView: React.FC<MediaAssetsViewProps> = ({
  mediaAssets,
  currentUser,
  onCreateMediaAsset,
  onUpdateMediaAsset,
}) => {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [name, setName] = useState('');
  const [platform, setPlatform] = useState<MediaAsset['platform']>('YouTube');
  const [category, setCategory] = useState('Technology & AI');
  const [status, setStatus] = useState<MediaAsset['status']>('Active');
  const [subscribersCount, setSubscribersCount] = useState('500,000');
  const [monthlyReach, setMonthlyReach] = useState('2.5M views/mo');
  const [notes, setNotes] = useState('');
  const [url, setUrl] = useState('');

  const isCeo = currentUser.role === 'ceo';
  const isManager = currentUser.role === 'manager';

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) return;

    onCreateMediaAsset({
      name,
      platform,
      category,
      status,
      subscribersCount,
      monthlyReach,
      notes,
      url: url || 'https://youtube.com',
    });

    setIsModalOpen(false);
    setName('');
    setUrl('');
    setNotes('');
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-200">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-lg font-bold text-slate-900 dark:text-white flex items-center gap-2">
            <Tv className="h-5 w-5 text-blue-600" />
            <span>Media Assets & Channel Portfolio</span>
          </h2>
          <p className="text-xs text-slate-500 dark:text-slate-400">
            Official Bluesky Networks publishing surfaces across YouTube and Facebook
          </p>
        </div>

        {(isCeo || isManager) && (
          <button
            onClick={() => setIsModalOpen(true)}
            className="flex items-center gap-1.5 rounded-xl bg-blue-600 px-3.5 py-2 text-xs font-semibold text-white hover:bg-blue-700 shadow-md shadow-blue-600/20 transition-all self-start sm:self-auto"
          >
            <Plus className="h-4 w-4" />
            <span>Connect Media Channel</span>
          </button>
        )}
      </div>

      {/* Media Channels Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {mediaAssets.map((asset) => (
          <div
            key={asset.id}
            className="p-5 rounded-2xl glass-card border border-slate-200/80 dark:border-slate-800 space-y-4 hover:border-blue-300 dark:hover:border-blue-700 transition-all"
          >
            <div className="flex items-start justify-between gap-3">
              <div className="flex items-center gap-3">
                <div
                  className={`flex h-12 w-12 items-center justify-center rounded-2xl font-bold text-white shadow-md ${
                    asset.platform === 'YouTube'
                      ? 'bg-gradient-to-tr from-red-600 to-rose-500 shadow-red-500/25'
                      : 'bg-gradient-to-tr from-blue-600 to-indigo-500 shadow-blue-500/25'
                  }`}
                >
                  {asset.platform === 'YouTube' ? 'YT' : 'FB'}
                </div>
                <div>
                  <h3 className="text-sm font-bold text-slate-900 dark:text-white">
                    {asset.name}
                  </h3>
                  <div className="text-xs text-slate-500 dark:text-slate-400">
                    {asset.platform} · {asset.category}
                  </div>
                </div>
              </div>

              <span
                className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                  asset.status === 'Active'
                    ? 'bg-emerald-50 text-emerald-700 dark:bg-emerald-950/40 dark:text-emerald-300 border border-emerald-200 dark:border-emerald-800'
                    : 'bg-blue-50 text-blue-700 dark:bg-blue-950/40 dark:text-blue-300'
                }`}
              >
                {asset.status}
              </span>
            </div>

            <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed bg-slate-50/60 dark:bg-slate-800/40 p-3 rounded-xl border border-slate-100 dark:border-slate-800">
              {asset.notes}
            </p>

            <div className="grid grid-cols-2 gap-3 pt-1 text-xs">
              <div>
                <span className="text-[11px] text-slate-400">Audience Scale</span>
                <div className="font-bold text-slate-900 dark:text-white font-mono tabular-nums text-sm">
                  {asset.subscribersCount}
                </div>
              </div>

              <div>
                <span className="text-[11px] text-slate-400">Monthly Reach</span>
                <div className="font-bold text-blue-600 dark:text-blue-400 font-mono tabular-nums text-sm">
                  {asset.monthlyReach}
                </div>
              </div>
            </div>

            <div className="pt-3 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between text-xs text-slate-400">
              <span>Added {asset.dateAdded}</span>
              <a
                href={asset.url}
                target="_blank"
                rel="noreferrer"
                className="flex items-center gap-1 font-semibold text-blue-600 hover:underline dark:text-blue-400"
              >
                <span>Visit Channel</span>
                <ExternalLink className="h-3 w-3" />
              </a>
            </div>
          </div>
        ))}
      </div>

      {/* Add Media Channel Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-md animate-in fade-in duration-100">
          <div className="w-full max-w-lg rounded-2xl border border-slate-200/90 bg-white p-6 shadow-2xl dark:border-slate-800 dark:bg-slate-900">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800">
              <h3 className="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-2">
                <Tv className="h-4 w-4 text-blue-600" />
                <span>Connect New Media Channel</span>
              </h3>
              <button
                onClick={() => setIsModalOpen(false)}
                className="text-slate-400 hover:text-slate-600 dark:hover:text-slate-200"
              >
                <X className="h-4 w-4" />
              </button>
            </div>

            <form onSubmit={handleSubmit} className="mt-4 space-y-3.5 text-xs">
              <div>
                <label className="block text-[11px] font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  Channel / Page Name *
                </label>
                <input
                  type="text"
                  placeholder="e.g. Bluesky Earth & Exploration"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  required
                  className="w-full rounded-xl border border-slate-200 bg-white px-3 py-2 text-xs text-slate-900 focus:outline-hidden dark:border-slate-700 dark:bg-slate-800 dark:text-white"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-[11px] font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    Platform
                  </label>
                  <select
                    value={platform}
                    onChange={(e) => setPlatform(e.target.value as any)}
                    className="w-full rounded-xl border border-slate-200 bg-white px-3 py-2 text-xs text-slate-900 focus:outline-hidden dark:border-slate-700 dark:bg-slate-800 dark:text-white"
                  >
                    <option value="YouTube">YouTube</option>
                    <option value="Facebook">Facebook</option>
                    <option value="Instagram">Instagram</option>
                    <option value="TikTok">TikTok</option>
                  </select>
                </div>
                <div>
                  <label className="block text-[11px] font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    Category
                  </label>
                  <input
                    type="text"
                    value={category}
                    onChange={(e) => setCategory(e.target.value)}
                    className="w-full rounded-xl border border-slate-200 bg-white px-3 py-2 text-xs text-slate-900 focus:outline-hidden dark:border-slate-700 dark:bg-slate-800 dark:text-white"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-[11px] font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    Subscribers / Followers Count
                  </label>
                  <input
                    type="text"
                    placeholder="e.g. 450,000"
                    value={subscribersCount}
                    onChange={(e) => setSubscribersCount(e.target.value)}
                    className="w-full rounded-xl border border-slate-200 bg-white px-3 py-2 text-xs text-slate-900 focus:outline-hidden dark:border-slate-700 dark:bg-slate-800 dark:text-white"
                  />
                </div>
                <div>
                  <label className="block text-[11px] font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    Monthly Reach
                  </label>
                  <input
                    type="text"
                    placeholder="e.g. 2.1M views/mo"
                    value={monthlyReach}
                    onChange={(e) => setMonthlyReach(e.target.value)}
                    className="w-full rounded-xl border border-slate-200 bg-white px-3 py-2 text-xs text-slate-900 focus:outline-hidden dark:border-slate-700 dark:bg-slate-800 dark:text-white"
                  />
                </div>
              </div>

              <div>
                <label className="block text-[11px] font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  Channel URL
                </label>
                <input
                  type="url"
                  placeholder="https://youtube.com/@channel"
                  value={url}
                  onChange={(e) => setUrl(e.target.value)}
                  className="w-full rounded-xl border border-slate-200 bg-white px-3 py-2 text-xs text-slate-900 focus:outline-hidden dark:border-slate-700 dark:bg-slate-800 dark:text-white"
                />
              </div>

              <div>
                <label className="block text-[11px] font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  Editorial & Production Guidelines
                </label>
                <textarea
                  rows={2}
                  placeholder="Target release cadence, visual standards, tone of voice..."
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  className="w-full rounded-xl border border-slate-200 bg-white px-3 py-2 text-xs text-slate-900 focus:outline-hidden dark:border-slate-700 dark:bg-slate-800 dark:text-white"
                />
              </div>

              <div className="pt-3 border-t border-slate-100 dark:border-slate-800 flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="rounded-xl border border-slate-200 px-3.5 py-2 text-slate-600 hover:bg-slate-100 dark:border-slate-700 dark:text-slate-300"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="rounded-xl bg-blue-600 px-4 py-2 font-semibold text-white hover:bg-blue-700 transition-colors shadow-xs"
                >
                  Save Media Asset
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
