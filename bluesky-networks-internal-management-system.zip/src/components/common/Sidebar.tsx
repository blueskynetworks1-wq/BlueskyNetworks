import React from 'react';
import {
  LayoutDashboard,
  Layers,
  Users,
  MessageSquare,
  Calendar,
  Video,
  Tv,
  Award,
  LineChart,
  Bell,
  ShieldCheck,
  Settings,
  UserCheck,
  CheckCircle2,
  FolderLock,
} from 'lucide-react';
import { User } from '../../types';

interface SidebarProps {
  currentUser: User;
  activeTab: string;
  onSelectTab: (tab: string) => void;
  unreadMessagesCount: number;
  unreadNotificationsCount: number;
  pendingReviewsCount: number;
}

export const Sidebar: React.FC<SidebarProps> = ({
  currentUser,
  activeTab,
  onSelectTab,
  unreadMessagesCount,
  unreadNotificationsCount,
  pendingReviewsCount,
}) => {
  const isCeo = currentUser.role === 'ceo';
  const isManager = currentUser.role === 'manager';
  const isMember = currentUser.role === 'member';

  return (
    <aside className="w-64 shrink-0 border-r border-slate-200/80 bg-white/70 backdrop-blur-2xl dark:border-slate-800/80 dark:bg-slate-900/70 flex flex-col justify-between transition-colors">
      <div className="flex flex-col h-full">
        {/* Brand Bar */}
        <div className="h-16 flex items-center gap-3 px-5 border-b border-slate-200/60 dark:border-slate-800/60">
          <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-gradient-to-tr from-blue-600 to-indigo-500 shadow-md shadow-blue-500/20 text-white font-bold text-base">
            <span className="tracking-tighter">BS</span>
          </div>
          <div>
            <div className="font-bold text-sm tracking-tight text-slate-900 dark:text-white leading-tight">
              Bluesky Networks
            </div>
            <div className="text-[11px] text-slate-500 dark:text-slate-400 font-medium">
              Digital Media Operations
            </div>
          </div>
        </div>

        {/* Navigation Links */}
        <div className="flex-1 overflow-y-auto px-3 py-4 space-y-6">
          {/* Main Workspace Section */}
          <div>
            <div className="px-3 pb-2 text-[11px] font-semibold tracking-wider text-slate-400 uppercase dark:text-slate-500">
              {isMember ? 'Workspace' : 'Executive Console'}
            </div>
            <nav className="space-y-1">
              {isCeo && (
                <button
                  onClick={() => onSelectTab('dashboard')}
                  className={`w-full flex items-center justify-between px-3 py-2 rounded-xl text-xs font-medium transition-all ${
                    activeTab === 'dashboard'
                      ? 'bg-blue-600 text-white shadow-sm shadow-blue-500/30'
                      : 'text-slate-600 hover:bg-slate-100 dark:text-slate-300 dark:hover:bg-slate-800/60'
                  }`}
                >
                  <div className="flex items-center gap-2.5">
                    <LayoutDashboard className="h-4 w-4" />
                    <span>Executive Overview</span>
                  </div>
                </button>
              )}

              {isMember && (
                <button
                  onClick={() => onSelectTab('my-dashboard')}
                  className={`w-full flex items-center justify-between px-3 py-2 rounded-xl text-xs font-medium transition-all ${
                    activeTab === 'my-dashboard'
                      ? 'bg-blue-600 text-white shadow-sm shadow-blue-500/30'
                      : 'text-slate-600 hover:bg-slate-100 dark:text-slate-300 dark:hover:bg-slate-800/60'
                  }`}
                >
                  <div className="flex items-center gap-2.5">
                    <LayoutDashboard className="h-4 w-4" />
                    <span>Today's Focus</span>
                  </div>
                </button>
              )}

              {isManager && (
                <button
                  onClick={() => onSelectTab('dashboard')}
                  className={`w-full flex items-center justify-between px-3 py-2 rounded-xl text-xs font-medium transition-all ${
                    activeTab === 'dashboard'
                      ? 'bg-blue-600 text-white shadow-sm shadow-blue-500/30'
                      : 'text-slate-600 hover:bg-slate-100 dark:text-slate-300 dark:hover:bg-slate-800/60'
                  }`}
                >
                  <div className="flex items-center gap-2.5">
                    <LayoutDashboard className="h-4 w-4" />
                    <span>Production Overview</span>
                  </div>
                </button>
              )}

              {/* Projects */}
              <button
                onClick={() => onSelectTab(isMember ? 'my-projects' : 'projects')}
                className={`w-full flex items-center justify-between px-3 py-2 rounded-xl text-xs font-medium transition-all ${
                  activeTab === 'projects' || activeTab === 'my-projects'
                    ? 'bg-blue-600 text-white shadow-sm shadow-blue-500/30'
                    : 'text-slate-600 hover:bg-slate-100 dark:text-slate-300 dark:hover:bg-slate-800/60'
                }`}
              >
                <div className="flex items-center gap-2.5">
                  <Layers className="h-4 w-4" />
                  <span>{isMember ? 'My Projects' : 'Projects Pipeline'}</span>
                </div>
                {(isCeo || isManager) && pendingReviewsCount > 0 && (
                  <span
                    className={`rounded-full px-1.5 py-0.5 text-[10px] font-bold ${
                      activeTab === 'projects'
                        ? 'bg-white text-blue-600'
                        : 'bg-amber-100 text-amber-700 dark:bg-amber-900/40 dark:text-amber-300'
                    }`}
                  >
                    {pendingReviewsCount} review
                  </span>
                )}
              </button>

              {/* Team Section (CEO and Manager only) */}
              {(isCeo || isManager) && (
                <button
                  onClick={() => onSelectTab('team')}
                  className={`w-full flex items-center justify-between px-3 py-2 rounded-xl text-xs font-medium transition-all ${
                    activeTab === 'team'
                      ? 'bg-blue-600 text-white shadow-sm shadow-blue-500/30'
                      : 'text-slate-600 hover:bg-slate-100 dark:text-slate-300 dark:hover:bg-slate-800/60'
                  }`}
                >
                  <div className="flex items-center gap-2.5">
                    <Users className="h-4 w-4" />
                    <span>Team & Rosters</span>
                  </div>
                </button>
              )}

              {/* Messages (Available to all, but strictly private 1-on-1) */}
              <button
                onClick={() => onSelectTab('messages')}
                className={`w-full flex items-center justify-between px-3 py-2 rounded-xl text-xs font-medium transition-all ${
                  activeTab === 'messages'
                    ? 'bg-blue-600 text-white shadow-sm shadow-blue-500/30'
                    : 'text-slate-600 hover:bg-slate-100 dark:text-slate-300 dark:hover:bg-slate-800/60'
                }`}
              >
                <div className="flex items-center gap-2.5">
                  <MessageSquare className="h-4 w-4" />
                  <span>Internal Messages</span>
                </div>
                {unreadMessagesCount > 0 && (
                  <span
                    className={`rounded-full px-1.5 py-0.5 text-[10px] font-bold ${
                      activeTab === 'messages'
                        ? 'bg-white text-blue-600'
                        : 'bg-blue-100 text-blue-700 dark:bg-blue-900/50 dark:text-blue-300'
                    }`}
                  >
                    {unreadMessagesCount}
                  </span>
                )}
              </button>

              {/* Performance & Points */}
              <button
                onClick={() => onSelectTab(isMember ? 'my-performance' : 'performance')}
                className={`w-full flex items-center justify-between px-3 py-2 rounded-xl text-xs font-medium transition-all ${
                  activeTab === 'performance' || activeTab === 'my-performance'
                    ? 'bg-blue-600 text-white shadow-sm shadow-blue-500/30'
                    : 'text-slate-600 hover:bg-slate-100 dark:text-slate-300 dark:hover:bg-slate-800/60'
                }`}
              >
                <div className="flex items-center gap-2.5">
                  <Award className="h-4 w-4" />
                  <span>{isMember ? 'My Performance' : 'Points & Performance'}</span>
                </div>
                {isMember && (
                  <span className="font-mono text-[10px] text-slate-400">
                    {currentUser.points} pts
                  </span>
                )}
              </button>
            </nav>
          </div>

          {/* Media & Content Publishing (CEO and Managers only) */}
          {(isCeo || isManager) && (
            <div>
              <div className="px-3 pb-2 text-[11px] font-semibold tracking-wider text-slate-400 uppercase dark:text-slate-500">
                Media & Distribution
              </div>
              <nav className="space-y-1">
                <button
                  onClick={() => onSelectTab('calendar')}
                  className={`w-full flex items-center justify-between px-3 py-2 rounded-xl text-xs font-medium transition-all ${
                    activeTab === 'calendar'
                      ? 'bg-blue-600 text-white shadow-sm shadow-blue-500/30'
                      : 'text-slate-600 hover:bg-slate-100 dark:text-slate-300 dark:hover:bg-slate-800/60'
                  }`}
                >
                  <div className="flex items-center gap-2.5">
                    <Calendar className="h-4 w-4" />
                    <span>Content Calendar</span>
                  </div>
                </button>

                <button
                  onClick={() => onSelectTab('publishing')}
                  className={`w-full flex items-center justify-between px-3 py-2 rounded-xl text-xs font-medium transition-all ${
                    activeTab === 'publishing'
                      ? 'bg-blue-600 text-white shadow-sm shadow-blue-500/30'
                      : 'text-slate-600 hover:bg-slate-100 dark:text-slate-300 dark:hover:bg-slate-800/60'
                  }`}
                >
                  <div className="flex items-center gap-2.5">
                    <Video className="h-4 w-4" />
                    <span>Published Tracker</span>
                  </div>
                </button>

                <button
                  onClick={() => onSelectTab('media')}
                  className={`w-full flex items-center justify-between px-3 py-2 rounded-xl text-xs font-medium transition-all ${
                    activeTab === 'media'
                      ? 'bg-blue-600 text-white shadow-sm shadow-blue-500/30'
                      : 'text-slate-600 hover:bg-slate-100 dark:text-slate-300 dark:hover:bg-slate-800/60'
                  }`}
                >
                  <div className="flex items-center gap-2.5">
                    <Tv className="h-4 w-4" />
                    <span>Media Assets</span>
                  </div>
                </button>

                {isCeo && (
                  <button
                    onClick={() => onSelectTab('insights')}
                    className={`w-full flex items-center justify-between px-3 py-2 rounded-xl text-xs font-medium transition-all ${
                      activeTab === 'insights'
                        ? 'bg-blue-600 text-white shadow-sm shadow-blue-500/30'
                        : 'text-slate-600 hover:bg-slate-100 dark:text-slate-300 dark:hover:bg-slate-800/60'
                    }`}
                  >
                    <div className="flex items-center gap-2.5">
                      <LineChart className="h-4 w-4" />
                      <span>Business Intelligence</span>
                    </div>
                  </button>
                )}
              </nav>
            </div>
          )}

          {/* Governance & System Section */}
          <div>
            <div className="px-3 pb-2 text-[11px] font-semibold tracking-wider text-slate-400 uppercase dark:text-slate-500">
              System
            </div>
            <nav className="space-y-1">
              <button
                onClick={() => onSelectTab('notifications')}
                className={`w-full flex items-center justify-between px-3 py-2 rounded-xl text-xs font-medium transition-all ${
                  activeTab === 'notifications'
                    ? 'bg-blue-600 text-white shadow-sm shadow-blue-500/30'
                    : 'text-slate-600 hover:bg-slate-100 dark:text-slate-300 dark:hover:bg-slate-800/60'
                }`}
              >
                <div className="flex items-center gap-2.5">
                  <Bell className="h-4 w-4" />
                  <span>Notifications</span>
                </div>
                {unreadNotificationsCount > 0 && (
                  <span
                    className={`rounded-full px-1.5 py-0.5 text-[10px] font-bold ${
                      activeTab === 'notifications'
                        ? 'bg-white text-blue-600'
                        : 'bg-red-100 text-red-600 dark:bg-red-900/40 dark:text-red-300'
                    }`}
                  >
                    {unreadNotificationsCount}
                  </span>
                )}
              </button>

              {/* CEO Admin Center */}
              {isCeo && (
                <button
                  onClick={() => onSelectTab('admin')}
                  className={`w-full flex items-center justify-between px-3 py-2 rounded-xl text-xs font-medium transition-all ${
                    activeTab === 'admin'
                      ? 'bg-blue-600 text-white shadow-sm shadow-blue-500/30'
                      : 'text-slate-600 hover:bg-slate-100 dark:text-slate-300 dark:hover:bg-slate-800/60'
                  }`}
                >
                  <div className="flex items-center gap-2.5">
                    <ShieldCheck className="h-4 w-4 text-amber-500" />
                    <span>Admin & Security</span>
                  </div>
                </button>
              )}

              {/* Profile for Team Members */}
              {isMember && (
                <button
                  onClick={() => onSelectTab('profile')}
                  className={`w-full flex items-center justify-between px-3 py-2 rounded-xl text-xs font-medium transition-all ${
                    activeTab === 'profile'
                      ? 'bg-blue-600 text-white shadow-sm shadow-blue-500/30'
                      : 'text-slate-600 hover:bg-slate-100 dark:text-slate-300 dark:hover:bg-slate-800/60'
                  }`}
                >
                  <div className="flex items-center gap-2.5">
                    <UserCheck className="h-4 w-4" />
                    <span>My Profile</span>
                  </div>
                </button>
              )}

              {isCeo && (
                <button
                  onClick={() => onSelectTab('settings')}
                  className={`w-full flex items-center justify-between px-3 py-2 rounded-xl text-xs font-medium transition-all ${
                    activeTab === 'settings'
                      ? 'bg-blue-600 text-white shadow-sm shadow-blue-500/30'
                      : 'text-slate-600 hover:bg-slate-100 dark:text-slate-300 dark:hover:bg-slate-800/60'
                  }`}
                >
                  <div className="flex items-center gap-2.5">
                    <Settings className="h-4 w-4" />
                    <span>Company Settings</span>
                  </div>
                </button>
              )}
            </nav>
          </div>
        </div>

        {/* Security / RBAC Status Capsule */}
        <div className="p-3 border-t border-slate-200/60 dark:border-slate-800/60">
          <div className="rounded-xl bg-slate-100/80 p-2.5 dark:bg-slate-800/60 text-xs text-slate-500 dark:text-slate-400">
            <div className="flex items-center gap-2 font-medium text-slate-700 dark:text-slate-200 mb-1">
              <FolderLock className="h-3.5 w-3.5 text-blue-500" />
              <span>Strict RBAC Active</span>
            </div>
            <div className="text-[11px] leading-tight">
              {isCeo && 'Unrestricted Founder/CEO access'}
              {isManager && 'Managerial scope with review authority'}
              {isMember && 'Confidential assigned projects only'}
            </div>
          </div>
        </div>
      </div>
    </aside>
  );
};
