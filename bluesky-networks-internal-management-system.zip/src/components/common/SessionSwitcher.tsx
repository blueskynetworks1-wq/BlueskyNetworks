import React from 'react';
import {
  X,
  Crown,
  Shield,
  User as UserIcon,
  Check,
  KeyRound,
  LogOut,
  Sparkles,
} from 'lucide-react';
import { User } from '../../types';

interface SessionSwitcherProps {
  isOpen: boolean;
  onClose: () => void;
  users: User[];
  currentUser: User;
  onSelectUser: (userId: string) => void;
  onOpenLoginModal: () => void;
  onResetData: () => void;
}

export const SessionSwitcher: React.FC<SessionSwitcherProps> = ({
  isOpen,
  onClose,
  users,
  currentUser,
  onSelectUser,
  onOpenLoginModal,
  onResetData,
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/40 backdrop-blur-sm animate-in fade-in duration-150">
      <div className="w-full max-w-lg rounded-2xl border border-slate-200/80 bg-white/95 p-6 shadow-2xl backdrop-blur-2xl dark:border-slate-800 dark:bg-slate-900/95 transition-all">
        {/* Header */}
        <div className="flex items-center justify-between pb-4 border-b border-slate-200/70 dark:border-slate-800/70">
          <div>
            <h2 className="text-base font-semibold text-slate-900 dark:text-white flex items-center gap-2">
              <Sparkles className="h-4 w-4 text-blue-500" />
              <span>Interactive Role Switcher</span>
            </h2>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              Instantly preview how permissions and confidential views adapt per user
            </p>
          </div>
          <button
            onClick={onClose}
            className="rounded-lg p-1.5 text-slate-400 hover:bg-slate-100 hover:text-slate-700 dark:hover:bg-slate-800 dark:hover:text-slate-200"
          >
            <X className="h-4 w-4" />
          </button>
        </div>

        {/* User Account List */}
        <div className="mt-4 space-y-2 max-h-80 overflow-y-auto pr-1">
          {users.map((user) => {
            const isSelected = user.id === currentUser.id;
            return (
              <button
                key={user.id}
                onClick={() => {
                  onSelectUser(user.id);
                  onClose();
                }}
                className={`w-full flex items-center justify-between p-3 rounded-xl border transition-all text-left ${
                  isSelected
                    ? 'border-blue-500 bg-blue-50/70 dark:border-blue-500 dark:bg-blue-950/40 shadow-xs ring-1 ring-blue-500/30'
                    : 'border-slate-200/80 bg-white hover:border-slate-300 hover:bg-slate-50/70 dark:border-slate-800 dark:bg-slate-800/50 dark:hover:bg-slate-800'
                }`}
              >
                <div className="flex items-center gap-3">
                  <div className="relative">
                    {user.avatarUrl ? (
                      <img
                        src={user.avatarUrl}
                        alt={user.name}
                        className="h-10 w-10 rounded-full object-cover ring-1 ring-slate-200 dark:ring-slate-700"
                      />
                    ) : (
                      <div className="flex h-10 w-10 items-center justify-center rounded-full bg-slate-100 text-slate-700 dark:bg-slate-800 dark:text-slate-300 font-bold text-sm">
                        {user.name.charAt(0)}
                      </div>
                    )}
                    {user.role === 'ceo' && (
                      <div className="absolute -bottom-1 -right-1 flex h-4 w-4 items-center justify-center rounded-full bg-amber-500 text-white shadow-xs">
                        <Crown className="h-2.5 w-2.5" />
                      </div>
                    )}
                    {user.role === 'manager' && (
                      <div className="absolute -bottom-1 -right-1 flex h-4 w-4 items-center justify-center rounded-full bg-indigo-500 text-white shadow-xs">
                        <Shield className="h-2.5 w-2.5" />
                      </div>
                    )}
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="text-sm font-semibold text-slate-900 dark:text-white">
                        {user.name}
                      </span>
                      <span
                        className={`text-[10px] font-medium px-2 py-0.5 rounded-full ${
                          user.role === 'ceo'
                            ? 'bg-amber-100 text-amber-800 dark:bg-amber-900/50 dark:text-amber-300'
                            : user.role === 'manager'
                            ? 'bg-indigo-100 text-indigo-800 dark:bg-indigo-900/50 dark:text-indigo-300'
                            : 'bg-slate-100 text-slate-700 dark:bg-slate-800 dark:text-slate-300'
                        }`}
                      >
                        {user.role === 'ceo' ? 'Founder & CEO' : user.role === 'manager' ? 'Manager' : 'Team Member'}
                      </span>
                    </div>
                    <div className="text-xs text-slate-500 dark:text-slate-400">
                      {user.jobTitle} · <span className="font-mono text-[11px]">{user.points} pts</span>
                    </div>
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  {isSelected && (
                    <div className="flex h-6 w-6 items-center justify-center rounded-full bg-blue-600 text-white shadow-xs">
                      <Check className="h-3.5 w-3.5" />
                    </div>
                  )}
                </div>
              </button>
            );
          })}
        </div>

        {/* Footer Actions */}
        <div className="mt-5 pt-4 border-t border-slate-200/70 dark:border-slate-800/70 flex flex-wrap items-center justify-between gap-2">
          <button
            onClick={() => {
              onClose();
              onOpenLoginModal();
            }}
            className="flex items-center gap-1.5 rounded-lg border border-slate-200 px-3 py-1.5 text-xs font-medium text-slate-700 hover:bg-slate-100 dark:border-slate-700 dark:text-slate-300 dark:hover:bg-slate-800 transition-colors"
          >
            <KeyRound className="h-3.5 w-3.5 text-slate-500" />
            <span>Simulate Secure Login</span>
          </button>

          <button
            onClick={() => {
              if (confirm('Reset workspace data back to pristine seed defaults?')) {
                onResetData();
                onClose();
              }
            }}
            className="text-xs text-slate-400 hover:text-red-500 transition-colors"
          >
            Reset Seed Data
          </button>
        </div>
      </div>
    </div>
  );
};
