import React, { useState, useEffect } from 'react';
import { Play, Square, Clock, Timer, Check, Sparkles } from 'lucide-react';
import { Project, User } from '../../types';

interface ProjectTimerWidgetProps {
  project: Project;
  currentUser: User;
  onStartTimer: (projectId: string) => void;
  onStopTimer: (projectId: string, notes?: string) => void;
  compact?: boolean;
}

export function formatSecondsToDuration(totalSeconds: number): string {
  if (!totalSeconds || totalSeconds <= 0) return '0m';
  const hours = Math.floor(totalSeconds / 3600);
  const minutes = Math.floor((totalSeconds % 3600) / 60);
  const seconds = totalSeconds % 60;

  if (hours > 0) {
    return `${hours}h ${minutes}m`;
  }
  if (minutes > 0) {
    return `${minutes}m ${seconds}s`;
  }
  return `${seconds}s`;
}

export function formatStopwatchTime(elapsedSeconds: number): string {
  const h = Math.floor(elapsedSeconds / 3600);
  const m = Math.floor((elapsedSeconds % 3600) / 60);
  const s = elapsedSeconds % 60;

  const hh = h > 0 ? `${h.toString().padStart(2, '0')}:` : '';
  const mm = m.toString().padStart(2, '0');
  const ss = s.toString().padStart(2, '0');
  return `${hh}${mm}:${ss}`;
}

export const ProjectTimerWidget: React.FC<ProjectTimerWidgetProps> = ({
  project,
  currentUser,
  onStartTimer,
  onStopTimer,
  compact = false,
}) => {
  const isRunning = Boolean(project.activeTimerStartedAt);
  const [elapsed, setElapsed] = useState<number>(0);
  const [showNoteInput, setShowNoteInput] = useState(false);
  const [sessionNote, setSessionNote] = useState('');

  // Ticking effect when running
  useEffect(() => {
    if (!project.activeTimerStartedAt) {
      setElapsed(0);
      return;
    }

    const startMs = new Date(project.activeTimerStartedAt).getTime();
    const updateElapsed = () => {
      const nowMs = Date.now();
      const diffSec = Math.max(0, Math.floor((nowMs - startMs) / 1000));
      setElapsed(diffSec);
    };

    updateElapsed();
    const interval = setInterval(updateElapsed, 1000);
    return () => clearInterval(interval);
  }, [project.activeTimerStartedAt]);

  // Only projects in 'In Progress' status show the active timer controls
  const isInProgress = project.status === 'In Progress';

  if (!isInProgress && !project.timeSpentSeconds) {
    return null;
  }

  // If not in progress but has logged time (e.g. Completed or Waiting for Review)
  if (!isInProgress) {
    return (
      <div className="inline-flex items-center gap-1.5 text-xs text-slate-500 dark:text-slate-400 font-mono tabular-nums">
        <Clock className="h-3.5 w-3.5 text-slate-400" />
        <span>{formatSecondsToDuration(project.timeSpentSeconds || 0)}</span>
      </div>
    );
  }

  const handleStopClick = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (compact) {
      onStopTimer(project.id);
    } else {
      setShowNoteInput(true);
    }
  };

  const handleConfirmStop = (e: React.FormEvent) => {
    e.preventDefault();
    e.stopPropagation();
    onStopTimer(project.id, sessionNote);
    setShowNoteInput(false);
    setSessionNote('');
  };

  if (compact) {
    return (
      <div
        className="inline-flex items-center gap-1.5"
        onClick={(e) => e.stopPropagation()}
      >
        {isRunning ? (
          <button
            onClick={handleStopClick}
            className="flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-emerald-500/15 border border-emerald-500/40 text-emerald-700 dark:text-emerald-300 text-xs font-mono font-bold hover:bg-emerald-500/25 transition-all shadow-2xs group"
            title="Timer active. Click to stop and record session."
          >
            <span className="relative flex h-2 w-2">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75" />
              <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500" />
            </span>
            <span className="tabular-nums">{formatStopwatchTime(elapsed)}</span>
            <Square className="h-3 w-3 text-rose-500 group-hover:scale-110 ml-0.5" />
          </button>
        ) : (
          <button
            onClick={(e) => {
              e.stopPropagation();
              onStartTimer(project.id);
            }}
            className="flex items-center gap-1.5 px-2.5 py-1 rounded-lg border border-blue-200 bg-blue-50/80 text-blue-700 hover:bg-blue-100 hover:border-blue-300 dark:border-blue-900/60 dark:bg-blue-950/40 dark:text-blue-300 text-xs font-semibold transition-all shadow-2xs"
            title="Start live work session timer"
          >
            <Play className="h-3 w-3 fill-current" />
            <span>Start Timer</span>
          </button>
        )}
      </div>
    );
  }

  // Full / expanded mode (used in modals and hero cards)
  return (
    <div
      className="p-3.5 rounded-2xl border border-slate-200/80 bg-white/90 dark:border-slate-800 dark:bg-slate-800/60 shadow-xs space-y-2.5"
      onClick={(e) => e.stopPropagation()}
    >
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <div className="flex h-7 w-7 items-center justify-center rounded-xl bg-blue-50 text-blue-600 dark:bg-blue-950/60 dark:text-blue-400">
            <Timer className="h-4 w-4" />
          </div>
          <div>
            <div className="text-xs font-bold text-slate-900 dark:text-white leading-tight">
              Live Work Session Tracker
            </div>
            <div className="text-[10px] text-slate-400">
              Total Logged: <strong className="text-slate-700 dark:text-slate-200 font-mono">{formatSecondsToDuration(project.timeSpentSeconds || 0)}</strong>
            </div>
          </div>
        </div>

        {isRunning ? (
          <div className="flex items-center gap-2">
            <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-600 dark:text-emerald-400 font-mono font-bold text-sm tabular-nums">
              <span className="relative flex h-2 w-2">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75" />
                <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500" />
              </span>
              <span>{formatStopwatchTime(elapsed)}</span>
            </div>

            <button
              onClick={() => setShowNoteInput(true)}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-rose-600 text-white text-xs font-semibold hover:bg-rose-700 shadow-xs transition-colors"
            >
              <Square className="h-3.5 w-3.5 fill-current" />
              <span>Stop & Save</span>
            </button>
          </div>
        ) : (
          <button
            onClick={() => onStartTimer(project.id)}
            className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-blue-600 text-white text-xs font-semibold hover:bg-blue-700 shadow-sm shadow-blue-500/20 transition-all"
          >
            <Play className="h-3.5 w-3.5 fill-current" />
            <span>Start Timer</span>
          </button>
        )}
      </div>

      {/* Note input popup when stopping timer */}
      {showNoteInput && (
        <form onSubmit={handleConfirmStop} className="pt-2 border-t border-slate-100 dark:border-slate-800 space-y-2">
          <label className="block text-[11px] font-medium text-slate-500 dark:text-slate-400">
            Work Session Notes (Optional):
          </label>
          <div className="flex items-center gap-2">
            <input
              type="text"
              placeholder="e.g. Edited scene transitions and audio ducking..."
              value={sessionNote}
              onChange={(e) => setSessionNote(e.target.value)}
              className="flex-1 rounded-xl border border-slate-200 bg-white px-3 py-1.5 text-xs text-slate-900 focus:outline-hidden dark:border-slate-700 dark:bg-slate-900 dark:text-white"
            />
            <button
              type="submit"
              className="px-3 py-1.5 rounded-xl bg-emerald-600 text-white text-xs font-semibold hover:bg-emerald-700 transition-colors shrink-0"
            >
              Confirm Log
            </button>
            <button
              type="button"
              onClick={() => {
                setShowNoteInput(false);
                onStopTimer(project.id);
              }}
              className="px-2.5 py-1.5 text-xs text-slate-400 hover:text-slate-600 dark:hover:text-slate-200"
            >
              Skip Notes
            </button>
          </div>
        </form>
      )}
    </div>
  );
};
