import React from 'react';
import {
  Bell,
  Search,
  Moon,
  Sun,
  Shield,
  User as UserIcon,
  LogOut,
  SlidersHorizontal,
} from 'lucide-react';
import { User, NotificationItem } from '../../types';

interface HeaderProps {
  currentUser: User;
  activeTab: string;
  darkMode: boolean;
  onToggleDarkMode: () => void;
  onOpenCommandPalette: () => void;
  onOpenNotifications: () => void;
  onOpenSessionSwitcher: () => void;
  onLogout: () => void;
  unreadNotificationsCount: number;
  unreadMessagesCount: number;
}

const TAB_TITLES: Record<string, { title: string; subtitle: string }> = {
  dashboard: { title: 'Executive Overview', subtitle: 'Real-time studio pipeline & operations' },
  'my-dashboard': { title: "Today's Focus", subtitle: 'Personal assignments & priority queue' },
  projects: { title: 'Project Management', subtitle: 'Video pipelines & production stages' },
  'my-projects': { title: 'Assigned Projects', subtitle: 'Your active and past video deliverables' },
  team: { title: 'Team Dossiers', subtitle: 'Staff profiles, performance & governance' },
  calendar: { title: 'Content Calendar', subtitle: 'Future publishing schedules & concepts' },
  publishing: { title: 'Published Video Tracker', subtitle: 'Archived releases, reach & metrics' },
  media: { title: 'Media Assets', subtitle: 'YouTube channels & Facebook pages' },
  performance: { title: 'Points & Performance', subtitle: 'Transparent scoring rules & leaderboard' },
  'my-performance': { title: 'My Performance', subtitle: 'Earned points, ratings & on-time stats' },
  messages: { title: 'Internal Messages', subtitle: 'Private encrypted 1-on-1 communications' },
  insights: { title: 'Business Intelligence', subtitle: 'Production velocity, bottlenecks & reach' },
  notifications: { title: 'Notification Center', subtitle: 'System alerts, submissions & approvals' },
  admin: { title: 'Security & Administration', subtitle: 'User accounts, change requests & audit logs' },
  profile: { title: 'Personal Profile', subtitle: 'Account settings & credentials' },
  settings: { title: 'Studio Settings', subtitle: 'Company configuration & preferences' },
};

export const Header: React.FC<HeaderProps> = ({
  currentUser,
  activeTab,
  darkMode,
  onToggleDarkMode,
  onOpenCommandPalette,
  onOpenNotifications,
  onOpenSessionSwitcher,
  onLogout,
  unreadNotificationsCount,
  unreadMessagesCount,
}) => {
  const currentTabMeta = TAB_TITLES[activeTab] || {
    title: 'Bluesky Operations',
    subtitle: 'Internal Management System',
  };

  return (
    <header className="sticky top-0 z-30 h-16 border-b border-slate-200/80 bg-white/80 backdrop-blur-xl dark:border-slate-800/80 dark:bg-slate-900/80 transition-colors">
      <div className="flex h-full items-center justify-between px-4 sm:px-6">
        {/* Left: Context Breadcrumb */}
        <div className="flex items-center gap-3">
          <div className="hidden sm:flex items-center gap-2 text-xs font-medium text-slate-400 dark:text-slate-500">
            <span>Bluesky Networks</span>
            <span>/</span>
          </div>
          <div>
            <h1 className="text-base font-semibold tracking-tight text-slate-900 dark:text-white leading-tight">
              {currentTabMeta.title}
            </h1>
            <p className="hidden md:block text-xs text-slate-500 dark:text-slate-400">
              {currentTabMeta.subtitle}
            </p>
          </div>
        </div>

        {/* Right: Actions & User Capsule */}
        <div className="flex items-center gap-2 sm:gap-3">
          {/* Quick Search Button */}
          <button
            onClick={onOpenCommandPalette}
            className="flex items-center gap-2 rounded-lg border border-slate-200/80 bg-slate-100/70 px-3 py-1.5 text-xs text-slate-600 hover:bg-slate-200/70 hover:text-slate-900 dark:border-slate-800 dark:bg-slate-800/70 dark:text-slate-400 dark:hover:bg-slate-700/70 dark:hover:text-white transition-all shadow-xs"
            title="Search anything (Cmd+K)"
          >
            <Search className="h-3.5 w-3.5" />
            <span className="hidden md:inline">Quick Search...</span>
            <kbd className="hidden lg:inline rounded bg-white px-1.5 py-0.5 text-[10px] font-semibold text-slate-400 dark:bg-slate-900 dark:text-slate-500 shadow-2xs">
              ⌘K
            </kbd>
          </button>

          {/* Theme Toggle */}
          <button
            onClick={onToggleDarkMode}
            className="flex h-9 w-9 items-center justify-center rounded-lg border border-slate-200/80 bg-white text-slate-600 hover:bg-slate-100 dark:border-slate-800 dark:bg-slate-800 dark:text-slate-300 dark:hover:bg-slate-700 transition-colors"
            title={darkMode ? 'Switch to Light Mode' : 'Switch to Dark Mode'}
            aria-label="Toggle theme"
          >
            {darkMode ? <Sun className="h-4 w-4 text-amber-400" /> : <Moon className="h-4 w-4 text-slate-600" />}
          </button>

          {/* Notifications Trigger */}
          <button
            onClick={onOpenNotifications}
            className="relative flex h-9 w-9 items-center justify-center rounded-lg border border-slate-200/80 bg-white text-slate-600 hover:bg-slate-100 dark:border-slate-800 dark:bg-slate-800 dark:text-slate-300 dark:hover:bg-slate-700 transition-colors"
            title="Notification Center"
            aria-label="Notifications"
          >
            <Bell className="h-4 w-4" />
            {unreadNotificationsCount > 0 && (
              <span className="absolute -top-1 -right-1 flex h-4 min-w-4 items-center justify-center rounded-full bg-blue-600 px-1 text-[10px] font-bold text-white shadow-xs">
                {unreadNotificationsCount}
              </span>
            )}
          </button>

          {/* Role / Switcher Capsule */}
          <button
            onClick={onOpenSessionSwitcher}
            className="flex items-center gap-2 rounded-lg border border-slate-200/90 bg-white/90 px-2.5 py-1 text-xs font-medium text-slate-700 hover:border-blue-400 dark:border-slate-800 dark:bg-slate-800/90 dark:text-slate-200 dark:hover:border-blue-500 transition-all shadow-xs"
            title="Switch Active Session Role"
          >
            <div className="relative">
              {currentUser.avatarUrl ? (
                <img
                  src={currentUser.avatarUrl}
                  alt={currentUser.name}
                  className="h-6 w-6 rounded-full object-cover ring-1 ring-slate-200 dark:ring-slate-700"
                />
              ) : (
                <div className="flex h-6 w-6 items-center justify-center rounded-full bg-blue-100 text-blue-700 dark:bg-blue-900/50 dark:text-blue-300 font-semibold text-[11px]">
                  {currentUser.name.charAt(0)}
                </div>
              )}
              {currentUser.role === 'ceo' && (
                <span className="absolute -bottom-0.5 -right-0.5 h-2 w-2 rounded-full bg-amber-500 ring-1 ring-white dark:ring-slate-900" />
              )}
            </div>
            <div className="text-left hidden sm:block">
              <div className="font-semibold leading-none text-slate-900 dark:text-white flex items-center gap-1">
                <span>{currentUser.name}</span>
                {currentUser.role === 'ceo' && (
                  <span className="text-[10px] text-amber-500 font-mono">CEO</span>
                )}
              </div>
              <div className="text-[10px] text-slate-400 dark:text-slate-400 capitalize">
                {currentUser.role}
              </div>
            </div>
            <SlidersHorizontal className="h-3.5 w-3.5 text-slate-400 ml-1 hidden sm:block" />
          </button>
        </div>
      </div>
    </header>
  );
};
