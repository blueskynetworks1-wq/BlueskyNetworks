import React, { useState, useEffect } from 'react';
import {
  Search,
  X,
  Layers,
  Users,
  Video,
  Tv,
  Calendar,
  MessageSquare,
  Award,
  ShieldCheck,
  ArrowRight,
  Sun,
  Moon,
} from 'lucide-react';
import { Project, User } from '../../types';

interface CommandPaletteProps {
  isOpen: boolean;
  onClose: () => void;
  projects: Project[];
  users: User[];
  onSelectTab: (tab: string) => void;
  onSelectProject?: (projectId: string) => void;
  onToggleDarkMode: () => void;
  darkMode: boolean;
}

export const CommandPalette: React.FC<CommandPaletteProps> = ({
  isOpen,
  onClose,
  projects,
  users,
  onSelectTab,
  onSelectProject,
  onToggleDarkMode,
  darkMode,
}) => {
  const [query, setQuery] = useState('');

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === 'k') {
        e.preventDefault();
        if (isOpen) onClose();
      }
      if (e.key === 'Escape' && isOpen) {
        onClose();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  const filteredProjects = projects.filter(
    (p) =>
      p.title.toLowerCase().includes(query.toLowerCase()) ||
      p.code.toLowerCase().includes(query.toLowerCase()) ||
      p.channelName.toLowerCase().includes(query.toLowerCase())
  ).slice(0, 4);

  const filteredUsers = users.filter(
    (u) =>
      u.name.toLowerCase().includes(query.toLowerCase()) ||
      u.jobTitle.toLowerCase().includes(query.toLowerCase())
  ).slice(0, 3);

  const quickNav = [
    { name: 'Projects Matrix', tab: 'projects', icon: Layers },
    { name: 'Content Calendar', tab: 'calendar', icon: Calendar },
    { name: 'Published Tracker', tab: 'publishing', icon: Video },
    { name: 'Media Assets & Channels', tab: 'media', icon: Tv },
    { name: 'Internal Messaging', tab: 'messages', icon: MessageSquare },
    { name: 'Points & Performance', tab: 'performance', icon: Award },
    { name: 'Security & Admin', tab: 'admin', icon: ShieldCheck },
  ].filter((item) => item.name.toLowerCase().includes(query.toLowerCase()));

  return (
    <div className="fixed inset-0 z-50 flex items-start justify-center pt-20 p-4 bg-black/50 backdrop-blur-sm animate-in fade-in duration-100">
      <div className="w-full max-w-xl rounded-2xl border border-slate-200/90 bg-white/95 shadow-2xl backdrop-blur-2xl dark:border-slate-800 dark:bg-slate-900/95 overflow-hidden">
        {/* Search Input Bar */}
        <div className="flex items-center gap-3 px-4 py-3 border-b border-slate-200/70 dark:border-slate-800/70">
          <Search className="h-4 w-4 text-slate-400 shrink-0" />
          <input
            type="text"
            placeholder="Type a project code (e.g. BSN-1082), employee name, or action..."
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            autoFocus
            className="w-full bg-transparent text-sm text-slate-900 placeholder:text-slate-400 focus:outline-hidden dark:text-white"
          />
          <button
            onClick={onClose}
            className="rounded-md p-1 text-slate-400 hover:bg-slate-100 hover:text-slate-600 dark:hover:bg-slate-800 dark:hover:text-slate-200"
          >
            <X className="h-4 w-4" />
          </button>
        </div>

        {/* Results Area */}
        <div className="max-h-96 overflow-y-auto p-3 space-y-4">
          {/* Quick Actions */}
          <div>
            <div className="px-2 pb-1.5 text-[11px] font-semibold uppercase tracking-wider text-slate-400">
              Quick Actions
            </div>
            <button
              onClick={() => {
                onToggleDarkMode();
                onClose();
              }}
              className="w-full flex items-center justify-between p-2 rounded-xl text-xs hover:bg-slate-100 dark:hover:bg-slate-800/60 text-slate-700 dark:text-slate-200"
            >
              <div className="flex items-center gap-2.5">
                {darkMode ? <Sun className="h-3.5 w-3.5 text-amber-400" /> : <Moon className="h-3.5 w-3.5 text-slate-600" />}
                <span>Toggle {darkMode ? 'Light' : 'Dark'} Mode</span>
              </div>
              <span className="text-[10px] text-slate-400">Shift</span>
            </button>
          </div>

          {/* Navigation Items */}
          {quickNav.length > 0 && (
            <div>
              <div className="px-2 pb-1.5 text-[11px] font-semibold uppercase tracking-wider text-slate-400">
                Navigation
              </div>
              <div className="space-y-0.5">
                {quickNav.map((item) => {
                  const Icon = item.icon;
                  return (
                    <button
                      key={item.tab}
                      onClick={() => {
                        onSelectTab(item.tab);
                        onClose();
                      }}
                      className="w-full flex items-center justify-between p-2 rounded-xl text-xs hover:bg-slate-100 dark:hover:bg-slate-800/60 text-slate-700 dark:text-slate-200 transition-colors"
                    >
                      <div className="flex items-center gap-2.5">
                        <Icon className="h-3.5 w-3.5 text-blue-500" />
                        <span>{item.name}</span>
                      </div>
                      <ArrowRight className="h-3 w-3 text-slate-400" />
                    </button>
                  );
                })}
              </div>
            </div>
          )}

          {/* Projects */}
          {filteredProjects.length > 0 && (
            <div>
              <div className="px-2 pb-1.5 text-[11px] font-semibold uppercase tracking-wider text-slate-400">
                Projects
              </div>
              <div className="space-y-1">
                {filteredProjects.map((p) => (
                  <button
                    key={p.id}
                    onClick={() => {
                      onSelectTab('projects');
                      if (onSelectProject) onSelectProject(p.id);
                      onClose();
                    }}
                    className="w-full flex items-center justify-between p-2 rounded-xl text-xs hover:bg-blue-50/70 dark:hover:bg-blue-950/40 text-left border border-transparent hover:border-blue-200 dark:hover:border-blue-900 transition-colors"
                  >
                    <div>
                      <div className="font-semibold text-slate-900 dark:text-white flex items-center gap-2">
                        <span className="font-mono text-blue-600 dark:text-blue-400">{p.code}</span>
                        <span className="truncate max-w-xs">{p.title}</span>
                      </div>
                      <div className="text-[11px] text-slate-500 dark:text-slate-400">
                        {p.channelName} · {p.currentStage} · Assigned to {p.assignedToName}
                      </div>
                    </div>
                    <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-slate-100 text-slate-600 dark:bg-slate-800 dark:text-slate-300">
                      {p.status}
                    </span>
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Users */}
          {filteredUsers.length > 0 && (
            <div>
              <div className="px-2 pb-1.5 text-[11px] font-semibold uppercase tracking-wider text-slate-400">
                Team Members
              </div>
              <div className="space-y-1">
                {filteredUsers.map((u) => (
                  <button
                    key={u.id}
                    onClick={() => {
                      onSelectTab('team');
                      onClose();
                    }}
                    className="w-full flex items-center justify-between p-2 rounded-xl text-xs hover:bg-slate-100 dark:hover:bg-slate-800/60 text-left transition-colors"
                  >
                    <div className="flex items-center gap-2.5">
                      <div className="h-6 w-6 rounded-full bg-blue-100 text-blue-700 dark:bg-blue-900/50 dark:text-blue-300 flex items-center justify-center font-bold text-[11px]">
                        {u.name.charAt(0)}
                      </div>
                      <div>
                        <div className="font-medium text-slate-900 dark:text-white">
                          {u.name}
                        </div>
                        <div className="text-[11px] text-slate-400">
                          {u.jobTitle}
                        </div>
                      </div>
                    </div>
                    <span className="text-[10px] font-mono text-slate-400">
                      {u.points} pts
                    </span>
                  </button>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Footer shortcuts */}
        <div className="px-4 py-2 border-t border-slate-200/60 dark:border-slate-800/60 bg-slate-50/70 dark:bg-slate-900/40 text-[11px] text-slate-400 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span>Press</span>
            <kbd className="rounded bg-white px-1.5 py-0.5 font-semibold text-slate-600 dark:bg-slate-800 dark:text-slate-300 shadow-2xs">ESC</kbd>
            <span>to close</span>
          </div>
          <span>Bluesky Command Console</span>
        </div>
      </div>
    </div>
  );
};
