import React, { useState } from 'react';
import {
  MessageSquare,
  Search,
  Send,
  Paperclip,
  Check,
  CheckCheck,
  User as UserIcon,
  Shield,
  Crown,
  Link,
} from 'lucide-react';
import { Message, User } from '../../types';

interface MessagingViewProps {
  messages: Message[];
  users: User[];
  currentUser: User;
  onSendMessage: (
    sender: User,
    recipientId: string,
    content: string,
    attachmentName?: string,
    attachmentUrl?: string
  ) => void;
  onMarkRead: (messageId: string) => void;
}

export const MessagingView: React.FC<MessagingViewProps> = ({
  messages,
  users,
  currentUser,
  onSendMessage,
  onMarkRead,
}) => {
  // Available conversation partners:
  // CEO can chat with everyone.
  // Managers can chat with CEO and all team members.
  // Team members can chat with CEO and managers.
  const eligibleRecipients = users.filter((u) => u.id !== currentUser.id);

  const [selectedPartnerId, setSelectedPartnerId] = useState<string>(
    eligibleRecipients[0]?.id || ''
  );
  const [inputText, setInputText] = useState('');
  const [searchPartner, setSearchPartner] = useState('');
  const [attachmentUrl, setAttachmentUrl] = useState('');
  const [showAttachInput, setShowAttachInput] = useState(false);

  const selectedPartner = users.find((u) => u.id === selectedPartnerId) || eligibleRecipients[0];

  // Conversation between currentUser and selectedPartner
  const conversation = messages.filter(
    (m) =>
      (m.senderId === currentUser.id && m.recipientId === selectedPartner?.id) ||
      (m.senderId === selectedPartner?.id && m.recipientId === currentUser.id)
  );

  const filteredPartners = eligibleRecipients.filter(
    (u) =>
      u.name.toLowerCase().includes(searchPartner.toLowerCase()) ||
      u.jobTitle.toLowerCase().includes(searchPartner.toLowerCase())
  );

  const handleSend = (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputText.trim() && !attachmentUrl.trim()) return;

    onSendMessage(
      currentUser,
      selectedPartner.id,
      inputText,
      attachmentUrl ? 'Asset Link' : undefined,
      attachmentUrl || undefined
    );

    setInputText('');
    setAttachmentUrl('');
    setShowAttachInput(false);
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-200">
      {/* Header */}
      <div>
        <h2 className="text-lg font-bold text-slate-900 dark:text-white flex items-center gap-2">
          <MessageSquare className="h-5 w-5 text-blue-600" />
          <span>Internal Confidential Communications</span>
        </h2>
        <p className="text-xs text-slate-500 dark:text-slate-400">
          Encrypted 1-on-1 direct channels strictly bounded to participants
        </p>
      </div>

      {/* Split Messaging Console */}
      <div className="h-[620px] rounded-2xl glass-card border border-slate-200/80 dark:border-slate-800 overflow-hidden flex flex-col md:flex-row shadow-sm">
        {/* Left: Chat Contacts List */}
        <div className="w-full md:w-80 border-r border-slate-200/70 dark:border-slate-800/70 flex flex-col shrink-0 bg-slate-50/50 dark:bg-slate-900/50">
          {/* Search Contacts */}
          <div className="p-3 border-b border-slate-200/70 dark:border-slate-800/70">
            <div className="relative">
              <Search className="absolute left-3 top-2.5 h-3.5 w-3.5 text-slate-400" />
              <input
                type="text"
                placeholder="Search team member..."
                value={searchPartner}
                onChange={(e) => setSearchPartner(e.target.value)}
                className="w-full rounded-xl border border-slate-200/80 bg-white pl-8 pr-3 py-1.5 text-xs text-slate-900 focus:outline-hidden dark:border-slate-700 dark:bg-slate-800 dark:text-white"
              />
            </div>
          </div>

          {/* Contacts List */}
          <div className="flex-1 overflow-y-auto p-2 space-y-1">
            {filteredPartners.map((partner) => {
              const isSelected = partner.id === selectedPartner?.id;
              // Check unread count from this partner
              const unreadFromPartner = messages.filter(
                (m) => m.senderId === partner.id && m.recipientId === currentUser.id && !m.isRead
              ).length;

              // Last message
              const lastMsg = messages
                .filter(
                  (m) =>
                    (m.senderId === currentUser.id && m.recipientId === partner.id) ||
                    (m.senderId === partner.id && m.recipientId === currentUser.id)
                )
                .slice(-1)[0];

              return (
                <button
                  key={partner.id}
                  onClick={() => setSelectedPartnerId(partner.id)}
                  className={`w-full flex items-center justify-between p-2.5 rounded-xl text-left transition-all ${
                    isSelected
                      ? 'bg-blue-600 text-white shadow-xs'
                      : 'hover:bg-slate-200/60 dark:hover:bg-slate-800/60 text-slate-800 dark:text-slate-200'
                  }`}
                >
                  <div className="flex items-center gap-2.5 min-w-0">
                    <div className="relative shrink-0">
                      {partner.avatarUrl ? (
                        <img
                          src={partner.avatarUrl}
                          alt={partner.name}
                          className="h-9 w-9 rounded-full object-cover ring-1 ring-slate-200 dark:ring-slate-700"
                        />
                      ) : (
                        <div
                          className={`flex h-9 w-9 items-center justify-center rounded-full font-bold text-xs ${
                            isSelected
                              ? 'bg-white/20 text-white'
                              : 'bg-blue-100 text-blue-700 dark:bg-blue-900/50 dark:text-blue-300'
                          }`}
                        >
                          {partner.name.charAt(0)}
                        </div>
                      )}
                      {partner.role === 'ceo' && (
                        <div className="absolute -bottom-0.5 -right-0.5 flex h-3.5 w-3.5 items-center justify-center rounded-full bg-amber-500 text-white shadow-xs">
                          <Crown className="h-2 w-2" />
                        </div>
                      )}
                    </div>

                    <div className="min-w-0 flex-1">
                      <div className="flex items-center justify-between mb-0.5">
                        <span className="text-xs font-bold truncate">
                          {partner.name}
                        </span>
                        {lastMsg && (
                          <span
                            className={`text-[10px] font-mono shrink-0 ml-1 ${
                              isSelected ? 'text-blue-100' : 'text-slate-400'
                            }`}
                          >
                            {lastMsg.createdAt.split(' ')[1] || ''}
                          </span>
                        )}
                      </div>
                      <div
                        className={`text-[11px] truncate ${
                          isSelected ? 'text-blue-100' : 'text-slate-400'
                        }`}
                      >
                        {lastMsg ? lastMsg.content : partner.jobTitle}
                      </div>
                    </div>
                  </div>

                  {unreadFromPartner > 0 && !isSelected && (
                    <span className="ml-2 flex h-4 min-w-4 items-center justify-center rounded-full bg-blue-600 px-1 text-[10px] font-bold text-white shadow-xs shrink-0">
                      {unreadFromPartner}
                    </span>
                  )}
                </button>
              );
            })}
          </div>
        </div>

        {/* Right: Active Chat Viewport */}
        {selectedPartner ? (
          <div className="flex-1 flex flex-col h-full bg-white dark:bg-slate-900">
            {/* Chat Partner Header */}
            <div className="h-14 px-5 border-b border-slate-200/70 dark:border-slate-800/70 flex items-center justify-between shrink-0 bg-white/80 dark:bg-slate-900/80 backdrop-blur-md">
              <div className="flex items-center gap-3">
                <div className="relative">
                  {selectedPartner.avatarUrl ? (
                    <img
                      src={selectedPartner.avatarUrl}
                      alt={selectedPartner.name}
                      className="h-8 w-8 rounded-full object-cover"
                    />
                  ) : (
                    <div className="flex h-8 w-8 items-center justify-center rounded-full bg-slate-100 dark:bg-slate-800 font-bold text-xs text-slate-700 dark:text-slate-300">
                      {selectedPartner.name.charAt(0)}
                    </div>
                  )}
                  <span className="absolute -bottom-0.5 -right-0.5 h-2 w-2 rounded-full bg-emerald-500 ring-2 ring-white dark:ring-slate-900" />
                </div>
                <div>
                  <div className="text-xs font-bold text-slate-900 dark:text-white flex items-center gap-1.5">
                    <span>{selectedPartner.name}</span>
                    <span className="text-[10px] font-medium text-slate-400">
                      ({selectedPartner.jobTitle})
                    </span>
                  </div>
                  <div className="text-[10px] text-emerald-600 dark:text-emerald-400 font-medium">
                    Active Session · Direct Channel
                  </div>
                </div>
              </div>
            </div>

            {/* Message Stream */}
            <div className="flex-1 overflow-y-auto p-4 space-y-3 bg-slate-50/40 dark:bg-slate-950/20">
              {conversation.length === 0 ? (
                <div className="h-full flex flex-col items-center justify-center text-center p-6 text-slate-400">
                  <MessageSquare className="h-8 w-8 text-slate-300 mb-2" />
                  <p className="text-xs font-medium">No previous messages with {selectedPartner.name}</p>
                  <p className="text-[11px] text-slate-400">Send a confidential memo or render review request below.</p>
                </div>
              ) : (
                conversation.map((msg) => {
                  const isMine = msg.senderId === currentUser.id;
                  return (
                    <div
                      key={msg.id}
                      className={`flex flex-col ${isMine ? 'items-end' : 'items-start'}`}
                    >
                      <div
                        className={`max-w-md rounded-2xl px-4 py-2.5 text-xs shadow-xs leading-relaxed ${
                          isMine
                            ? 'bg-blue-600 text-white rounded-br-xs'
                            : 'bg-white border border-slate-200/80 text-slate-900 dark:border-slate-800 dark:bg-slate-800 dark:text-slate-100 rounded-bl-xs'
                        }`}
                      >
                        <p>{msg.content}</p>

                        {/* Optional Attachment */}
                        {msg.attachmentUrl && (
                          <a
                            href={msg.attachmentUrl}
                            target="_blank"
                            rel="noreferrer"
                            className={`mt-2 flex items-center gap-1.5 p-2 rounded-lg text-[11px] font-medium border ${
                              isMine
                                ? 'bg-blue-700/60 border-blue-500/50 text-blue-100 hover:bg-blue-700'
                                : 'bg-slate-100 border-slate-200 dark:bg-slate-700 dark:border-slate-600 text-blue-600 dark:text-blue-300'
                            }`}
                          >
                            <Link className="h-3 w-3 shrink-0" />
                            <span className="truncate">{msg.attachmentName || msg.attachmentUrl}</span>
                          </a>
                        )}
                      </div>

                      <div className="flex items-center gap-1 text-[10px] text-slate-400 font-mono mt-1 px-1">
                        <span>{msg.createdAt}</span>
                        {isMine && (
                          <span>
                            {msg.isRead ? (
                              <CheckCheck className="h-3 w-3 text-blue-500" />
                            ) : (
                              <Check className="h-3 w-3 text-slate-400" />
                            )}
                          </span>
                        )}
                      </div>
                    </div>
                  );
                })
              )}
            </div>

            {/* Input Composer */}
            <form onSubmit={handleSend} className="p-3 border-t border-slate-200/70 dark:border-slate-800/70 bg-white dark:bg-slate-900 space-y-2">
              {showAttachInput && (
                <div className="flex items-center gap-2 p-2 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 animate-in fade-in">
                  <Link className="h-3.5 w-3.5 text-blue-500" />
                  <input
                    type="url"
                    placeholder="Attach asset or review URL (e.g. https://drive.google.com/...)"
                    value={attachmentUrl}
                    onChange={(e) => setAttachmentUrl(e.target.value)}
                    className="w-full bg-transparent text-xs text-slate-900 dark:text-white focus:outline-hidden"
                  />
                  <button
                    type="button"
                    onClick={() => setShowAttachInput(false)}
                    className="text-slate-400 hover:text-slate-600 text-xs"
                  >
                    Cancel
                  </button>
                </div>
              )}

              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => setShowAttachInput(!showAttachInput)}
                  className="p-2 rounded-xl text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800 hover:text-slate-700 dark:hover:text-slate-200 transition-colors"
                  title="Attach Asset Link"
                >
                  <Paperclip className="h-4 w-4" />
                </button>

                <input
                  type="text"
                  placeholder={`Direct message to ${selectedPartner.name}...`}
                  value={inputText}
                  onChange={(e) => setInputText(e.target.value)}
                  className="flex-1 rounded-xl border border-slate-200 bg-slate-50/70 px-4 py-2 text-xs text-slate-900 focus:bg-white focus:border-blue-500 focus:outline-hidden dark:border-slate-700 dark:bg-slate-800 dark:text-white"
                />

                <button
                  type="submit"
                  disabled={!inputText.trim() && !attachmentUrl.trim()}
                  className="flex h-8 w-8 items-center justify-center rounded-xl bg-blue-600 text-white hover:bg-blue-700 disabled:opacity-40 shadow-xs transition-colors"
                >
                  <Send className="h-3.5 w-3.5" />
                </button>
              </div>
            </form>
          </div>
        ) : (
          <div className="flex-1 flex items-center justify-center text-xs text-slate-400">
            Select a team member to open confidential chat.
          </div>
        )}
      </div>
    </div>
  );
};
