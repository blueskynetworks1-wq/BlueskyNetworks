import React, { useState } from 'react';
import {
  Award,
  Crown,
  TrendingUp,
  Sliders,
  CheckCircle2,
  AlertTriangle,
  Flame,
  Shield,
  Edit2,
  Check,
  Clock,
  Timer,
  BarChart3,
  Sparkles,
} from 'lucide-react';
import { User, ScoringRule, PointAuditEntry, Project } from '../../types';
import { formatSecondsToDuration } from '../common/ProjectTimerWidget';

interface PerformanceViewProps {
  users: User[];
  scoringRules: ScoringRule[];
  pointAudits: PointAuditEntry[];
  projects?: Project[];
  currentUser: User;
  onUpdateScoringRule: (ruleId: string, delta: number) => void;
}

export const PerformanceView: React.FC<PerformanceViewProps> = ({
  users,
  scoringRules,
  pointAudits,
  projects = [],
  currentUser,
  onUpdateScoringRule,
}) => {
  const isCeo = currentUser.role === 'ceo';
  const isMember = currentUser.role === 'member';

  const [editingRuleId, setEditingRuleId] = useState<string | null>(null);
  const [editedDelta, setEditedDelta] = useState<number>(0);

  const creators = users
    .filter((u) => u.role === 'member')
    .sort((a, b) => b.points - a.points);

  // Time metrics calculations
  const totalSecondsLogged = projects.reduce(
    (acc, p) => acc + (p.timeSpentSeconds || 0),
    0
  );
  const totalHoursLogged = (totalSecondsLogged / 3600).toFixed(1);

  const completedProjectsWithTime = projects.filter(
    (p) => p.status === 'Completed' && (p.timeSpentSeconds || 0) > 0
  );
  const avgTimePerVideoHours = completedProjectsWithTime.length
    ? (
        completedProjectsWithTime.reduce((acc, p) => acc + (p.timeSpentSeconds || 0), 0) /
        completedProjectsWithTime.length /
        3600
      ).toFixed(1)
    : '11.8';

  const activeTimersCount = projects.filter((p) => Boolean(p.activeTimerStartedAt)).length;

  const handleStartEdit = (rule: ScoringRule) => {
    setEditingRuleId(rule.id);
    setEditedDelta(rule.pointsDelta);
  };

  const handleSaveEdit = (ruleId: string) => {
    onUpdateScoringRule(ruleId, editedDelta);
    setEditingRuleId(null);
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-200">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-lg font-bold text-slate-900 dark:text-white flex items-center gap-2">
            <Award className="h-5 w-5 text-amber-500" />
            <span>Points & Performance Architecture</span>
          </h2>
          <p className="text-xs text-slate-500 dark:text-slate-400">
            Automated delivery score calculation, actual task time visualization, and audit ledgers
          </p>
        </div>
      </div>

      {/* Actual Time Tracking Visualization KPI Strip */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        <div className="p-4 rounded-2xl glass-card border border-slate-200/80 dark:border-slate-800">
          <div className="flex items-center justify-between text-slate-400 mb-1">
            <span className="text-xs font-medium">Total Studio Time Logged</span>
            <Clock className="h-4 w-4 text-blue-500" />
          </div>
          <div className="text-2xl font-bold tracking-tight text-slate-900 dark:text-white font-mono tabular-nums">
            {totalHoursLogged} hrs
          </div>
          <div className="text-[11px] text-slate-400 mt-1">Across all pipeline stages</div>
        </div>

        <div className="p-4 rounded-2xl glass-card border border-slate-200/80 dark:border-slate-800">
          <div className="flex items-center justify-between text-slate-400 mb-1">
            <span className="text-xs font-medium">Avg Time per Video</span>
            <Timer className="h-4 w-4 text-emerald-500" />
          </div>
          <div className="text-2xl font-bold tracking-tight text-emerald-600 dark:text-emerald-400 font-mono tabular-nums">
            {avgTimePerVideoHours} hrs
          </div>
          <div className="text-[11px] text-slate-400 mt-1">From prompt to final export</div>
        </div>

        <div className="p-4 rounded-2xl glass-card border border-slate-200/80 dark:border-slate-800">
          <div className="flex items-center justify-between text-slate-400 mb-1">
            <span className="text-xs font-medium">Active Work Timers</span>
            <span className="relative flex h-2.5 w-2.5">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75" />
              <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-emerald-500" />
            </span>
          </div>
          <div className="text-2xl font-bold tracking-tight text-slate-900 dark:text-white font-mono tabular-nums">
            {activeTimersCount} active
          </div>
          <div className="text-[11px] text-emerald-600 dark:text-emerald-400 mt-1">
            {activeTimersCount > 0 ? 'Live sessions in flight' : 'No active stopwatches'}
          </div>
        </div>

        <div className="p-4 rounded-2xl glass-card border border-slate-200/80 dark:border-slate-800">
          <div className="flex items-center justify-between text-slate-400 mb-1">
            <span className="text-xs font-medium">On-Time Accuracy</span>
            <CheckCircle2 className="h-4 w-4 text-purple-500" />
          </div>
          <div className="text-2xl font-bold tracking-tight text-purple-600 dark:text-purple-400 font-mono tabular-nums">
            96.8%
          </div>
          <div className="text-[11px] text-slate-400 mt-1">Delivered ahead of deadline</div>
        </div>
      </div>

      {/* Creator Leaderboard Cards (Showing Points & Actual Hours Logged) */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {creators.map((creator, idx) => {
          // Calculate creator's actual logged hours from projects
          const creatorProjects = projects.filter((p) => p.assignedToId === creator.id);
          const creatorSeconds = creatorProjects.reduce(
            (acc, p) => acc + (p.timeSpentSeconds || 0),
            0
          );
          const loggedHours = creatorSeconds > 0
            ? (creatorSeconds / 3600).toFixed(1)
            : (creator.totalHoursLogged || 120).toString();

          return (
            <div
              key={creator.id}
              className={`p-5 rounded-2xl border transition-all ${
                idx === 0
                  ? 'border-amber-300 bg-gradient-to-br from-amber-50/80 via-white to-amber-50/30 dark:border-amber-800/60 dark:from-amber-950/20 dark:via-slate-900 dark:to-slate-900 shadow-md ring-1 ring-amber-400/20'
                  : 'glass-card border-slate-200/80 dark:border-slate-800'
              }`}
            >
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center gap-2">
                  {idx === 0 ? (
                    <div className="flex h-7 w-7 items-center justify-center rounded-xl bg-amber-500 text-white shadow-xs">
                      <Crown className="h-4 w-4" />
                    </div>
                  ) : (
                    <div className="flex h-7 w-7 items-center justify-center rounded-xl bg-slate-100 text-slate-700 dark:bg-slate-800 dark:text-slate-300 font-bold font-mono text-xs">
                      #{idx + 1}
                    </div>
                  )}
                  <span className="text-xs font-bold text-slate-900 dark:text-white">
                    {idx === 0 ? 'Top Contributor' : `Rank #${idx + 1}`}
                  </span>
                </div>
                <span className="font-mono text-sm font-bold text-blue-600 dark:text-blue-400 tabular-nums">
                  {creator.points} pts
                </span>
              </div>

              <div className="space-y-1">
                <div className="text-sm font-semibold text-slate-900 dark:text-white">
                  {creator.name}
                </div>
                <div className="text-xs text-slate-500 dark:text-slate-400">
                  {creator.jobTitle}
                </div>
              </div>

              <div className="mt-4 pt-3 border-t border-slate-200/60 dark:border-slate-800/80 grid grid-cols-3 gap-2 text-xs">
                <div>
                  <span className="text-slate-400 text-[10px]">On-Time</span>
                  <div className="font-bold text-emerald-600 dark:text-emerald-400 tabular-nums">
                    {creator.onTimeRate}%
                  </div>
                </div>
                <div>
                  <span className="text-slate-400 text-[10px]">Completed</span>
                  <div className="font-bold text-slate-900 dark:text-white tabular-nums">
                    {creator.completedProjectsCount} vids
                  </div>
                </div>
                <div>
                  <span className="text-slate-400 text-[10px]">Time Spent</span>
                  <div className="font-mono font-bold text-blue-600 dark:text-blue-400 tabular-nums">
                    {loggedHours}h
                  </div>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Visual Time Investment Breakdown: Creator Time Allocation & Project Time Matrix */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Creator Time Investment Bars */}
        <div className="p-5 rounded-2xl glass-card border border-slate-200/80 dark:border-slate-800 space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-semibold text-slate-900 dark:text-white flex items-center gap-2">
              <Clock className="h-4 w-4 text-blue-500" />
              <span>Creator Time Investment & Output</span>
            </h3>
            <span className="text-xs text-slate-400 font-mono">Actual Logged Hours</span>
          </div>

          <div className="space-y-3 pt-1">
            {creators.map((c) => {
              const cProjects = projects.filter((p) => p.assignedToId === c.id);
              const cSec = cProjects.reduce((acc, p) => acc + (p.timeSpentSeconds || 0), 0);
              const hrs = cSec > 0 ? (cSec / 3600).toFixed(1) : (c.totalHoursLogged || 120).toString();
              const pct = Math.min(100, Math.round((parseFloat(hrs) / 160) * 100));

              return (
                <div key={c.id} className="space-y-1.5 text-xs">
                  <div className="flex items-center justify-between">
                    <span className="font-semibold text-slate-900 dark:text-white">
                      {c.name}
                    </span>
                    <span className="font-mono text-slate-500 dark:text-slate-400 tabular-nums">
                      <strong className="text-slate-900 dark:text-white">{hrs} hrs</strong> ({pct}% of monthly capacity)
                    </span>
                  </div>
                  <div className="h-2.5 w-full rounded-full bg-slate-100 dark:bg-slate-800 overflow-hidden">
                    <div
                      className="h-full rounded-full bg-gradient-to-r from-blue-500 to-indigo-600 transition-all duration-500"
                      style={{ width: `${pct}%` }}
                    />
                  </div>
                </div>
              );
            })}
          </div>

          <div className="grid grid-cols-3 gap-2 pt-2 border-t border-slate-100 dark:border-slate-800 text-[11px] text-slate-400">
            <div>Research/Script: <strong className="text-slate-700 dark:text-slate-200">28%</strong></div>
            <div>AI/3D Gen: <strong className="text-slate-700 dark:text-slate-200">38%</strong></div>
            <div>Editing/LUTs: <strong className="text-slate-700 dark:text-slate-200">34%</strong></div>
          </div>
        </div>

        {/* Project Task Time Matrix */}
        <div className="p-5 rounded-2xl glass-card border border-slate-200/80 dark:border-slate-800 space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-semibold text-slate-900 dark:text-white flex items-center gap-2">
              <BarChart3 className="h-4 w-4 text-indigo-500" />
              <span>Project Task Time Logged Matrix</span>
            </h3>
            <span className="text-xs text-slate-400">Cumulative Duration</span>
          </div>

          <div className="space-y-2.5 max-h-64 overflow-y-auto pr-1">
            {projects.slice(0, 5).map((p) => {
              const isTiming = Boolean(p.activeTimerStartedAt);
              return (
                <div
                  key={p.id}
                  className="p-2.5 rounded-xl border border-slate-100 bg-slate-50/60 dark:border-slate-800 dark:bg-slate-800/40 text-xs flex items-center justify-between gap-3"
                >
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center gap-2 mb-0.5">
                      <span className="font-mono text-xs font-bold text-blue-600 dark:text-blue-400">
                        {p.code}
                      </span>
                      <span className="font-semibold text-slate-900 dark:text-white truncate">
                        {p.title}
                      </span>
                    </div>
                    <div className="text-[11px] text-slate-400">
                      {p.assignedToName} · Stage: {p.currentStage}
                      {p.timeLogs && p.timeLogs.length > 0 && (
                        <span> · {p.timeLogs.length} session{p.timeLogs.length > 1 ? 's' : ''}</span>
                      )}
                    </div>
                  </div>

                  <div className="text-right shrink-0">
                    <div className="flex items-center gap-1.5 font-mono font-bold text-slate-900 dark:text-white tabular-nums">
                      {isTiming && (
                        <span className="h-2 w-2 rounded-full bg-emerald-500 animate-pulse" />
                      )}
                      <span>{formatSecondsToDuration(p.timeSpentSeconds || 0)}</span>
                    </div>
                    <span
                      className={`text-[9px] font-bold px-1.5 py-0.5 rounded-sm ${
                        p.status === 'Completed'
                          ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950/60 dark:text-emerald-300'
                          : p.status === 'In Progress'
                          ? 'bg-blue-100 text-blue-800 dark:bg-blue-950/60 dark:text-blue-300'
                          : 'bg-slate-100 text-slate-600 dark:bg-slate-800 dark:text-slate-300'
                      }`}
                    >
                      {p.status}
                    </span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>

      {/* Scoring Rules Matrix */}
      <div className="p-5 rounded-2xl glass-card border border-slate-200/80 dark:border-slate-800 space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="text-sm font-semibold text-slate-900 dark:text-white">
              Studio Performance Scoring Rules
            </h3>
            <p className="text-xs text-slate-400">
              {isCeo
                ? 'CEO Configurable: Rules automatically applied upon managerial project sign-off'
                : 'Official point weighting criteria enforced across all media pipelines'}
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
          {scoringRules.map((rule) => {
            const isEditing = editingRuleId === rule.id;
            return (
              <div
                key={rule.id}
                className="p-4 rounded-xl border border-slate-200/70 bg-white dark:border-slate-800 dark:bg-slate-800/40 text-xs flex flex-col justify-between"
              >
                <div>
                  <div className="flex items-center justify-between mb-1.5">
                    <span className="font-bold text-slate-900 dark:text-white">
                      {rule.name}
                    </span>
                    {isEditing ? (
                      <div className="flex items-center gap-1">
                        <input
                          type="number"
                          value={editedDelta}
                          onChange={(e) => setEditedDelta(parseInt(e.target.value, 10) || 0)}
                          className="w-14 px-1.5 py-0.5 font-mono text-xs border rounded bg-white text-slate-900 dark:bg-slate-900 dark:text-white"
                        />
                        <button
                          onClick={() => handleSaveEdit(rule.id)}
                          className="p-1 rounded bg-emerald-600 text-white"
                        >
                          <Check className="h-3 w-3" />
                        </button>
                      </div>
                    ) : (
                      <div className="flex items-center gap-1.5">
                        <span
                          className={`font-mono font-bold text-xs tabular-nums px-2 py-0.5 rounded-full ${
                            rule.pointsDelta >= 0
                              ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950/60 dark:text-emerald-300'
                              : 'bg-rose-100 text-rose-800 dark:bg-rose-950/60 dark:text-rose-300'
                          }`}
                        >
                          {rule.pointsDelta > 0 ? `+${rule.pointsDelta}` : rule.pointsDelta} pts
                        </span>
                        {isCeo && (
                          <button
                            onClick={() => handleStartEdit(rule)}
                            className="p-1 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200"
                            title="Edit Rule Weight"
                          >
                            <Edit2 className="h-3 w-3" />
                          </button>
                        )}
                      </div>
                    )}
                  </div>
                  <p className="text-[11px] text-slate-500 dark:text-slate-400 leading-relaxed">
                    {rule.description}
                  </p>
                </div>
                <div className="mt-3 pt-2 border-t border-slate-100 dark:border-slate-800 text-[10px] text-slate-400 font-mono">
                  Trigger: {rule.condition}
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Point Audits Table */}
      <div className="p-5 rounded-2xl glass-card border border-slate-200/80 dark:border-slate-800 space-y-4">
        <div className="flex items-center justify-between">
          <h3 className="text-sm font-semibold text-slate-900 dark:text-white">
            Audit Ledger of Point Transactions ({pointAudits.length})
          </h3>
          <span className="text-[11px] text-slate-400">
            Immutable tracking for both automated and CEO-adjusted points
          </span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead>
              <tr className="border-b border-slate-200/70 text-slate-400 font-semibold uppercase text-[10px] tracking-wider">
                <th className="py-2.5 px-3">Team Member</th>
                <th className="py-2.5 px-3">Project Ref</th>
                <th className="py-2.5 px-3">Justification / Reason</th>
                <th className="py-2.5 px-3">Adjusted By</th>
                <th className="py-2.5 px-3">Timestamp</th>
                <th className="py-2.5 px-3 text-right">Points</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800/60 font-medium">
              {pointAudits.map((pa) => (
                <tr key={pa.id} className="hover:bg-slate-50/50 dark:hover:bg-slate-800/30">
                  <td className="py-2.5 px-3 font-semibold text-slate-900 dark:text-white">
                    {pa.userName}
                  </td>
                  <td className="py-2.5 px-3 font-mono text-blue-600 dark:text-blue-400">
                    {pa.projectCode || '—'}
                  </td>
                  <td className="py-2.5 px-3 text-slate-700 dark:text-slate-300">
                    {pa.reason}
                  </td>
                  <td className="py-2.5 px-3 text-slate-500 dark:text-slate-400">
                    {pa.adjustedBy}
                  </td>
                  <td className="py-2.5 px-3 font-mono text-[11px] text-slate-400">
                    {pa.timestamp}
                  </td>
                  <td className="py-2.5 px-3 text-right">
                    <span
                      className={`font-mono font-bold tabular-nums ${
                        pa.points >= 0
                          ? 'text-emerald-600 dark:text-emerald-400'
                          : 'text-rose-600 dark:text-rose-400'
                      }`}
                    >
                      {pa.points > 0 ? `+${pa.points}` : pa.points} pts
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
