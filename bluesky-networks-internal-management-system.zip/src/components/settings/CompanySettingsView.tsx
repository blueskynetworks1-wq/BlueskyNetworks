import React, { useState } from 'react';
import {
  Settings,
  Shield,
  Download,
  RotateCcw,
  CheckCircle2,
  Tv,
  Users,
  Bell,
  Lock,
} from 'lucide-react';
import { User } from '../../types';

interface CompanySettingsViewProps {
  currentUser: User;
  onResetSeedData: () => void;
  onExportJson: () => string;
}

export const CompanySettingsView: React.FC<CompanySettingsViewProps> = ({
  currentUser,
  onResetSeedData,
  onExportJson,
}) => {
  const [downloadSuccess, setDownloadSuccess] = useState(false);

  const handleExport = () => {
    const data = onExportJson();
    const blob = new Blob([data], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `bluesky_networks_backup_${new Date().toISOString().substring(0, 10)}.json`;
    a.click();
    URL.revokeObjectURL(url);
    setDownloadSuccess(true);
    setTimeout(() => setDownloadSuccess(false), 3000);
  };

  return (
    <div className="space-y-6 max-w-4xl mx-auto animate-in fade-in duration-200">
      {/* Header */}
      <div>
        <h2 className="text-lg font-bold text-slate-900 dark:text-white flex items-center gap-2">
          <Settings className="h-5 w-5 text-blue-600" />
          <span>Company & Studio Preferences</span>
        </h2>
        <p className="text-xs text-slate-500 dark:text-slate-400">
          Global studio operating parameters, backup exports, and data integrity
        </p>
      </div>

      {/* Studio Profile Details */}
      <div className="p-6 rounded-2xl glass-card border border-slate-200/80 dark:border-slate-800 space-y-4 text-xs">
        <h3 className="text-sm font-bold text-slate-900 dark:text-white">
          Company Master Profile
        </h3>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div>
            <span className="text-[11px] text-slate-400 font-medium">Business Entity</span>
            <div className="font-semibold text-slate-900 dark:text-white mt-0.5">
              Bluesky Networks (Private Digital Media)
            </div>
          </div>

          <div>
            <span className="text-[11px] text-slate-400 font-medium">Founder & CEO</span>
            <div className="font-semibold text-slate-900 dark:text-white mt-0.5">
              Manuja Rathnayake
            </div>
          </div>

          <div>
            <span className="text-[11px] text-slate-400 font-medium">Design & Interface Standard</span>
            <div className="font-semibold text-slate-900 dark:text-white mt-0.5">
              Apple Cupertino macOS / iOS Glassmorphism
            </div>
          </div>

          <div>
            <span className="text-[11px] text-slate-400 font-medium">Authorization Architecture</span>
            <div className="font-semibold text-blue-600 dark:text-blue-400 mt-0.5 font-mono">
              Strict RBAC · Zero-Leak Confidentiality
            </div>
          </div>
        </div>
      </div>

      {/* Backup and Data Resilience */}
      <div className="p-6 rounded-2xl glass-card border border-slate-200/80 dark:border-slate-800 space-y-4 text-xs">
        <h3 className="text-sm font-bold text-slate-900 dark:text-white">
          Data Management & Archival
        </h3>
        <p className="text-slate-500 dark:text-slate-400 leading-relaxed">
          Export a complete, self-contained JSON snapshot of all current projects, channel assets, published releases, audit trails, and points ledgers for cold-storage backup.
        </p>

        <div className="flex flex-wrap items-center gap-3 pt-2">
          <button
            onClick={handleExport}
            className="flex items-center gap-2 rounded-xl bg-blue-600 px-4 py-2.5 font-semibold text-white hover:bg-blue-700 shadow-md shadow-blue-600/20 transition-all"
          >
            <Download className="h-4 w-4" />
            <span>Download Complete JSON Backup</span>
          </button>

          {downloadSuccess && (
            <span className="flex items-center gap-1.5 text-xs font-semibold text-emerald-600 dark:text-emerald-400 animate-in fade-in">
              <CheckCircle2 className="h-4 w-4" />
              <span>Snapshot downloaded successfully!</span>
            </span>
          )}
        </div>

        <div className="pt-4 border-t border-slate-100 dark:border-slate-800">
          <div className="flex items-center justify-between">
            <div>
              <div className="font-semibold text-slate-900 dark:text-white">
                Revert to Initial Studio Seed State
              </div>
              <div className="text-[11px] text-slate-400">
                Restores original team accounts (Manuja, Danuji, Imasha, Kaveen, Nimna, Dilshan) and baseline projects.
              </div>
            </div>
            <button
              onClick={() => {
                if (confirm('Revert all workspace data back to pristine seed defaults?')) {
                  onResetSeedData();
                  alert('Workspace state restored to initial demo seeds.');
                }
              }}
              className="px-3.5 py-2 rounded-xl border border-rose-200 bg-rose-50 text-rose-700 hover:bg-rose-100 dark:border-rose-900 dark:bg-rose-950/40 dark:text-rose-300 font-semibold transition-colors"
            >
              Reset Seed Data
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
