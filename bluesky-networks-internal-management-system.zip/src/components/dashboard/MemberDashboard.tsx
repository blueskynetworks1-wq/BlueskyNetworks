import React from 'react';
import {
  Clock,
  Layers,
  Award,
  AlertCircle,
  CheckCircle2,
  Calendar,
  MessageSquare,
  ArrowRight,
  Flame,
  FileText,
  Video,
  UploadCloud,
  ChevronRight,
  Sparkles,
} from 'lucide-react';
import { Project, User, Message, NotificationItem } from '../../types';

import { ProjectTimerWidget, formatSecondsToDuration } from '../common/ProjectTimerWidget';

interface MemberDashboardProps {
  currentUser: User;
  projects: Project[];
  messages: Message[];
  notifications: NotificationItem[];
  onSelectProject: (projectId: string) => void;
  onNavigateTab: (tab: string) => void;
  onStartTimer?: (projectId: string) => void;
  onStopTimer?: (projectId: string, notes?: string) => void;
}

export const MemberDashboard: React.FC<MemberDashboardProps> = ({
  currentUser,
  projects,
  messages,
  notifications,
  onSelectProject,
  onNavigateTab,
  onStartTimer,
  onStopTimer,
}) => {
  // My projects only (strict RBAC guarantees projects is already filtered, but re-assert)
  const myProjects = projects.filter((p) => p.assignedToId === currentUser.id);
  const activeProjects = myProjects.filter((p) => p.status !== 'Completed' && p.status !== 'Cancelled');
  const completedProjects = myProjects.filter((p) => p.status === 'Completed');
  const overdueProjects = myProjects.filter((p) => p.status === 'Overdue');

  // Today's focus is the highest priority or nearest deadline project
  const focusProject = activeProjects[0] || null;

  return (
    <div className="space-y-6 animate-in fade-in duration-200">
      {/* Personalized Welcome Banner */}
      <div className="p-6 rounded-2xl glass-card border border-slate-200/80 dark:border-slate-800 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="text-xs font-semibold px-2.5 py-0.5 rounded-full bg-blue-100 text-blue-700 dark:bg-blue-950/60 dark:text-blue-300">
              Creative Workspace
            </span>
            <span className="text-xs text-slate-400">· Confidential Session</span>
          </div>
          <h2 className="text-xl font-bold tracking-tight text-slate-900 dark:text-white">
            Hello, {currentUser.name.split(' ')[0]}
          </h2>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
            You have <strong className="text-blue-600 dark:text-blue-400">{activeProjects.length} active deliverable{activeProjects.length !== 1 ? 's' : ''}</strong> assigned to your pipeline today.
          </p>
        </div>

        {/* Performance Metric Pill */}
        <div className="flex items-center gap-3 p-3 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200/70 dark:border-slate-800">
          <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-amber-500 text-white shadow-xs">
            <Award className="h-5 w-5" />
          </div>
          <div>
            <div className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider">
              Performance Score
            </div>
            <div className="text-lg font-bold text-slate-900 dark:text-white tabular-nums flex items-center gap-1.5">
              <span>{currentUser.points} pts</span>
              <span className="text-xs font-medium text-emerald-500 bg-emerald-50 dark:bg-emerald-950/40 px-1.5 py-0.5 rounded-sm">
                {currentUser.onTimeRate}% on-time
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* TODAY'S FOCUS: Hero Card */}
      {focusProject ? (
        <div className="relative overflow-hidden p-6 rounded-2xl bg-gradient-to-br from-blue-900 via-indigo-900 to-slate-900 text-white shadow-xl">
          <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-6">
            <div className="space-y-3 max-w-2xl">
              <div className="flex items-center gap-2 text-xs">
                <span className="flex items-center gap-1 font-bold bg-amber-400 text-amber-950 px-2.5 py-0.5 rounded-full">
                  <Flame className="h-3.5 w-3.5" />
                  Today's Top Priority
                </span>
                <span className="font-mono text-blue-200">{focusProject.code}</span>
                <span>·</span>
                <span className="text-slate-300">{focusProject.channelName}</span>
              </div>

              <h3 className="text-lg sm:text-xl font-bold tracking-tight">
                {focusProject.title}
              </h3>

              <p className="text-xs text-slate-200 line-clamp-2">
                {focusProject.description}
              </p>

              {/* Progress Stage */}
              <div className="pt-2 space-y-1.5">
                <div className="flex items-center justify-between text-xs text-slate-300">
                  <span>Current Production Stage: <strong className="text-white">{focusProject.currentStage}</strong></span>
                  <span className="font-mono text-amber-300">Due: {focusProject.deadline}</span>
                </div>
                <div className="h-2 w-full rounded-full bg-white/20 overflow-hidden">
                  <div
                    className="h-full rounded-full bg-gradient-to-r from-blue-400 to-indigo-300"
                    style={{
                      width:
                        focusProject.currentStage === 'Research'
                          ? '15%'
                          : focusProject.currentStage === 'Script Writing'
                          ? '30%'
                          : focusProject.currentStage === 'Prompt Creation'
                          ? '45%'
                          : focusProject.currentStage === 'Video Generation'
                          ? '60%'
                          : focusProject.currentStage === 'Editing'
                          ? '75%'
                          : focusProject.currentStage === 'Submitted'
                          ? '90%'
                          : '100%',
                    }}
                  />
                </div>
              </div>

              {/* In-Card Live Timer Control */}
              {focusProject.status === 'In Progress' && onStartTimer && onStopTimer && (
                <div className="pt-2">
                  <ProjectTimerWidget
                    project={focusProject}
                    currentUser={currentUser}
                    onStartTimer={onStartTimer}
                    onStopTimer={onStopTimer}
                    compact={false}
                  />
                </div>
              )}
            </div>

            <div className="flex flex-col sm:flex-row lg:flex-col gap-2 shrink-0">
              <button
                onClick={() => onSelectProject(focusProject.id)}
                className="flex items-center justify-center gap-2 rounded-xl bg-white px-5 py-3 text-xs font-bold text-slate-900 hover:bg-slate-100 shadow-lg shadow-black/20 transition-all"
              >
                <span>Open Project Workspace</span>
                <ArrowRight className="h-4 w-4" />
              </button>
              {focusProject.status === 'Revision Required' && (
                <div className="text-center text-[11px] font-medium text-amber-300 bg-amber-500/20 px-3 py-1.5 rounded-lg border border-amber-400/30">
                  Revision Feedback Attached
                </div>
              )}
            </div>
          </div>
        </div>
      ) : (
        <div className="p-8 rounded-2xl glass-card border border-slate-200/80 dark:border-slate-800 text-center space-y-2">
          <CheckCircle2 className="h-10 w-10 text-emerald-500 mx-auto" />
          <h3 className="text-sm font-bold text-slate-900 dark:text-white">All Caught Up!</h3>
          <p className="text-xs text-slate-500 dark:text-slate-400">
            You currently have no pending video deliverables in your queue.
          </p>
        </div>
      )}

      {/* Grid: My Projects & Urgent Feed */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Assigned Projects List */}
        <div className="lg:col-span-2 p-5 rounded-2xl glass-card border border-slate-200/80 dark:border-slate-800 space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-sm font-semibold text-slate-900 dark:text-white">
                My Video Deliverables ({myProjects.length})
              </h3>
              <p className="text-xs text-slate-400">
                Directly assigned to you under confidential protocols
              </p>
            </div>
            <button
              onClick={() => onNavigateTab('my-projects')}
              className="text-xs font-medium text-blue-600 hover:text-blue-700 dark:text-blue-400 flex items-center gap-1"
            >
              <span>Full List</span>
              <ChevronRight className="h-3 w-3" />
            </button>
          </div>

          <div className="space-y-2.5">
            {myProjects.map((proj) => (
              <div
                key={proj.id}
                onClick={() => onSelectProject(proj.id)}
                className="p-3.5 rounded-xl border border-slate-200/70 bg-white dark:border-slate-800 dark:bg-slate-800/40 hover:border-blue-400 dark:hover:border-blue-600 transition-all cursor-pointer"
              >
                <div className="flex items-center justify-between mb-1.5">
                  <div className="flex items-center gap-2">
                    <span className="font-mono text-xs font-bold text-blue-600 dark:text-blue-400">
                      {proj.code}
                    </span>
                    <span className="text-[10px] font-semibold text-slate-500 dark:text-slate-400">
                      {proj.channelName}
                    </span>
                  </div>
                  <div className="flex items-center gap-2">
                    {proj.status === 'In Progress' && onStartTimer && onStopTimer && (
                      <ProjectTimerWidget
                        project={proj}
                        currentUser={currentUser}
                        onStartTimer={onStartTimer}
                        onStopTimer={onStopTimer}
                        compact={true}
                      />
                    )}
                    <span
                      className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                        proj.status === 'Completed'
                          ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950/60 dark:text-emerald-300'
                          : proj.status === 'Waiting for Review'
                          ? 'bg-amber-100 text-amber-800 dark:bg-amber-950/60 dark:text-amber-300'
                          : proj.status === 'Revision Required'
                          ? 'bg-rose-100 text-rose-800 dark:bg-rose-950/60 dark:text-rose-300'
                          : 'bg-blue-100 text-blue-800 dark:bg-blue-950/60 dark:text-blue-300'
                      }`}
                    >
                      {proj.status}
                    </span>
                  </div>
                </div>

                <div className="text-xs font-semibold text-slate-900 dark:text-white line-clamp-1 mb-1">
                  {proj.title}
                </div>

                <div className="flex items-center justify-between text-[11px] text-slate-400">
                  <span>Current Stage: <strong className="text-slate-700 dark:text-slate-200">{proj.currentStage}</strong></span>
                  <div className="flex items-center gap-3">
                    <span className="font-mono text-slate-500 dark:text-slate-400">
                      ⏱ {formatSecondsToDuration(proj.timeSpentSeconds || 0)} logged
                    </span>
                    <span className="font-mono">Due: {proj.deadline}</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Right Rail: Performance Milestones & Recent Messages */}
        <div className="space-y-6">
          {/* Milestones Card */}
          <div className="p-5 rounded-2xl glass-card border border-slate-200/80 dark:border-slate-800 space-y-3">
            <h3 className="text-sm font-semibold text-slate-900 dark:text-white flex items-center gap-2">
              <Sparkles className="h-4 w-4 text-amber-500" />
              <span>Earned Studio Badges</span>
            </h3>
            <div className="grid grid-cols-2 gap-2 text-xs">
              <div className="p-2.5 rounded-xl bg-slate-50 dark:bg-slate-800/40 border border-slate-100 dark:border-slate-800">
                <div className="font-bold text-slate-900 dark:text-white">🚀 On-Time Master</div>
                <div className="text-[10px] text-slate-400">{currentUser.onTimeRate}% delivery rate</div>
              </div>
              <div className="p-2.5 rounded-xl bg-slate-50 dark:bg-slate-800/40 border border-slate-100 dark:border-slate-800">
                <div className="font-bold text-slate-900 dark:text-white">⭐ Quality Star</div>
                <div className="text-[10px] text-slate-400">Zero-revision streak</div>
              </div>
            </div>
          </div>

          {/* Quick Messages */}
          <div className="p-5 rounded-2xl glass-card border border-slate-200/80 dark:border-slate-800 space-y-3">
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-semibold text-slate-900 dark:text-white flex items-center gap-2">
                <MessageSquare className="h-4 w-4 text-blue-500" />
                <span>Internal Feedback</span>
              </h3>
              <button
                onClick={() => onNavigateTab('messages')}
                className="text-xs text-blue-600 dark:text-blue-400"
              >
                Open Chat
              </button>
            </div>

            <div className="space-y-2">
              {messages.slice(0, 3).map((m) => (
                <div
                  key={m.id}
                  className="p-2.5 rounded-xl bg-slate-50 dark:bg-slate-800/40 border border-slate-100 dark:border-slate-800 text-xs"
                >
                  <div className="flex items-center justify-between text-[11px] mb-1">
                    <span className="font-bold text-slate-900 dark:text-white">{m.senderName}</span>
                    <span className="text-slate-400">{m.createdAt}</span>
                  </div>
                  <p className="text-slate-600 dark:text-slate-300 text-[11px] line-clamp-2">
                    {m.content}
                  </p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
