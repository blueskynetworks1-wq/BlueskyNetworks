import React, { useState } from 'react';
import {
  Layers,
  CheckCircle2,
  Clock,
  AlertTriangle,
  Calendar,
  Users,
  Award,
  Video,
  ArrowUpRight,
  TrendingUp,
  Activity,
  Plus,
  Tv,
  Eye,
  Check,
  ChevronRight,
  ShieldAlert,
} from 'lucide-react';
import { Project, User, PublishedVideo, ContentPlanItem, AuditLog, AccountChangeRequest } from '../../types';

interface CeoDashboardProps {
  projects: Project[];
  users: User[];
  publishedVideos: PublishedVideo[];
  contentPlans: ContentPlanItem[];
  auditLogs: AuditLog[];
  accountRequests: AccountChangeRequest[];
  onNavigateTab: (tab: string) => void;
  onOpenCreateProject: () => void;
  onSelectProject: (projectId: string) => void;
}

export const CeoDashboard: React.FC<CeoDashboardProps> = ({
  projects,
  users,
  publishedVideos,
  contentPlans,
  auditLogs,
  accountRequests,
  onNavigateTab,
  onOpenCreateProject,
  onSelectProject,
}) => {
  const [selectedTimeRange, setSelectedTimeRange] = useState<'week' | 'month'>('week');

  // Metrics calculation
  const activeProjects = projects.filter((p) => p.status !== 'Completed' && p.status !== 'Cancelled');
  const completedProjects = projects.filter((p) => p.status === 'Completed');
  const inProgressProjects = projects.filter((p) => p.status === 'In Progress');
  const overdueProjects = projects.filter((p) => p.status === 'Overdue');
  const pendingReviewProjects = projects.filter((p) => p.status === 'Waiting for Review');

  const activeTeamMembers = users.filter((u) => u.status === 'active');
  const scheduledContent = contentPlans.filter((cp) => cp.publishingStatus === 'Scheduled');
  const pendingRequests = accountRequests.filter((r) => r.status === 'Pending');

  // Average performance score across team
  const memberScores = users.filter((u) => u.role === 'member').map((u) => u.onTimeRate);
  const avgPerformance = memberScores.length
    ? (memberScores.reduce((a, b) => a + b, 0) / memberScores.length).toFixed(1)
    : '95.0';

  // Platform publishing volume
  const ytPublished = publishedVideos.filter((v) => v.platform === 'YouTube').length;
  const fbPublished = publishedVideos.filter((v) => v.platform === 'Facebook').length;
  const totalViews = publishedVideos.reduce((acc, v) => acc + v.views, 0);

  return (
    <div className="space-y-6 animate-in fade-in duration-200">
      {/* Executive Command Banner */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 p-5 rounded-2xl glass-card border border-slate-200/80 dark:border-slate-800">
        <div className="flex items-center gap-4">
          <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-gradient-to-tr from-blue-600 via-indigo-600 to-sky-400 text-white shadow-lg shadow-blue-500/25">
            <Activity className="h-6 w-6" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-lg font-bold tracking-tight text-slate-900 dark:text-white">
                Executive Operations Console
              </h2>
              <span className="flex items-center gap-1 text-[11px] font-mono text-emerald-600 dark:text-emerald-400 bg-emerald-50 dark:bg-emerald-950/60 px-2 py-0.5 rounded-full border border-emerald-200 dark:border-emerald-900">
                <span className="h-1.5 w-1.5 rounded-full bg-emerald-500" />
                Live Studio Sync
              </span>
            </div>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              Welcome back, Manuja. Studio publishing pipelines are operating at 96.8% on-time velocity.
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => onNavigateTab('calendar')}
            className="rounded-xl border border-slate-200 px-3.5 py-2 text-xs font-medium text-slate-700 hover:bg-slate-100 dark:border-slate-800 dark:text-slate-300 dark:hover:bg-slate-800 transition-colors shadow-2xs"
          >
            Review Calendar
          </button>
          <button
            onClick={onOpenCreateProject}
            className="flex items-center gap-1.5 rounded-xl bg-blue-600 px-4 py-2 text-xs font-semibold text-white hover:bg-blue-700 shadow-md shadow-blue-600/25 transition-all"
          >
            <Plus className="h-3.5 w-3.5" />
            <span>Assign Project</span>
          </button>
        </div>
      </div>

      {/* Action Items Alert Strip (If reviews or account change requests are waiting) */}
      {(pendingReviewProjects.length > 0 || pendingRequests.length > 0) && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
          {pendingReviewProjects.length > 0 && (
            <div
              onClick={() => onNavigateTab('projects')}
              className="flex items-center justify-between p-3.5 rounded-xl bg-amber-500/10 border border-amber-500/30 text-amber-900 dark:text-amber-200 cursor-pointer hover:bg-amber-500/15 transition-all"
            >
              <div className="flex items-center gap-3">
                <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-amber-500 text-white shadow-xs">
                  <Video className="h-4 w-4" />
                </div>
                <div>
                  <div className="text-xs font-bold leading-tight">
                    {pendingReviewProjects.length} Video Submission{pendingReviewProjects.length > 1 ? 's' : ''} Awaiting Review
                  </div>
                  <div className="text-[11px] text-amber-700/80 dark:text-amber-300/80">
                    Latest: {pendingReviewProjects[0].title}
                  </div>
                </div>
              </div>
              <ChevronRight className="h-4 w-4 text-amber-600 dark:text-amber-400" />
            </div>
          )}

          {pendingRequests.length > 0 && (
            <div
              onClick={() => onNavigateTab('admin')}
              className="flex items-center justify-between p-3.5 rounded-xl bg-indigo-500/10 border border-indigo-500/30 text-indigo-900 dark:text-indigo-200 cursor-pointer hover:bg-indigo-500/15 transition-all"
            >
              <div className="flex items-center gap-3">
                <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-indigo-600 text-white shadow-xs">
                  <ShieldAlert className="h-4 w-4" />
                </div>
                <div>
                  <div className="text-xs font-bold leading-tight">
                    {pendingRequests.length} Sensitive Account Request Requires CEO Approval
                  </div>
                  <div className="text-[11px] text-indigo-700/80 dark:text-indigo-300/80">
                    {pendingRequests[0].userName}: {pendingRequests[0].requestType}
                  </div>
                </div>
              </div>
              <ChevronRight className="h-4 w-4 text-indigo-600 dark:text-indigo-400" />
            </div>
          )}
        </div>
      )}

      {/* 10 Executive Metric Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3.5">
        <div className="p-4 rounded-2xl glass-card border border-slate-200/80 dark:border-slate-800">
          <div className="flex items-center justify-between text-slate-500 dark:text-slate-400 mb-1">
            <span className="text-xs font-medium">Active Projects</span>
            <Layers className="h-4 w-4 text-blue-500" />
          </div>
          <div className="text-2xl font-bold tracking-tight text-slate-900 dark:text-white tabular-nums">
            {activeProjects.length}
          </div>
          <div className="text-[11px] text-slate-400 mt-1 flex items-center gap-1">
            <span>In production pipeline</span>
          </div>
        </div>

        <div className="p-4 rounded-2xl glass-card border border-slate-200/80 dark:border-slate-800">
          <div className="flex items-center justify-between text-slate-500 dark:text-slate-400 mb-1">
            <span className="text-xs font-medium">Completed Today</span>
            <CheckCircle2 className="h-4 w-4 text-emerald-500" />
          </div>
          <div className="text-2xl font-bold tracking-tight text-slate-900 dark:text-white tabular-nums">
            2
          </div>
          <div className="text-[11px] text-emerald-600 dark:text-emerald-400 mt-1">
            +1 ahead of target
          </div>
        </div>

        <div className="p-4 rounded-2xl glass-card border border-slate-200/80 dark:border-slate-800">
          <div className="flex items-center justify-between text-slate-500 dark:text-slate-400 mb-1">
            <span className="text-xs font-medium">In Progress</span>
            <Clock className="h-4 w-4 text-indigo-500" />
          </div>
          <div className="text-2xl font-bold tracking-tight text-slate-900 dark:text-white tabular-nums">
            {inProgressProjects.length}
          </div>
          <div className="text-[11px] text-slate-400 mt-1">
            Research & editing
          </div>
        </div>

        <div className="p-4 rounded-2xl glass-card border border-slate-200/80 dark:border-slate-800">
          <div className="flex items-center justify-between text-slate-500 dark:text-slate-400 mb-1">
            <span className="text-xs font-medium">Overdue Projects</span>
            <AlertTriangle className="h-4 w-4 text-rose-500" />
          </div>
          <div className="text-2xl font-bold tracking-tight text-slate-900 dark:text-white tabular-nums">
            {overdueProjects.length}
          </div>
          <div className="text-[11px] text-emerald-600 dark:text-emerald-400 mt-1">
            0 critical delays
          </div>
        </div>

        <div className="p-4 rounded-2xl glass-card border border-slate-200/80 dark:border-slate-800">
          <div className="flex items-center justify-between text-slate-500 dark:text-slate-400 mb-1">
            <span className="text-xs font-medium">Upcoming 48h Due</span>
            <Calendar className="h-4 w-4 text-amber-500" />
          </div>
          <div className="text-2xl font-bold tracking-tight text-slate-900 dark:text-white tabular-nums">
            2
          </div>
          <div className="text-[11px] text-amber-600 dark:text-amber-400 mt-1">
            BSN-1082 & BSN-1083
          </div>
        </div>

        <div className="p-4 rounded-2xl glass-card border border-slate-200/80 dark:border-slate-800">
          <div className="flex items-center justify-between text-slate-500 dark:text-slate-400 mb-1">
            <span className="text-xs font-medium">Total Staff</span>
            <Users className="h-4 w-4 text-blue-500" />
          </div>
          <div className="text-2xl font-bold tracking-tight text-slate-900 dark:text-white tabular-nums">
            {users.length}
          </div>
          <div className="text-[11px] text-slate-400 mt-1">
            CEO, 2 Mgrs, 3 Creators
          </div>
        </div>

        <div className="p-4 rounded-2xl glass-card border border-slate-200/80 dark:border-slate-800">
          <div className="flex items-center justify-between text-slate-500 dark:text-slate-400 mb-1">
            <span className="text-xs font-medium">Active Online</span>
            <Activity className="h-4 w-4 text-emerald-500" />
          </div>
          <div className="text-2xl font-bold tracking-tight text-slate-900 dark:text-white tabular-nums">
            {activeTeamMembers.length}
          </div>
          <div className="text-[11px] text-emerald-600 dark:text-emerald-400 mt-1">
            100% attendance
          </div>
        </div>

        <div className="p-4 rounded-2xl glass-card border border-slate-200/80 dark:border-slate-800">
          <div className="flex items-center justify-between text-slate-500 dark:text-slate-400 mb-1">
            <span className="text-xs font-medium">Scheduled Future</span>
            <Tv className="h-4 w-4 text-indigo-500" />
          </div>
          <div className="text-2xl font-bold tracking-tight text-slate-900 dark:text-white tabular-nums">
            {scheduledContent.length}
          </div>
          <div className="text-[11px] text-slate-400 mt-1">
            Through Nov 18
          </div>
        </div>

        <div className="p-4 rounded-2xl glass-card border border-slate-200/80 dark:border-slate-800">
          <div className="flex items-center justify-between text-slate-500 dark:text-slate-400 mb-1">
            <span className="text-xs font-medium">Published This Week</span>
            <Video className="h-4 w-4 text-purple-500" />
          </div>
          <div className="text-2xl font-bold tracking-tight text-slate-900 dark:text-white tabular-nums">
            {publishedVideos.length}
          </div>
          <div className="text-[11px] text-purple-600 dark:text-purple-400 mt-1">
            {(totalViews / 1000000).toFixed(1)}M combined views
          </div>
        </div>

        <div className="p-4 rounded-2xl glass-card border border-slate-200/80 dark:border-slate-800">
          <div className="flex items-center justify-between text-slate-500 dark:text-slate-400 mb-1">
            <span className="text-xs font-medium">Company Score</span>
            <Award className="h-4 w-4 text-amber-500" />
          </div>
          <div className="text-2xl font-bold tracking-tight text-slate-900 dark:text-white tabular-nums">
            {avgPerformance}%
          </div>
          <div className="text-[11px] text-emerald-600 dark:text-emerald-400 mt-1">
            Top tier studio index
          </div>
        </div>
      </div>

      {/* Visual Analytics Grid: Pipeline Velocity & Team Productivity */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Production Stage Breakdown */}
        <div className="lg:col-span-2 p-5 rounded-2xl glass-card border border-slate-200/80 dark:border-slate-800 space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-sm font-semibold text-slate-900 dark:text-white">
                Active Production Pipeline Velocity
              </h3>
              <p className="text-xs text-slate-400">
                Live distribution of media deliverables across production stages
              </p>
            </div>
            <button
              onClick={() => onNavigateTab('projects')}
              className="text-xs font-medium text-blue-600 hover:text-blue-700 dark:text-blue-400 flex items-center gap-1"
            >
              <span>View All Projects</span>
              <ArrowUpRight className="h-3 w-3" />
            </button>
          </div>

          {/* Interactive stage velocity bars */}
          <div className="space-y-3 pt-2">
            {[
              { stage: 'Research & Dossiers', count: 1, color: 'bg-sky-500', width: '25%' },
              { stage: 'Script Writing & Prompts', count: 1, color: 'bg-indigo-500', width: '25%' },
              { stage: 'Video Generation (AI/3D)', count: 1, color: 'bg-purple-500', width: '30%' },
              { stage: 'Editing & Post-Production', count: 2, color: 'bg-blue-600', width: '55%' },
              { stage: 'Submitted / Waiting Review', count: 1, color: 'bg-amber-500', width: '35%' },
              { stage: 'Completed & Delivered', count: completedProjects.length, color: 'bg-emerald-500', width: '80%' },
            ].map((item, idx) => (
              <div key={idx} className="space-y-1">
                <div className="flex items-center justify-between text-xs">
                  <span className="font-medium text-slate-700 dark:text-slate-300">
                    {item.stage}
                  </span>
                  <span className="font-mono text-slate-400 tabular-nums">
                    {item.count} video{item.count !== 1 ? 's' : ''}
                  </span>
                </div>
                <div className="h-2 w-full rounded-full bg-slate-100 dark:bg-slate-800 overflow-hidden">
                  <div
                    className={`h-full rounded-full ${item.color} transition-all duration-500`}
                    style={{ width: item.width }}
                  />
                </div>
              </div>
            ))}
          </div>

          {/* Distribution split info */}
          <div className="grid grid-cols-2 gap-3 pt-2 border-t border-slate-100 dark:border-slate-800 text-xs">
            <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/40">
              <div className="font-medium text-slate-500 dark:text-slate-400">YouTube Focus</div>
              <div className="text-base font-bold text-slate-900 dark:text-white tabular-nums">
                60% Long-form
              </div>
              <div className="text-[11px] text-slate-400">Avg duration 12:40</div>
            </div>
            <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/40">
              <div className="font-medium text-slate-500 dark:text-slate-400">Facebook Reels Focus</div>
              <div className="text-base font-bold text-slate-900 dark:text-white tabular-nums">
                40% Short-form
              </div>
              <div className="text-[11px] text-slate-400">Avg duration 03:15</div>
            </div>
          </div>
        </div>

        {/* Creator Leaderboard & Score Ranking */}
        <div className="p-5 rounded-2xl glass-card border border-slate-200/80 dark:border-slate-800 space-y-4 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-3">
              <div>
                <h3 className="text-sm font-semibold text-slate-900 dark:text-white">
                  Creator Productivity Ranking
                </h3>
                <p className="text-xs text-slate-400">Points & on-time delivery index</p>
              </div>
              <button
                onClick={() => onNavigateTab('performance')}
                className="text-xs font-medium text-blue-600 hover:text-blue-700 dark:text-blue-400"
              >
                Rules
              </button>
            </div>

            <div className="space-y-2.5">
              {users
                .filter((u) => u.role === 'member')
                .sort((a, b) => b.points - a.points)
                .map((creator, rank) => (
                  <div
                    key={creator.id}
                    className="flex items-center justify-between p-2.5 rounded-xl border border-slate-100 bg-slate-50/60 dark:border-slate-800 dark:bg-slate-800/40"
                  >
                    <div className="flex items-center gap-2.5">
                      <span className="flex h-5 w-5 items-center justify-center rounded-full bg-blue-100 text-blue-700 dark:bg-blue-900/50 dark:text-blue-300 font-mono text-[10px] font-bold">
                        #{rank + 1}
                      </span>
                      <div>
                        <div className="text-xs font-semibold text-slate-900 dark:text-white">
                          {creator.name}
                        </div>
                        <div className="text-[10px] text-slate-400">
                          {creator.completedProjectsCount} completed · {creator.onTimeRate}% on-time
                        </div>
                      </div>
                    </div>
                    <div className="text-right">
                      <div className="font-mono text-xs font-bold text-blue-600 dark:text-blue-400 tabular-nums">
                        {creator.points} pts
                      </div>
                      <div className="text-[10px] text-emerald-500 font-medium">+15 this week</div>
                    </div>
                  </div>
                ))}
            </div>
          </div>

          <div className="p-3 rounded-xl bg-blue-50/60 border border-blue-200/60 dark:bg-blue-950/30 dark:border-blue-900/40 text-xs text-blue-900 dark:text-blue-200">
            <div className="font-semibold mb-0.5">Scoring Benchmark</div>
            <div className="text-[11px] text-blue-700 dark:text-blue-300">
              Ahead of schedule gives +15 pts. Zero-revision work adds +5 quality bonus.
            </div>
          </div>
        </div>
      </div>

      {/* Two Column Layout: Urgent Project Queue & Real-Time Company Activity Feed */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Active Projects Quick Action Table */}
        <div className="p-5 rounded-2xl glass-card border border-slate-200/80 dark:border-slate-800 space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-sm font-semibold text-slate-900 dark:text-white">
                Active Project Queue
              </h3>
              <p className="text-xs text-slate-400">High priority video deliverables in flight</p>
            </div>
            <button
              onClick={() => onNavigateTab('projects')}
              className="text-xs font-medium text-blue-600 hover:text-blue-700 dark:text-blue-400"
            >
              Matrix View
            </button>
          </div>

          <div className="space-y-2">
            {activeProjects.slice(0, 4).map((proj) => (
              <div
                key={proj.id}
                onClick={() => onSelectProject(proj.id)}
                className="p-3 rounded-xl border border-slate-200/70 bg-white dark:border-slate-800 dark:bg-slate-800/40 hover:border-blue-300 dark:hover:border-blue-700 transition-all cursor-pointer"
              >
                <div className="flex items-center justify-between mb-1.5">
                  <div className="flex items-center gap-2">
                    <span className="font-mono text-xs font-bold text-blue-600 dark:text-blue-400">
                      {proj.code}
                    </span>
                    <span
                      className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                        proj.priority === 'Urgent'
                          ? 'bg-red-100 text-red-700 dark:bg-red-900/40 dark:text-red-300'
                          : proj.priority === 'High'
                          ? 'bg-amber-100 text-amber-700 dark:bg-amber-900/40 dark:text-amber-300'
                          : 'bg-slate-100 text-slate-600 dark:bg-slate-800 dark:text-slate-300'
                      }`}
                    >
                      {proj.priority}
                    </span>
                  </div>
                  <span
                    className={`text-[10px] font-semibold px-2 py-0.5 rounded-full ${
                      proj.status === 'Waiting for Review'
                        ? 'bg-amber-500 text-white shadow-xs'
                        : proj.status === 'Revision Required'
                        ? 'bg-rose-100 text-rose-700 dark:bg-rose-900/50 dark:text-rose-300'
                        : 'bg-slate-100 text-slate-700 dark:bg-slate-800 dark:text-slate-300'
                    }`}
                  >
                    {proj.status}
                  </span>
                </div>

                <div className="text-xs font-semibold text-slate-900 dark:text-white line-clamp-1 mb-1">
                  {proj.title}
                </div>

                <div className="flex items-center justify-between text-[11px] text-slate-400">
                  <span>{proj.channelName} · Stage: <strong className="text-slate-700 dark:text-slate-200">{proj.currentStage}</strong></span>
                  <span>Assigned: <strong className="text-slate-700 dark:text-slate-200">{proj.assignedToName}</strong></span>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Real-Time Company Activity Feed */}
        <div className="p-5 rounded-2xl glass-card border border-slate-200/80 dark:border-slate-800 space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <h3 className="text-sm font-semibold text-slate-900 dark:text-white">
                Live Studio Activity Feed
              </h3>
              <span className="flex h-2 w-2 rounded-full bg-emerald-500" />
            </div>
            <button
              onClick={() => onNavigateTab('admin')}
              className="text-xs font-medium text-blue-600 hover:text-blue-700 dark:text-blue-400"
            >
              Full Audit Logs
            </button>
          </div>

          <div className="space-y-3 max-h-96 overflow-y-auto pr-1">
            {auditLogs.slice(0, 6).map((log) => (
              <div
                key={log.id}
                className="flex items-start gap-3 p-2.5 rounded-xl bg-slate-50/70 dark:bg-slate-800/40 border border-slate-100 dark:border-slate-800 text-xs"
              >
                <div className="flex h-7 w-7 shrink-0 items-center justify-center rounded-lg bg-blue-100 text-blue-600 dark:bg-blue-900/50 dark:text-blue-300 font-bold text-[11px] mt-0.5">
                  {log.actorName.charAt(0)}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between mb-0.5">
                    <span className="font-semibold text-slate-900 dark:text-white">
                      {log.actorName}
                    </span>
                    <span className="text-[10px] text-slate-400 font-mono">
                      {log.timestamp}
                    </span>
                  </div>
                  <div className="text-slate-600 dark:text-slate-300 text-[11px] line-clamp-1">
                    <strong className="text-blue-600 dark:text-blue-400 font-mono mr-1">
                      {log.targetId}
                    </strong>
                    {log.details}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
