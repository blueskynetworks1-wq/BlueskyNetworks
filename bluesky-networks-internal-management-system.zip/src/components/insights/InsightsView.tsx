import React from 'react';
import {
  LineChart,
  TrendingUp,
  Award,
  Clock,
  Tv,
  Users,
  CheckCircle2,
  Calendar,
  AlertTriangle,
  ArrowUpRight,
} from 'lucide-react';
import { Project, User, MediaAsset, PublishedVideo } from '../../types';

interface InsightsViewProps {
  projects: Project[];
  users: User[];
  mediaAssets: MediaAsset[];
  publishedVideos: PublishedVideo[];
}

export const InsightsView: React.FC<InsightsViewProps> = ({
  projects,
  users,
  mediaAssets,
  publishedVideos,
}) => {
  const creators = users.filter((u) => u.role === 'member');
  const totalViews = publishedVideos.reduce((a, b) => a + b.views, 0);

  return (
    <div className="space-y-6 animate-in fade-in duration-200">
      {/* Header */}
      <div>
        <h2 className="text-lg font-bold text-slate-900 dark:text-white flex items-center gap-2">
          <LineChart className="h-5 w-5 text-blue-600" />
          <span>Executive Business Intelligence & Studio Analytics</span>
        </h2>
        <p className="text-xs text-slate-500 dark:text-slate-400">
          Executive decision metrics: Bottleneck analysis, channel performance, and workload equilibrium
        </p>
      </div>

      {/* High-Level Overview Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 text-xs">
        <div className="p-4 rounded-2xl glass-card border border-slate-200/80 dark:border-slate-800">
          <span className="text-slate-400 font-medium">Aggregate Delivery Rate</span>
          <div className="text-2xl font-bold text-emerald-600 dark:text-emerald-400 mt-1 tabular-nums">
            96.8%
          </div>
          <div className="text-[11px] text-slate-400 mt-1">100% on-time during Q4 sprint</div>
        </div>

        <div className="p-4 rounded-2xl glass-card border border-slate-200/80 dark:border-slate-800">
          <span className="text-slate-400 font-medium">Avg Production Cycle</span>
          <div className="text-2xl font-bold text-blue-600 dark:text-blue-400 mt-1 tabular-nums">
            4.2 Days
          </div>
          <div className="text-[11px] text-slate-400 mt-1">From prompt authoring to final delivery</div>
        </div>

        <div className="p-4 rounded-2xl glass-card border border-slate-200/80 dark:border-slate-800">
          <span className="text-slate-400 font-medium">First-Pass Approval Rate</span>
          <div className="text-2xl font-bold text-purple-600 dark:text-purple-400 mt-1 tabular-nums">
            83.3%
          </div>
          <div className="text-[11px] text-slate-400 mt-1">Approved without revision requests</div>
        </div>

        <div className="p-4 rounded-2xl glass-card border border-slate-200/80 dark:border-slate-800">
          <span className="text-slate-400 font-medium">Total Audience Reach</span>
          <div className="text-2xl font-bold text-amber-500 mt-1 tabular-nums">
            {(totalViews / 1000000).toFixed(1)}M Views
          </div>
          <div className="text-[11px] text-emerald-600 dark:text-emerald-400 mt-1">+24% vs preceding period</div>
        </div>
      </div>

      {/* Grid: Channel Activity Breakdown & Workload Distribution */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Channel Activity & Velocity */}
        <div className="p-5 rounded-2xl glass-card border border-slate-200/80 dark:border-slate-800 space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-semibold text-slate-900 dark:text-white">
              Channel Output Velocity & Audience Scale
            </h3>
            <span className="text-xs text-slate-400">4 Active Outlets</span>
          </div>

          <div className="space-y-3">
            {mediaAssets.map((asset) => {
              const videoCount = publishedVideos.filter((v) => v.channelId === asset.id).length;
              return (
                <div
                  key={asset.id}
                  className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/40 border border-slate-100 dark:border-slate-800 text-xs space-y-1.5"
                >
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-slate-900 dark:text-white">
                      {asset.name}
                    </span>
                    <span className="font-mono text-blue-600 dark:text-blue-400 font-bold">
                      {asset.monthlyReach}
                    </span>
                  </div>
                  <div className="flex items-center justify-between text-[11px] text-slate-400">
                    <span>{asset.platform} · {asset.category}</span>
                    <span>{videoCount} catalog videos</span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Creator Workload Distribution */}
        <div className="p-5 rounded-2xl glass-card border border-slate-200/80 dark:border-slate-800 space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-semibold text-slate-900 dark:text-white">
              Creator Pipeline Allocation & Workload Equilibrium
            </h3>
            <span className="text-xs text-emerald-500 font-semibold">Equilibrium: Balanced</span>
          </div>

          <div className="space-y-3">
            {creators.map((c) => {
              const assignedCount = projects.filter((p) => p.assignedToId === c.id && p.status !== 'Completed').length;
              const loadPercentage = Math.min(100, assignedCount * 33);
              return (
                <div key={c.id} className="space-y-1 text-xs">
                  <div className="flex items-center justify-between">
                    <span className="font-semibold text-slate-900 dark:text-white">
                      {c.name} ({c.jobTitle.split('&')[0]})
                    </span>
                    <span className="font-mono text-slate-400 tabular-nums">
                      {assignedCount} active projects ({loadPercentage}%)
                    </span>
                  </div>
                  <div className="h-2 w-full rounded-full bg-slate-100 dark:bg-slate-800 overflow-hidden">
                    <div
                      className={`h-full rounded-full ${
                        loadPercentage > 75 ? 'bg-amber-500' : 'bg-blue-600'
                      }`}
                      style={{ width: `${loadPercentage}%` }}
                    />
                  </div>
                </div>
              );
            })}
          </div>

          <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/40 text-[11px] text-slate-500 dark:text-slate-400 space-y-1">
            <div className="font-semibold text-slate-700 dark:text-slate-300">
              Workload Recommendation
            </div>
            <p>
              Dilshan Fernando has available capacity for next week's Horizon Pulse season packaging kickoff.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};
