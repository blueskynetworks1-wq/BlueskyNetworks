import React, { useState } from 'react';
import {
  Users,
  Search,
  Filter,
  Award,
  Clock,
  CheckCircle2,
  AlertTriangle,
  KeyRound,
  Shield,
  Sliders,
  ChevronRight,
  TrendingUp,
  X,
  Plus,
  Lock,
} from 'lucide-react';
import { User, Project, UserRole, PointAuditEntry } from '../../types';

interface TeamRosterProps {
  users: User[];
  projects: Project[];
  pointAudits: PointAuditEntry[];
  currentUser: User;
  onAdjustPoints: (userId: string, delta: number, reason: string) => void;
  onResetPassword: (userId: string) => { tempResetToken: string };
  onUpdateStatus: (userId: string, status: User['status']) => void;
  onSelectProject: (projectId: string) => void;
}

export const TeamRoster: React.FC<TeamRosterProps> = ({
  users,
  projects,
  pointAudits,
  currentUser,
  onAdjustPoints,
  onResetPassword,
  onUpdateStatus,
  onSelectProject,
}) => {
  const [selectedUserId, setSelectedUserId] = useState<string>(users[0]?.id || '');
  const [search, setSearch] = useState('');
  const [roleFilter, setRoleFilter] = useState<string>('all');

  // Point Adjustment Modal state
  const [showPointModal, setShowPointModal] = useState(false);
  const [pointDelta, setPointDelta] = useState<number>(10);
  const [pointReason, setPointReason] = useState('');

  // Password Reset Feedback state
  const [resetTokenFeedback, setResetTokenFeedback] = useState<{ userName: string; token: string } | null>(null);

  // Selected Employee
  const selectedUser = users.find((u) => u.id === selectedUserId) || users[0];

  // Employee Projects
  const employeeProjects = projects.filter((p) => p.assignedToId === selectedUser?.id);
  const employeePointAudits = pointAudits.filter((pa) => pa.userId === selectedUser?.id);

  const isCeo = currentUser.role === 'ceo';

  const filteredUsers = users.filter((u) => {
    const matchesSearch =
      u.name.toLowerCase().includes(search.toLowerCase()) ||
      u.jobTitle.toLowerCase().includes(search.toLowerCase()) ||
      u.email.toLowerCase().includes(search.toLowerCase());
    const matchesRole = roleFilter === 'all' || u.role === roleFilter;
    return matchesSearch && matchesRole;
  });

  const handlePointSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!pointReason.trim()) return;
    onAdjustPoints(selectedUser.id, pointDelta, pointReason);
    setPointReason('');
    setShowPointModal(false);
  };

  const handlePasswordReset = (user: User) => {
    if (confirm(`Generate secure single-use password reset token for ${user.name}? This forces password update on their next login.`)) {
      const res = onResetPassword(user.id);
      setResetTokenFeedback({ userName: user.name, token: res.tempResetToken });
    }
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-200">
      {/* Reset Token Modal / Banner */}
      {resetTokenFeedback && (
        <div className="p-4 rounded-2xl bg-amber-500/10 border border-amber-500/30 text-amber-900 dark:text-amber-200 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <KeyRound className="h-5 w-5 text-amber-600 dark:text-amber-400 shrink-0" />
            <div className="text-xs">
              <div className="font-bold">
                Temporary Reset Token Generated for {resetTokenFeedback.userName}
              </div>
              <div className="text-[11px] text-amber-800/80 dark:text-amber-300/80">
                Single-use credential: <strong className="font-mono bg-white/60 dark:bg-black/40 px-2 py-0.5 rounded">{resetTokenFeedback.token}</strong>. Passwords are never stored in plain text.
              </div>
            </div>
          </div>
          <button
            onClick={() => setResetTokenFeedback(null)}
            className="text-xs font-semibold px-3 py-1 rounded-lg bg-amber-600 text-white hover:bg-amber-700"
          >
            Dismiss
          </button>
        </div>
      )}

      {/* Header and Controls */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-lg font-bold text-slate-900 dark:text-white">
            Team Member Dossiers & Performance
          </h2>
          <p className="text-xs text-slate-500 dark:text-slate-400">
            Individual delivery metrics, on-time history, and secure account management
          </p>
        </div>

        {/* Filter controls */}
        <div className="flex items-center gap-2">
          <div className="relative">
            <Search className="absolute left-3 top-2 h-3.5 w-3.5 text-slate-400" />
            <input
              type="text"
              placeholder="Search staff..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="rounded-xl border border-slate-200/80 bg-white pl-8 pr-3 py-1.5 text-xs text-slate-900 focus:outline-hidden dark:border-slate-700 dark:bg-slate-800 dark:text-white"
            />
          </div>

          <select
            value={roleFilter}
            onChange={(e) => setRoleFilter(e.target.value)}
            className="rounded-xl border border-slate-200/80 bg-white px-3 py-1.5 text-xs text-slate-700 focus:outline-hidden dark:border-slate-700 dark:bg-slate-800 dark:text-slate-300"
          >
            <option value="all">All Roles</option>
            <option value="ceo">CEO</option>
            <option value="manager">Managers</option>
            <option value="member">Creators</option>
          </select>
        </div>
      </div>

      {/* Master-Detail Split Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Col: Employee Selector List (4 cols) */}
        <div className="lg:col-span-4 space-y-2">
          {filteredUsers.map((user) => {
            const isSelected = user.id === selectedUser?.id;
            return (
              <div
                key={user.id}
                onClick={() => setSelectedUserId(user.id)}
                className={`p-3.5 rounded-2xl border transition-all cursor-pointer ${
                  isSelected
                    ? 'border-blue-500 bg-blue-50/80 dark:border-blue-500 dark:bg-blue-950/40 shadow-xs ring-1 ring-blue-500/30'
                    : 'glass-card border-slate-200/80 hover:border-slate-300 dark:border-slate-800'
                }`}
              >
                <div className="flex items-center gap-3">
                  <div className="relative">
                    {user.avatarUrl ? (
                      <img
                        src={user.avatarUrl}
                        alt={user.name}
                        className="h-10 w-10 rounded-full object-cover ring-1 ring-slate-200 dark:ring-slate-700"
                      />
                    ) : (
                      <div className="flex h-10 w-10 items-center justify-center rounded-full bg-slate-100 text-slate-700 dark:bg-slate-800 dark:text-slate-300 font-bold text-sm">
                        {user.name.charAt(0)}
                      </div>
                    )}
                    <span
                      className={`absolute -bottom-0.5 -right-0.5 h-2.5 w-2.5 rounded-full ring-2 ring-white dark:ring-slate-900 ${
                        user.status === 'active' ? 'bg-emerald-500' : 'bg-rose-500'
                      }`}
                    />
                  </div>

                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between mb-0.5">
                      <span className="text-xs font-bold text-slate-900 dark:text-white truncate">
                        {user.name}
                      </span>
                      <span className="font-mono text-[11px] font-bold text-blue-600 dark:text-blue-400 tabular-nums">
                        {user.points} pts
                      </span>
                    </div>
                    <div className="text-[11px] text-slate-500 dark:text-slate-400 truncate">
                      {user.jobTitle}
                    </div>
                  </div>
                </div>
              </div>
            );
          })}
        </div>

        {/* Right Col: Selected User Dossier & History (8 cols) */}
        {selectedUser && (
          <div className="lg:col-span-8 space-y-6">
            {/* Dossier Hero Card */}
            <div className="p-6 rounded-2xl glass-card border border-slate-200/80 dark:border-slate-800 space-y-5">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                <div className="flex items-center gap-4">
                  {selectedUser.avatarUrl ? (
                    <img
                      src={selectedUser.avatarUrl}
                      alt={selectedUser.name}
                      className="h-16 w-16 rounded-2xl object-cover ring-2 ring-blue-500/20 shadow-md"
                    />
                  ) : (
                    <div className="flex h-16 w-16 items-center justify-center rounded-2xl bg-gradient-to-tr from-blue-600 to-indigo-600 text-white font-bold text-xl shadow-md">
                      {selectedUser.name.charAt(0)}
                    </div>
                  )}
                  <div>
                    <div className="flex items-center gap-2">
                      <h3 className="text-base font-bold text-slate-900 dark:text-white">
                        {selectedUser.name}
                      </h3>
                      <span
                        className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                          selectedUser.role === 'ceo'
                            ? 'bg-amber-100 text-amber-800 dark:bg-amber-950/60 dark:text-amber-300'
                            : selectedUser.role === 'manager'
                            ? 'bg-indigo-100 text-indigo-800 dark:bg-indigo-950/60 dark:text-indigo-300'
                            : 'bg-slate-100 text-slate-700 dark:bg-slate-800 dark:text-slate-300'
                        }`}
                      >
                        {selectedUser.role.toUpperCase()}
                      </span>
                      <span
                        className={`text-[10px] font-medium px-2 py-0.5 rounded-full ${
                          selectedUser.status === 'active'
                            ? 'bg-emerald-50 text-emerald-700 dark:bg-emerald-950/40 dark:text-emerald-300'
                            : 'bg-rose-50 text-rose-700 dark:bg-rose-950/40 dark:text-rose-300'
                        }`}
                      >
                        {selectedUser.status}
                      </span>
                    </div>
                    <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
                      {selectedUser.jobTitle} · {selectedUser.department}
                    </p>
                    <p className="text-[11px] text-slate-400 font-mono mt-0.5">
                      {selectedUser.email} · Joined {selectedUser.joinDate}
                    </p>
                  </div>
                </div>

                {/* CEO Governance Controls */}
                {isCeo && (
                  <div className="flex flex-wrap items-center gap-2">
                    <button
                      onClick={() => setShowPointModal(true)}
                      className="flex items-center gap-1.5 rounded-xl bg-blue-600 px-3.5 py-2 text-xs font-semibold text-white hover:bg-blue-700 shadow-xs transition-all"
                    >
                      <Award className="h-3.5 w-3.5" />
                      <span>Adjust Points</span>
                    </button>
                    <button
                      onClick={() => handlePasswordReset(selectedUser)}
                      className="flex items-center gap-1.5 rounded-xl border border-slate-200 bg-white px-3 py-2 text-xs font-medium text-slate-700 hover:bg-slate-100 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-300 transition-colors"
                      title="Reset Password Securely"
                    >
                      <KeyRound className="h-3.5 w-3.5" />
                      <span>Reset Token</span>
                    </button>
                    <button
                      onClick={() =>
                        onUpdateStatus(
                          selectedUser.id,
                          selectedUser.status === 'active' ? 'suspended' : 'active'
                        )
                      }
                      className={`rounded-xl px-3 py-2 text-xs font-medium transition-colors ${
                        selectedUser.status === 'active'
                          ? 'text-rose-600 hover:bg-rose-50 dark:hover:bg-rose-950/40'
                          : 'text-emerald-600 hover:bg-emerald-50 dark:hover:bg-emerald-950/40'
                      }`}
                    >
                      {selectedUser.status === 'active' ? 'Suspend' : 'Activate'}
                    </button>
                  </div>
                )}
              </div>

              {/* KPI Strip */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
                <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/40 border border-slate-100 dark:border-slate-800">
                  <div className="text-slate-400 font-medium">Performance Score</div>
                  <div className="text-lg font-bold text-slate-900 dark:text-white tabular-nums">
                    {selectedUser.points} pts
                  </div>
                </div>

                <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/40 border border-slate-100 dark:border-slate-800">
                  <div className="text-slate-400 font-medium">On-Time Delivery</div>
                  <div className="text-lg font-bold text-emerald-600 dark:text-emerald-400 tabular-nums">
                    {selectedUser.onTimeRate}%
                  </div>
                </div>

                <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/40 border border-slate-100 dark:border-slate-800">
                  <div className="text-slate-400 font-medium">Completed Videos</div>
                  <div className="text-lg font-bold text-slate-900 dark:text-white tabular-nums">
                    {selectedUser.completedProjectsCount}
                  </div>
                </div>

                <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/40 border border-slate-100 dark:border-slate-800">
                  <div className="text-slate-400 font-medium">Active Deliverables</div>
                  <div className="text-lg font-bold text-blue-600 dark:text-blue-400 tabular-nums">
                    {employeeProjects.filter((p) => p.status !== 'Completed').length}
                  </div>
                </div>
              </div>
            </div>

            {/* Project History */}
            <div className="p-5 rounded-2xl glass-card border border-slate-200/80 dark:border-slate-800 space-y-3">
              <div className="flex items-center justify-between">
                <h4 className="text-xs font-semibold uppercase tracking-wider text-slate-400">
                  Project History & Deliverables ({employeeProjects.length})
                </h4>
              </div>

              {employeeProjects.length === 0 ? (
                <div className="py-6 text-center text-xs text-slate-400">
                  No projects recorded for this team member.
                </div>
              ) : (
                <div className="space-y-2">
                  {employeeProjects.map((p) => (
                    <div
                      key={p.id}
                      onClick={() => onSelectProject(p.id)}
                      className="flex items-center justify-between p-3 rounded-xl border border-slate-100 bg-white dark:border-slate-800 dark:bg-slate-800/40 hover:border-blue-400 transition-all cursor-pointer text-xs"
                    >
                      <div>
                        <div className="flex items-center gap-2 mb-0.5">
                          <span className="font-mono text-blue-600 dark:text-blue-400 font-bold">
                            {p.code}
                          </span>
                          <span className="font-semibold text-slate-900 dark:text-white line-clamp-1">
                            {p.title}
                          </span>
                        </div>
                        <div className="text-[11px] text-slate-400">
                          {p.channelName} · Stage: {p.currentStage} · Due {p.deadline}
                        </div>
                      </div>

                      <div className="flex items-center gap-2">
                        <span
                          className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                            p.status === 'Completed'
                              ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950/60 dark:text-emerald-300'
                              : 'bg-blue-100 text-blue-800 dark:bg-blue-950/60 dark:text-blue-300'
                          }`}
                        >
                          {p.status}
                        </span>
                        <ChevronRight className="h-3.5 w-3.5 text-slate-400" />
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* Performance Point Audit History */}
            <div className="p-5 rounded-2xl glass-card border border-slate-200/80 dark:border-slate-800 space-y-3">
              <h4 className="text-xs font-semibold uppercase tracking-wider text-slate-400">
                Point Transactions & Audit History ({employeePointAudits.length})
              </h4>
              <div className="space-y-2">
                {employeePointAudits.map((pa) => (
                  <div
                    key={pa.id}
                    className="flex items-center justify-between p-2.5 rounded-xl bg-slate-50 dark:bg-slate-800/30 border border-slate-100 dark:border-slate-800 text-xs"
                  >
                    <div>
                      <div className="font-medium text-slate-900 dark:text-white">
                        {pa.reason}
                      </div>
                      <div className="text-[10px] text-slate-400">
                        Adjusted by {pa.adjustedBy} · {pa.timestamp}
                      </div>
                    </div>
                    <span
                      className={`font-mono text-xs font-bold tabular-nums ${
                        pa.points >= 0
                          ? 'text-emerald-600 dark:text-emerald-400'
                          : 'text-rose-600 dark:text-rose-400'
                      }`}
                    >
                      {pa.points > 0 ? `+${pa.points}` : pa.points} pts
                    </span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Point Adjustment Modal */}
      {showPointModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm animate-in fade-in duration-100">
          <div className="w-full max-w-md rounded-2xl border border-slate-200/90 bg-white p-6 shadow-2xl dark:border-slate-800 dark:bg-slate-900">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800">
              <h3 className="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-2">
                <Award className="h-4 w-4 text-blue-600" />
                <span>Adjust Points for {selectedUser.name}</span>
              </h3>
              <button
                onClick={() => setShowPointModal(false)}
                className="text-slate-400 hover:text-slate-600 dark:hover:text-slate-200"
              >
                <X className="h-4 w-4" />
              </button>
            </div>

            <form onSubmit={handlePointSubmit} className="mt-4 space-y-4 text-xs">
              <div>
                <label className="block text-[11px] font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  Points Delta (+ or -)
                </label>
                <input
                  type="number"
                  value={pointDelta}
                  onChange={(e) => setPointDelta(parseInt(e.target.value, 10) || 0)}
                  className="w-full rounded-xl border border-slate-200 bg-white px-3 py-2 text-xs text-slate-900 font-mono font-bold dark:border-slate-700 dark:bg-slate-800 dark:text-white"
                />
              </div>

              <div>
                <label className="block text-[11px] font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  Official Justification / Reason *
                </label>
                <textarea
                  rows={3}
                  placeholder="e.g. CEO special commendation for outstanding turnaround on quantum computing reel..."
                  value={pointReason}
                  onChange={(e) => setPointReason(e.target.value)}
                  required
                  className="w-full rounded-xl border border-slate-200 bg-white px-3 py-2 text-xs text-slate-900 focus:outline-hidden dark:border-slate-700 dark:bg-slate-800 dark:text-white"
                />
              </div>

              <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-100 dark:border-slate-800">
                <button
                  type="button"
                  onClick={() => setShowPointModal(false)}
                  className="rounded-xl border border-slate-200 px-3.5 py-2 text-slate-600 hover:bg-slate-100 dark:border-slate-700 dark:text-slate-300"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="rounded-xl bg-blue-600 px-4 py-2 font-semibold text-white hover:bg-blue-700 transition-colors shadow-xs"
                >
                  Commit Point Adjustment
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
