import React, { useState } from 'react';
import { X, Plus, Sparkles, Layers, Calendar, Users, Tv } from 'lucide-react';
import { User, MediaAsset, PriorityLevel, ProductionStage } from '../../types';

interface CreateProjectModalProps {
  isOpen: boolean;
  onClose: () => void;
  users: User[];
  mediaAssets: MediaAsset[];
  currentUser: User;
  onCreateProject: (projectData: any) => void;
}

export const CreateProjectModal: React.FC<CreateProjectModalProps> = ({
  isOpen,
  onClose,
  users,
  mediaAssets,
  currentUser,
  onCreateProject,
}) => {
  if (!isOpen) return null;

  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [videoPrompt, setVideoPrompt] = useState('');
  const [platform, setPlatform] = useState<'YouTube' | 'Facebook'>('YouTube');
  const [channelId, setChannelId] = useState(mediaAssets[0]?.id || 'chan-1');
  const [assignedToId, setAssignedToId] = useState(users.find((u) => u.role === 'member')?.id || 'u-kaveen');
  const [deadlineDate, setDeadlineDate] = useState('2026-11-14');
  const [deadlineTime, setDeadlineTime] = useState('18:00');
  const [priority, setPriority] = useState<PriorityLevel>('High');
  const [category, setCategory] = useState('Tech Explainer');
  const [currentStage, setCurrentStage] = useState<ProductionStage>('Research');
  const [notes, setNotes] = useState('');
  const [referenceLink, setReferenceLink] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim() || !videoPrompt.trim()) return;

    const channel = mediaAssets.find((m) => m.id === channelId);
    const assignee = users.find((u) => u.id === assignedToId);

    onCreateProject({
      title,
      description,
      videoPrompt,
      platform,
      channelId,
      channelName: channel?.name || 'Bluesky Channel',
      startDate: new Date().toISOString().substring(0, 10),
      deadline: `${deadlineDate}T${deadlineTime}`,
      priority,
      category,
      assignedToId,
      assignedToName: assignee?.name || 'Assigned Creator',
      currentStage,
      notes,
      referenceLinks: referenceLink ? [referenceLink] : [],
    });

    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/60 backdrop-blur-md animate-in fade-in duration-150 overflow-y-auto">
      <div className="w-full max-w-2xl rounded-2xl border border-slate-200/90 bg-white/95 shadow-2xl backdrop-blur-2xl dark:border-slate-800 dark:bg-slate-900/95 overflow-hidden my-auto max-h-[92vh] flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-200/80 dark:border-slate-800/80 shrink-0">
          <div>
            <h2 className="text-base font-bold text-slate-900 dark:text-white flex items-center gap-2">
              <Plus className="h-4 w-4 text-blue-600" />
              <span>Commission New Video Deliverable</span>
            </h2>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              Assign prompt, channel, and confidential production workflow
            </p>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-slate-700 hover:bg-slate-100 dark:hover:bg-slate-800 dark:hover:text-slate-200"
          >
            <X className="h-4 w-4" />
          </button>
        </div>

        {/* Scrollable Form */}
        <form onSubmit={handleSubmit} className="flex-1 overflow-y-auto p-6 space-y-4 text-xs">
          {/* Project Title */}
          <div>
            <label className="block text-[11px] font-semibold text-slate-700 dark:text-slate-300 mb-1">
              Project Title *
            </label>
            <input
              type="text"
              placeholder="e.g. The Real Reason Electric Airplanes Are Finally Flying in 2026"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              required
              className="w-full rounded-xl border border-slate-200 bg-white px-3 py-2 text-xs text-slate-900 focus:border-blue-500 focus:outline-hidden dark:border-slate-700 dark:bg-slate-800 dark:text-white"
            />
          </div>

          {/* Generative Video Prompt */}
          <div>
            <label className="block text-[11px] font-semibold text-slate-700 dark:text-slate-300 mb-1">
              Official Generative Prompt & Visual Directives *
            </label>
            <textarea
              rows={3}
              placeholder="Detailed B-roll, camera movement, lighting, lens specs, color temperature, and thematic cues..."
              value={videoPrompt}
              onChange={(e) => setVideoPrompt(e.target.value)}
              required
              className="w-full rounded-xl border border-blue-200 bg-blue-50/30 p-3 font-mono text-xs text-slate-900 focus:border-blue-500 focus:outline-hidden dark:border-blue-900/50 dark:bg-blue-950/20 dark:text-blue-100"
            />
          </div>

          {/* Brief / Description */}
          <div>
            <label className="block text-[11px] font-semibold text-slate-700 dark:text-slate-300 mb-1">
              Script Brief & Key Narrative Goals
            </label>
            <textarea
              rows={2}
              placeholder="Narrative hook, target duration, core premise, and target audience..."
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              className="w-full rounded-xl border border-slate-200 bg-white px-3 py-2 text-xs text-slate-900 focus:border-blue-500 focus:outline-hidden dark:border-slate-700 dark:bg-slate-800 dark:text-white"
            />
          </div>

          {/* Platform & Channel */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-[11px] font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Platform
              </label>
              <select
                value={platform}
                onChange={(e) => setPlatform(e.target.value as any)}
                className="w-full rounded-xl border border-slate-200 bg-white px-3 py-2 text-xs text-slate-900 focus:border-blue-500 focus:outline-hidden dark:border-slate-700 dark:bg-slate-800 dark:text-white"
              >
                <option value="YouTube">YouTube</option>
                <option value="Facebook">Facebook</option>
              </select>
            </div>

            <div>
              <label className="block text-[11px] font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Target Media Channel
              </label>
              <select
                value={channelId}
                onChange={(e) => setChannelId(e.target.value)}
                className="w-full rounded-xl border border-slate-200 bg-white px-3 py-2 text-xs text-slate-900 focus:border-blue-500 focus:outline-hidden dark:border-slate-700 dark:bg-slate-800 dark:text-white"
              >
                {mediaAssets.map((m) => (
                  <option key={m.id} value={m.id}>
                    {m.name} ({m.platform})
                  </option>
                ))}
              </select>
            </div>
          </div>

          {/* Assignee & Priority */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-[11px] font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Assign To Team Member (Confidential Assignment)
              </label>
              <select
                value={assignedToId}
                onChange={(e) => setAssignedToId(e.target.value)}
                className="w-full rounded-xl border border-slate-200 bg-white px-3 py-2 text-xs text-slate-900 focus:border-blue-500 focus:outline-hidden dark:border-slate-700 dark:bg-slate-800 dark:text-white"
              >
                {users.map((u) => (
                  <option key={u.id} value={u.id}>
                    {u.name} — {u.jobTitle} ({u.role.toUpperCase()})
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-[11px] font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Priority Level
              </label>
              <select
                value={priority}
                onChange={(e) => setPriority(e.target.value as PriorityLevel)}
                className="w-full rounded-xl border border-slate-200 bg-white px-3 py-2 text-xs text-slate-900 focus:border-blue-500 focus:outline-hidden dark:border-slate-700 dark:bg-slate-800 dark:text-white"
              >
                <option value="Urgent">Urgent (48-hour turn)</option>
                <option value="High">High Priority</option>
                <option value="Medium">Medium Priority</option>
                <option value="Low">Low / Flexible</option>
              </select>
            </div>
          </div>

          {/* Deadline Date & Time */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div className="sm:col-span-2">
              <label className="block text-[11px] font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Submission Deadline Date
              </label>
              <input
                type="date"
                value={deadlineDate}
                onChange={(e) => setDeadlineDate(e.target.value)}
                required
                className="w-full rounded-xl border border-slate-200 bg-white px-3 py-2 text-xs text-slate-900 focus:border-blue-500 focus:outline-hidden dark:border-slate-700 dark:bg-slate-800 dark:text-white"
              />
            </div>

            <div>
              <label className="block text-[11px] font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Deadline Time
              </label>
              <input
                type="time"
                value={deadlineTime}
                onChange={(e) => setDeadlineTime(e.target.value)}
                required
                className="w-full rounded-xl border border-slate-200 bg-white px-3 py-2 text-xs text-slate-900 focus:border-blue-500 focus:outline-hidden dark:border-slate-700 dark:bg-slate-800 dark:text-white"
              />
            </div>
          </div>

          {/* Reference Link & Notes */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-[11px] font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Reference / Asset Link (Optional)
              </label>
              <input
                type="url"
                placeholder="https://drive.google.com/..."
                value={referenceLink}
                onChange={(e) => setReferenceLink(e.target.value)}
                className="w-full rounded-xl border border-slate-200 bg-white px-3 py-2 text-xs text-slate-900 focus:border-blue-500 focus:outline-hidden dark:border-slate-700 dark:bg-slate-800 dark:text-white"
              />
            </div>

            <div>
              <label className="block text-[11px] font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Category
              </label>
              <select
                value={category}
                onChange={(e) => setCategory(e.target.value)}
                className="w-full rounded-xl border border-slate-200 bg-white px-3 py-2 text-xs text-slate-900 focus:border-blue-500 focus:outline-hidden dark:border-slate-700 dark:bg-slate-800 dark:text-white"
              >
                <option value="Tech Explainer">Tech Explainer</option>
                <option value="Digital Culture & Stories">Digital Culture & Stories</option>
                <option value="Deep Dives & Futurism">Deep Dives & Futurism</option>
                <option value="Current Affairs & Explanations">Current Affairs & Explanations</option>
                <option value="Branding & Visuals">Branding & Visuals</option>
              </select>
            </div>
          </div>

          {/* Submit Action */}
          <div className="pt-4 border-t border-slate-200/80 dark:border-slate-800/80 flex items-center justify-end gap-2">
            <button
              type="button"
              onClick={onClose}
              className="rounded-xl border border-slate-200 px-4 py-2 font-medium text-slate-700 hover:bg-slate-100 dark:border-slate-700 dark:text-slate-300 dark:hover:bg-slate-800 transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="flex items-center gap-1.5 rounded-xl bg-blue-600 px-5 py-2 font-semibold text-white hover:bg-blue-700 shadow-md shadow-blue-600/25 transition-all"
            >
              <Plus className="h-4 w-4" />
              <span>Create Project</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
