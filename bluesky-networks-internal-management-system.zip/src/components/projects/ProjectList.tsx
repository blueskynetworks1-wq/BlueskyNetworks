import React, { useState } from 'react';
import {
  Plus,
  Search,
  Filter,
  Layers,
  Clock,
  CheckCircle2,
  AlertTriangle,
  ChevronRight,
  ExternalLink,
  Shield,
  Video,
  Eye,
} from 'lucide-react';
import { Project, User, ProjectStatus, PriorityLevel } from '../../types';

import { ProjectTimerWidget, formatSecondsToDuration } from '../common/ProjectTimerWidget';

interface ProjectListProps {
  projects: Project[];
  currentUser: User;
  onSelectProject: (projectId: string) => void;
  onOpenCreateProject: () => void;
  onStartTimer?: (projectId: string) => void;
  onStopTimer?: (projectId: string, notes?: string) => void;
}

export const ProjectList: React.FC<ProjectListProps> = ({
  projects,
  currentUser,
  onSelectProject,
  onOpenCreateProject,
  onStartTimer,
  onStopTimer,
}) => {
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [platformFilter, setPlatformFilter] = useState<string>('all');
  const [priorityFilter, setPriorityFilter] = useState<string>('all');

  const canCreate = currentUser.role === 'ceo' || (currentUser.role === 'manager' && currentUser.managerPermissions?.canAssignProjects);

  const filteredProjects = projects.filter((p) => {
    const matchesSearch =
      p.title.toLowerCase().includes(search.toLowerCase()) ||
      p.code.toLowerCase().includes(search.toLowerCase()) ||
      p.assignedToName.toLowerCase().includes(search.toLowerCase()) ||
      p.channelName.toLowerCase().includes(search.toLowerCase());

    const matchesStatus = statusFilter === 'all' || p.status === statusFilter;
    const matchesPlatform = platformFilter === 'all' || p.platform === platformFilter;
    const matchesPriority = priorityFilter === 'all' || p.priority === priorityFilter;

    return matchesSearch && matchesStatus && matchesPlatform && matchesPriority;
  });

  return (
    <div className="space-y-6 animate-in fade-in duration-200">
      {/* Header Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h2 className="text-lg font-bold text-slate-900 dark:text-white">
              {currentUser.role === 'member' ? 'My Assigned Projects' : 'Studio Project Matrix'}
            </h2>
            <span className="font-mono text-xs px-2 py-0.5 rounded-full bg-slate-100 text-slate-600 dark:bg-slate-800 dark:text-slate-300">
              {filteredProjects.length} items
            </span>
          </div>
          <p className="text-xs text-slate-500 dark:text-slate-400">
            {currentUser.role === 'member'
              ? 'Confidential production queue assigned specifically to you'
              : 'End-to-end media production tracking across Facebook and YouTube'}
          </p>
        </div>

        {canCreate && (
          <button
            onClick={onOpenCreateProject}
            className="flex items-center gap-1.5 rounded-xl bg-blue-600 px-4 py-2.5 text-xs font-semibold text-white hover:bg-blue-700 shadow-md shadow-blue-600/25 transition-all self-start sm:self-auto"
          >
            <Plus className="h-4 w-4" />
            <span>Create & Assign Project</span>
          </button>
        )}
      </div>

      {/* Filter and Search Bar */}
      <div className="p-4 rounded-2xl glass-card border border-slate-200/80 dark:border-slate-800 space-y-3">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
          {/* Search */}
          <div className="relative">
            <Search className="absolute left-3 top-2.5 h-4 w-4 text-slate-400" />
            <input
              type="text"
              placeholder="Search code, title, assignee..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="w-full rounded-xl border border-slate-200/80 bg-white pl-9 pr-3 py-2 text-xs text-slate-900 placeholder:text-slate-400 focus:border-blue-500 focus:outline-hidden dark:border-slate-700 dark:bg-slate-800 dark:text-white"
            />
          </div>

          {/* Status Filter */}
          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            className="rounded-xl border border-slate-200/80 bg-white px-3 py-2 text-xs text-slate-700 focus:border-blue-500 focus:outline-hidden dark:border-slate-700 dark:bg-slate-800 dark:text-slate-300"
          >
            <option value="all">All Statuses</option>
            <option value="Assigned">Assigned</option>
            <option value="In Progress">In Progress</option>
            <option value="Waiting for Review">Waiting for Review</option>
            <option value="Revision Required">Revision Required</option>
            <option value="Completed">Completed</option>
            <option value="Overdue">Overdue</option>
          </select>

          {/* Platform Filter */}
          <select
            value={platformFilter}
            onChange={(e) => setPlatformFilter(e.target.value)}
            className="rounded-xl border border-slate-200/80 bg-white px-3 py-2 text-xs text-slate-700 focus:border-blue-500 focus:outline-hidden dark:border-slate-700 dark:bg-slate-800 dark:text-slate-300"
          >
            <option value="all">All Platforms</option>
            <option value="YouTube">YouTube</option>
            <option value="Facebook">Facebook</option>
          </select>

          {/* Priority Filter */}
          <select
            value={priorityFilter}
            onChange={(e) => setPriorityFilter(e.target.value)}
            className="rounded-xl border border-slate-200/80 bg-white px-3 py-2 text-xs text-slate-700 focus:border-blue-500 focus:outline-hidden dark:border-slate-700 dark:bg-slate-800 dark:text-slate-300"
          >
            <option value="all">All Priorities</option>
            <option value="Urgent">Urgent</option>
            <option value="High">High</option>
            <option value="Medium">Medium</option>
            <option value="Low">Low</option>
          </select>
        </div>
      </div>

      {/* Projects Table / Card List */}
      <div className="rounded-2xl glass-card border border-slate-200/80 dark:border-slate-800 overflow-hidden shadow-xs">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse">
            <thead>
              <tr className="border-b border-slate-200/70 bg-slate-50/70 dark:border-slate-800 dark:bg-slate-800/40 text-slate-400 font-semibold tracking-wider uppercase text-[10px]">
                <th className="py-3 px-4">Code / Title</th>
                <th className="py-3 px-4">Platform & Channel</th>
                <th className="py-3 px-4">Assignee</th>
                <th className="py-3 px-4">Production Stage</th>
                <th className="py-3 px-4">Time Tracker</th>
                <th className="py-3 px-4">Deadline</th>
                <th className="py-3 px-4">Status</th>
                <th className="py-3 px-4 text-right">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800/60 font-medium">
              {filteredProjects.length === 0 ? (
                <tr>
                  <td colSpan={8} className="py-12 text-center text-slate-400">
                    No video projects match the selected criteria.
                  </td>
                </tr>
              ) : (
                filteredProjects.map((p) => (
                  <tr
                    key={p.id}
                    onClick={() => onSelectProject(p.id)}
                    className="hover:bg-blue-50/40 dark:hover:bg-blue-950/20 transition-colors cursor-pointer"
                  >
                    {/* Code & Title */}
                    <td className="py-3.5 px-4 max-w-xs">
                      <div className="flex items-center gap-2 mb-0.5">
                        <span className="font-mono text-xs font-bold text-blue-600 dark:text-blue-400">
                          {p.code}
                        </span>
                        <span
                          className={`text-[9px] font-bold px-1.5 py-0.5 rounded-sm uppercase ${
                            p.priority === 'Urgent'
                              ? 'bg-red-100 text-red-700 dark:bg-red-900/40 dark:text-red-300'
                              : p.priority === 'High'
                              ? 'bg-amber-100 text-amber-700 dark:bg-amber-900/40 dark:text-amber-300'
                              : 'bg-slate-100 text-slate-600 dark:bg-slate-800 dark:text-slate-300'
                          }`}
                        >
                          {p.priority}
                        </span>
                      </div>
                      <div className="font-semibold text-slate-900 dark:text-white line-clamp-1">
                        {p.title}
                      </div>
                    </td>

                    {/* Platform & Channel */}
                    <td className="py-3.5 px-4">
                      <div className="text-slate-900 dark:text-slate-200 font-medium">
                        {p.channelName}
                      </div>
                      <div className="text-[11px] text-slate-400">
                        {p.platform} · {p.category}
                      </div>
                    </td>

                    {/* Assignee */}
                    <td className="py-3.5 px-4">
                      <div className="flex items-center gap-2">
                        <div className="flex h-6 w-6 items-center justify-center rounded-full bg-slate-100 text-slate-700 dark:bg-slate-800 dark:text-slate-300 font-bold text-[10px]">
                          {p.assignedToName.charAt(0)}
                        </div>
                        <span className="text-slate-800 dark:text-slate-200">
                          {p.assignedToName}
                        </span>
                      </div>
                    </td>

                    {/* Stage */}
                    <td className="py-3.5 px-4">
                      <div className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-slate-100 text-slate-700 dark:bg-slate-800 dark:text-slate-200 text-xs font-medium">
                        <span className="h-1.5 w-1.5 rounded-full bg-blue-500" />
                        <span>{p.currentStage}</span>
                      </div>
                    </td>

                    {/* Time Tracker Column */}
                    <td className="py-3.5 px-4" onClick={(e) => e.stopPropagation()}>
                      {p.status === 'In Progress' && onStartTimer && onStopTimer ? (
                        <div className="flex items-center gap-2">
                          <ProjectTimerWidget
                            project={p}
                            currentUser={currentUser}
                            onStartTimer={onStartTimer}
                            onStopTimer={onStopTimer}
                            compact={true}
                          />
                          {p.timeSpentSeconds && !p.activeTimerStartedAt ? (
                            <span className="font-mono text-[11px] text-slate-400 tabular-nums">
                              {formatSecondsToDuration(p.timeSpentSeconds)}
                            </span>
                          ) : null}
                        </div>
                      ) : (
                        <div className="flex items-center gap-1 text-[11px] font-mono text-slate-400 tabular-nums">
                          <Clock className="h-3 w-3 text-slate-400" />
                          <span>{formatSecondsToDuration(p.timeSpentSeconds || 0)}</span>
                        </div>
                      )}
                    </td>

                    {/* Deadline */}
                    <td className="py-3.5 px-4 font-mono text-[11px] text-slate-500 dark:text-slate-400 tabular-nums">
                      {p.deadline}
                    </td>

                    {/* Status */}
                    <td className="py-3.5 px-4">
                      <span
                        className={`inline-block text-[10px] font-bold px-2 py-0.5 rounded-full ${
                          p.status === 'Completed'
                            ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950/60 dark:text-emerald-300'
                            : p.status === 'Waiting for Review'
                            ? 'bg-amber-100 text-amber-800 dark:bg-amber-950/60 dark:text-amber-300'
                            : p.status === 'Revision Required'
                            ? 'bg-rose-100 text-rose-800 dark:bg-rose-950/60 dark:text-rose-300'
                            : p.status === 'Overdue'
                            ? 'bg-red-500 text-white shadow-xs'
                            : 'bg-blue-100 text-blue-800 dark:bg-blue-950/60 dark:text-blue-300'
                        }`}
                      >
                        {p.status}
                      </span>
                    </td>

                    {/* Action */}
                    <td className="py-3.5 px-4 text-right">
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          onSelectProject(p.id);
                        }}
                        className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg border border-slate-200 hover:bg-slate-100 dark:border-slate-700 dark:hover:bg-slate-800 text-slate-700 dark:text-slate-300 font-semibold"
                      >
                        <span>Open</span>
                        <ChevronRight className="h-3 w-3" />
                      </button>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
