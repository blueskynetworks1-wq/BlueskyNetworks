import React, { useState } from 'react';
import {
  X,
  Copy,
  Check,
  Clock,
  Calendar,
  ExternalLink,
  Send,
  CheckCircle2,
  AlertTriangle,
  RotateCcw,
  Trash2,
  Tv,
  Film,
  FileText,
  Award,
} from 'lucide-react';
import { Project, User, ProductionStage } from '../../types';

import { ProjectTimerWidget, formatSecondsToDuration } from '../common/ProjectTimerWidget';

interface ProjectDetailModalProps {
  project: Project | null;
  currentUser: User;
  onClose: () => void;
  onUpdateStage: (projectId: string, stage: ProductionStage, notes: string) => void;
  onSubmitProject: (projectId: string, link: string, notes: string) => void;
  onReviewProject: (projectId: string, decision: 'approve' | 'revise', feedback: string) => void;
  onDeleteProject?: (projectId: string) => void;
  onStartTimer?: (projectId: string) => void;
  onStopTimer?: (projectId: string, notes?: string) => void;
}

const STAGES: ProductionStage[] = [
  'Research',
  'Script Writing',
  'Prompt Creation',
  'Video Generation',
  'Editing',
  'Review',
  'Final Export',
  'Submitted',
  'Completed',
];

export const ProjectDetailModal: React.FC<ProjectDetailModalProps> = ({
  project,
  currentUser,
  onClose,
  onUpdateStage,
  onSubmitProject,
  onReviewProject,
  onDeleteProject,
  onStartTimer,
  onStopTimer,
}) => {
  if (!project) return null;

  const [copiedPrompt, setCopiedPrompt] = useState(false);
  const [selectedStage, setSelectedStage] = useState<ProductionStage>(project.currentStage);
  const [stageNotes, setStageNotes] = useState('');

  // Submission state
  const [submissionLink, setSubmissionLink] = useState(project.finalSubmissionLink || '');
  const [submissionNotes, setSubmissionNotes] = useState(project.submissionNotes || '');

  // Review state
  const [reviewFeedback, setReviewFeedback] = useState('');
  const [activeActionTab, setActiveActionTab] = useState<'stage' | 'submit' | 'review'>('stage');

  const isAssignedMember = currentUser.id === project.assignedToId;
  const isCeo = currentUser.role === 'ceo';
  const isManager = currentUser.role === 'manager';
  const canReview = isCeo || (isManager && currentUser.managerPermissions?.canReviewSubmissions);

  const handleCopyPrompt = () => {
    navigator.clipboard.writeText(project.videoPrompt);
    setCopiedPrompt(true);
    setTimeout(() => setCopiedPrompt(false), 2000);
  };

  const handleStageSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onUpdateStage(project.id, selectedStage, stageNotes);
    setStageNotes('');
  };

  const handleDeliverySubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!submissionLink.trim()) return;
    onSubmitProject(project.id, submissionLink, submissionNotes);
  };

  const handleReviewAction = (decision: 'approve' | 'revise') => {
    if (decision === 'revise' && !reviewFeedback.trim()) {
      alert('Please provide feedback explaining the requested changes.');
      return;
    }
    onReviewProject(project.id, decision, reviewFeedback);
    setReviewFeedback('');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/60 backdrop-blur-md animate-in fade-in duration-150 overflow-y-auto">
      <div className="w-full max-w-3xl rounded-2xl border border-slate-200/90 bg-white/95 shadow-2xl backdrop-blur-2xl dark:border-slate-800 dark:bg-slate-900/95 overflow-hidden my-auto max-h-[90vh] flex flex-col">
        {/* Modal Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-200/80 dark:border-slate-800/80 shrink-0">
          <div className="flex items-center gap-3">
            <span className="font-mono text-xs font-bold text-blue-600 dark:text-blue-400 bg-blue-50 dark:bg-blue-950/60 px-2.5 py-1 rounded-lg border border-blue-200 dark:border-blue-900">
              {project.code}
            </span>
            <div>
              <h2 className="text-base font-bold text-slate-900 dark:text-white line-clamp-1">
                {project.title}
              </h2>
              <div className="text-xs text-slate-500 dark:text-slate-400 flex items-center gap-2">
                <span>{project.channelName}</span>
                <span>·</span>
                <span>Assigned to <strong className="text-slate-800 dark:text-slate-200">{project.assignedToName}</strong></span>
              </div>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {isCeo && onDeleteProject && (
              <button
                onClick={() => {
                  if (confirm(`Are you sure you want to delete project ${project.code}?`)) {
                    onDeleteProject(project.id);
                    onClose();
                  }
                }}
                className="p-1.5 rounded-lg text-slate-400 hover:text-red-500 hover:bg-red-50 dark:hover:bg-red-950/40 transition-colors"
                title="Delete Project"
              >
                <Trash2 className="h-4 w-4" />
              </button>
            )}
            <button
              onClick={onClose}
              className="p-1.5 rounded-lg text-slate-400 hover:text-slate-700 hover:bg-slate-100 dark:hover:bg-slate-800 dark:hover:text-slate-200"
            >
              <X className="h-4 w-4" />
            </button>
          </div>
        </div>

        {/* Modal Scrollable Body */}
        <div className="flex-1 overflow-y-auto p-6 space-y-6">
          {/* Metadata Grid */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
            <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200/60 dark:border-slate-800">
              <span className="text-slate-400 font-medium">Status</span>
              <div className="font-bold text-slate-900 dark:text-white mt-0.5">
                {project.status}
              </div>
            </div>

            <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200/60 dark:border-slate-800">
              <span className="text-slate-400 font-medium">Current Stage</span>
              <div className="font-bold text-blue-600 dark:text-blue-400 mt-0.5">
                {project.currentStage}
              </div>
            </div>

            <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200/60 dark:border-slate-800">
              <span className="text-slate-400 font-medium">Priority</span>
              <div className="font-bold text-amber-600 dark:text-amber-400 mt-0.5">
                {project.priority}
              </div>
            </div>

            <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200/60 dark:border-slate-800">
              <span className="text-slate-400 font-medium">Official Deadline</span>
              <div className="font-mono font-bold text-slate-900 dark:text-white mt-0.5">
                {project.deadline}
              </div>
            </div>
          </div>

          {/* Active Work Session Timer Widget */}
          {onStartTimer && onStopTimer && (
            <ProjectTimerWidget
              project={project}
              currentUser={currentUser}
              onStartTimer={onStartTimer}
              onStopTimer={onStopTimer}
              compact={false}
            />
          )}

          {/* Description */}
          <div className="space-y-1.5">
            <h4 className="text-xs font-semibold uppercase tracking-wider text-slate-400">
              Deliverable Brief
            </h4>
            <p className="text-xs leading-relaxed text-slate-700 dark:text-slate-300 bg-slate-50/70 dark:bg-slate-800/30 p-3.5 rounded-xl border border-slate-200/60 dark:border-slate-800">
              {project.description}
            </p>
          </div>

          {/* Video Prompt with 1-click Copy */}
          <div className="space-y-1.5">
            <div className="flex items-center justify-between">
              <h4 className="text-xs font-semibold uppercase tracking-wider text-slate-400">
                Official Generative Video Prompt
              </h4>
              <button
                onClick={handleCopyPrompt}
                className="flex items-center gap-1 text-xs text-blue-600 dark:text-blue-400 hover:underline"
              >
                {copiedPrompt ? <Check className="h-3.5 w-3.5 text-emerald-500" /> : <Copy className="h-3.5 w-3.5" />}
                <span>{copiedPrompt ? 'Copied Prompt' : 'Copy Prompt'}</span>
              </button>
            </div>
            <div className="relative rounded-xl border border-blue-200/60 bg-blue-50/40 p-4 font-mono text-xs text-slate-800 dark:border-blue-900/50 dark:bg-blue-950/20 dark:text-blue-200 leading-relaxed">
              {project.videoPrompt}
            </div>
          </div>

          {/* Reference Links & Deliverable Link */}
          {(project.referenceLinks.length > 0 || project.finalSubmissionLink) && (
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {project.referenceLinks.length > 0 && (
                <div className="space-y-1.5">
                  <h4 className="text-xs font-semibold uppercase tracking-wider text-slate-400">
                    Reference Links
                  </h4>
                  <div className="space-y-1">
                    {project.referenceLinks.map((link, idx) => (
                      <a
                        key={idx}
                        href={link}
                        target="_blank"
                        rel="noreferrer"
                        className="flex items-center gap-1.5 text-xs text-blue-600 dark:text-blue-400 hover:underline truncate"
                      >
                        <ExternalLink className="h-3 w-3 shrink-0" />
                        <span className="truncate">{link}</span>
                      </a>
                    ))}
                  </div>
                </div>
              )}

              {project.finalSubmissionLink && (
                <div className="space-y-1.5">
                  <h4 className="text-xs font-semibold uppercase tracking-wider text-slate-400">
                    Submitted Video Delivery
                  </h4>
                  <a
                    href={project.finalSubmissionLink}
                    target="_blank"
                    rel="noreferrer"
                    className="flex items-center gap-2 p-2.5 rounded-xl bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-900 text-xs text-emerald-800 dark:text-emerald-300 font-medium"
                  >
                    <Film className="h-4 w-4 shrink-0 text-emerald-600" />
                    <span className="truncate">{project.finalSubmissionLink}</span>
                    <ExternalLink className="h-3 w-3 ml-auto shrink-0" />
                  </a>
                  {project.submissionNotes && (
                    <p className="text-[11px] text-slate-500 italic">
                      "{project.submissionNotes}"
                    </p>
                  )}
                </div>
              )}
            </div>
          )}

          {/* Revision History (if any) */}
          {project.revisionHistory.length > 0 && (
            <div className="space-y-2">
              <h4 className="text-xs font-semibold uppercase tracking-wider text-rose-500 flex items-center gap-1.5">
                <RotateCcw className="h-3.5 w-3.5" />
                <span>Revision History ({project.revisionHistory.length})</span>
              </h4>
              <div className="space-y-2">
                {project.revisionHistory.map((rev) => (
                  <div
                    key={rev.id}
                    className="p-3 rounded-xl bg-rose-50/70 border border-rose-200/70 dark:bg-rose-950/30 dark:border-rose-900/40 text-xs space-y-1"
                  >
                    <div className="flex items-center justify-between text-[11px] text-rose-700 dark:text-rose-300 font-semibold">
                      <span>Requested by {rev.requestedBy}</span>
                      <span className="font-mono">{rev.timestamp}</span>
                    </div>
                    <p className="text-slate-800 dark:text-slate-200">{rev.feedback}</p>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Interactive Pipeline Actions (Stage Update / Submit Video / Managerial Review) */}
          <div className="rounded-2xl border border-slate-200/80 bg-slate-50/70 dark:border-slate-800 dark:bg-slate-800/40 p-4 space-y-4">
            {/* Action Tabs */}
            <div className="flex items-center gap-1 p-1 bg-slate-200/60 dark:bg-slate-800 rounded-xl text-xs">
              <button
                type="button"
                onClick={() => setActiveActionTab('stage')}
                className={`flex-1 py-1.5 px-3 rounded-lg font-medium transition-all ${
                  activeActionTab === 'stage'
                    ? 'bg-white dark:bg-slate-700 text-slate-900 dark:text-white shadow-xs'
                    : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
                }`}
              >
                Advance Stage
              </button>
              {(isAssignedMember || isCeo) && (
                <button
                  type="button"
                  onClick={() => setActiveActionTab('submit')}
                  className={`flex-1 py-1.5 px-3 rounded-lg font-medium transition-all ${
                    activeActionTab === 'submit'
                      ? 'bg-white dark:bg-slate-700 text-slate-900 dark:text-white shadow-xs'
                      : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
                  }`}
                >
                  Submit Video
                </button>
              )}
              {canReview && (
                <button
                  type="button"
                  onClick={() => setActiveActionTab('review')}
                  className={`flex-1 py-1.5 px-3 rounded-lg font-medium transition-all ${
                    activeActionTab === 'review'
                      ? 'bg-white dark:bg-slate-700 text-slate-900 dark:text-white shadow-xs'
                      : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
                  }`}
                >
                  Managerial Review
                </button>
              )}
            </div>

            {/* Tab 1: Advance Stage */}
            {activeActionTab === 'stage' && (
              <form onSubmit={handleStageSubmit} className="space-y-3">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-[11px] font-medium text-slate-500 mb-1">
                      New Production Stage
                    </label>
                    <select
                      value={selectedStage}
                      onChange={(e) => setSelectedStage(e.target.value as ProductionStage)}
                      className="w-full rounded-xl border border-slate-200 bg-white px-3 py-2 text-xs text-slate-900 focus:outline-hidden dark:border-slate-700 dark:bg-slate-800 dark:text-white"
                    >
                      {STAGES.map((s) => (
                        <option key={s} value={s}>
                          {s}
                        </option>
                      ))}
                    </select>
                  </div>
                  <div>
                    <label className="block text-[11px] font-medium text-slate-500 mb-1">
                      Stage Transition Notes
                    </label>
                    <input
                      type="text"
                      placeholder="e.g. Rough cut assembly done, sound fx added..."
                      value={stageNotes}
                      onChange={(e) => setStageNotes(e.target.value)}
                      className="w-full rounded-xl border border-slate-200 bg-white px-3 py-2 text-xs text-slate-900 focus:outline-hidden dark:border-slate-700 dark:bg-slate-800 dark:text-white"
                    />
                  </div>
                </div>
                <div className="flex justify-end">
                  <button
                    type="submit"
                    className="flex items-center gap-1.5 rounded-xl bg-blue-600 px-4 py-2 text-xs font-semibold text-white hover:bg-blue-700 transition-colors shadow-xs"
                  >
                    <span>Record Stage Update</span>
                  </button>
                </div>
              </form>
            )}

            {/* Tab 2: Submit Video */}
            {activeActionTab === 'submit' && (
              <form onSubmit={handleDeliverySubmit} className="space-y-3">
                <div>
                  <label className="block text-[11px] font-medium text-slate-500 mb-1">
                    Final Video Link (Vimeo / YouTube Review / Drive)
                  </label>
                  <input
                    type="url"
                    placeholder="https://vimeo.com/review/..."
                    value={submissionLink}
                    onChange={(e) => setSubmissionLink(e.target.value)}
                    required
                    className="w-full rounded-xl border border-slate-200 bg-white px-3 py-2 text-xs text-slate-900 focus:outline-hidden dark:border-slate-700 dark:bg-slate-800 dark:text-white"
                  />
                </div>
                <div>
                  <label className="block text-[11px] font-medium text-slate-500 mb-1">
                    Submission Notes & Render Specs
                  </label>
                  <textarea
                    rows={2}
                    placeholder="Notes for reviewer (aspect ratio, sound layers, key highlights)..."
                    value={submissionNotes}
                    onChange={(e) => setSubmissionNotes(e.target.value)}
                    className="w-full rounded-xl border border-slate-200 bg-white px-3 py-2 text-xs text-slate-900 focus:outline-hidden dark:border-slate-700 dark:bg-slate-800 dark:text-white"
                  />
                </div>
                <div className="flex justify-end">
                  <button
                    type="submit"
                    className="flex items-center gap-1.5 rounded-xl bg-emerald-600 px-4 py-2 text-xs font-semibold text-white hover:bg-emerald-700 transition-colors shadow-xs"
                  >
                    <Send className="h-3.5 w-3.5" />
                    <span>Submit for Review</span>
                  </button>
                </div>
              </form>
            )}

            {/* Tab 3: Managerial Review */}
            {activeActionTab === 'review' && (
              <div className="space-y-3">
                <div>
                  <label className="block text-[11px] font-medium text-slate-500 mb-1">
                    Review Feedback / Revision Instructions
                  </label>
                  <textarea
                    rows={2}
                    placeholder="Add specific constructive feedback or notes regarding approval..."
                    value={reviewFeedback}
                    onChange={(e) => setReviewFeedback(e.target.value)}
                    className="w-full rounded-xl border border-slate-200 bg-white px-3 py-2 text-xs text-slate-900 focus:outline-hidden dark:border-slate-700 dark:bg-slate-800 dark:text-white"
                  />
                </div>
                <div className="flex items-center justify-end gap-2">
                  <button
                    type="button"
                    onClick={() => handleReviewAction('revise')}
                    className="flex items-center gap-1.5 rounded-xl border border-rose-300 bg-rose-50 px-3.5 py-2 text-xs font-semibold text-rose-700 hover:bg-rose-100 dark:border-rose-900 dark:bg-rose-950/40 dark:text-rose-300 transition-colors"
                  >
                    <RotateCcw className="h-3.5 w-3.5" />
                    <span>Request Revisions</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => handleReviewAction('approve')}
                    className="flex items-center gap-1.5 rounded-xl bg-emerald-600 px-4 py-2 text-xs font-semibold text-white hover:bg-emerald-700 transition-colors shadow-xs"
                  >
                    <CheckCircle2 className="h-3.5 w-3.5" />
                    <span>Approve & Award Points</span>
                  </button>
                </div>
              </div>
            )}
          </div>

          {/* Timestamped Stage Progression Audit Trail */}
          <div className="space-y-2">
            <h4 className="text-xs font-semibold uppercase tracking-wider text-slate-400">
              Stage History & Audit Log ({project.stageHistory.length})
            </h4>
            <div className="space-y-2 border-l-2 border-blue-500/30 pl-4 ml-1">
              {project.stageHistory.map((item) => (
                <div key={item.id} className="text-xs space-y-0.5 relative">
                  <div className="flex items-center gap-2">
                    <span className="font-bold text-slate-900 dark:text-white">
                      {item.stage}
                    </span>
                    <span className="text-[10px] text-slate-400">by {item.updatedBy}</span>
                    <span className="text-[10px] text-slate-400 font-mono ml-auto">{item.timestamp}</span>
                  </div>
                  {item.notes && (
                    <div className="text-[11px] text-slate-500 dark:text-slate-400 italic">
                      "{item.notes}"
                    </div>
                  )}
                </div>
              ))}
            </div>
          </div>

          {/* Time Logs & Recorded Sessions */}
          {project.timeLogs && project.timeLogs.length > 0 && (
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <h4 className="text-xs font-semibold uppercase tracking-wider text-slate-400">
                  Recorded Work Sessions ({project.timeLogs.length})
                </h4>
                <span className="font-mono text-xs font-bold text-blue-600 dark:text-blue-400 tabular-nums">
                  Total: {formatSecondsToDuration(project.timeSpentSeconds || 0)}
                </span>
              </div>
              <div className="space-y-1.5 max-h-48 overflow-y-auto pr-1">
                {project.timeLogs.map((log) => (
                  <div
                    key={log.id}
                    className="flex items-center justify-between p-2.5 rounded-xl bg-slate-50 dark:bg-slate-800/40 border border-slate-100 dark:border-slate-800 text-xs"
                  >
                    <div>
                      <div className="flex items-center gap-2 mb-0.5">
                        <span className="font-bold text-slate-900 dark:text-white">
                          {log.userName}
                        </span>
                        <span className="text-[10px] text-slate-400 font-medium">
                          ({log.stageAtTime})
                        </span>
                      </div>
                      <div className="text-[11px] text-slate-500 dark:text-slate-400">
                        {log.startedAt} → {log.stoppedAt.split(' ')[1] || log.stoppedAt}
                        {log.notes && <span> · "{log.notes}"</span>}
                      </div>
                    </div>
                    <span className="font-mono font-bold text-slate-900 dark:text-white tabular-nums text-xs">
                      {formatSecondsToDuration(log.durationSeconds)}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
