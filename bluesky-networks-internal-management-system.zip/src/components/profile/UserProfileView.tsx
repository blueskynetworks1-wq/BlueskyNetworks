import React, { useState } from 'react';
import {
  User as UserIcon,
  Award,
  ShieldAlert,
  Send,
  CheckCircle2,
  Lock,
  Mail,
  Clock,
  Calendar,
  Sparkles,
} from 'lucide-react';
import { User, Project, AccountChangeRequest } from '../../types';

interface UserProfileViewProps {
  currentUser: User;
  projects: Project[];
  onRequestAccountChange: (
    userId: string,
    requestType: AccountChangeRequest['requestType'],
    requestedChanges: AccountChangeRequest['requestedChanges'],
    reason: string
  ) => void;
}

export const UserProfileView: React.FC<UserProfileViewProps> = ({
  currentUser,
  projects,
  onRequestAccountChange,
}) => {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [requestType, setRequestType] = useState<AccountChangeRequest['requestType']>('Email Change');
  const [targetField, setTargetField] = useState('email');
  const [newValue, setNewValue] = useState('');
  const [reason, setReason] = useState('');
  const [submittedFeedback, setSubmittedFeedback] = useState(false);

  const completedProjects = projects.filter((p) => p.assignedToId === currentUser.id && p.status === 'Completed');

  const handleSubmitRequest = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newValue.trim() || !reason.trim()) return;

    const oldValue = (currentUser as any)[targetField] || '';

    onRequestAccountChange(
      currentUser.id,
      requestType,
      [
        {
          field: targetField,
          oldValue,
          newValue,
        },
      ],
      reason
    );

    setSubmittedFeedback(true);
    setTimeout(() => {
      setSubmittedFeedback(false);
      setIsModalOpen(false);
      setNewValue('');
      setReason('');
    }, 2500);
  };

  return (
    <div className="space-y-6 max-w-4xl mx-auto animate-in fade-in duration-200">
      {/* Profile Header Card */}
      <div className="p-6 rounded-2xl glass-card border border-slate-200/80 dark:border-slate-800 space-y-5">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="flex items-center gap-4">
            {currentUser.avatarUrl ? (
              <img
                src={currentUser.avatarUrl}
                alt={currentUser.name}
                className="h-16 w-16 rounded-2xl object-cover ring-2 ring-blue-500/30 shadow-md"
              />
            ) : (
              <div className="flex h-16 w-16 items-center justify-center rounded-2xl bg-blue-600 text-white font-bold text-xl shadow-md">
                {currentUser.name.charAt(0)}
              </div>
            )}
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-lg font-bold text-slate-900 dark:text-white">
                  {currentUser.name}
                </h2>
                <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-blue-100 text-blue-800 dark:bg-blue-950/60 dark:text-blue-300">
                  {currentUser.role.toUpperCase()}
                </span>
              </div>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                {currentUser.jobTitle} · {currentUser.department}
              </p>
              <p className="text-[11px] text-slate-400 font-mono mt-0.5">
                @{currentUser.username} · {currentUser.email}
              </p>
            </div>
          </div>

          <button
            onClick={() => setIsModalOpen(true)}
            className="flex items-center gap-1.5 rounded-xl border border-slate-200 bg-white px-3.5 py-2 text-xs font-semibold text-slate-700 hover:bg-slate-50 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-200 transition-colors self-start sm:self-auto"
          >
            <ShieldAlert className="h-3.5 w-3.5 text-indigo-500" />
            <span>Request Account Modification</span>
          </button>
        </div>

        {/* Stats Strip */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs pt-2 border-t border-slate-100 dark:border-slate-800/80">
          <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/40">
            <span className="text-slate-400 text-[11px]">Performance Score</span>
            <div className="text-lg font-bold text-slate-900 dark:text-white tabular-nums">
              {currentUser.points} pts
            </div>
          </div>

          <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/40">
            <span className="text-slate-400 text-[11px]">On-Time Delivery</span>
            <div className="text-lg font-bold text-emerald-600 dark:text-emerald-400 tabular-nums">
              {currentUser.onTimeRate}%
            </div>
          </div>

          <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/40">
            <span className="text-slate-400 text-[11px]">Delivered Videos</span>
            <div className="text-lg font-bold text-slate-900 dark:text-white tabular-nums">
              {completedProjects.length}
            </div>
          </div>

          <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/40">
            <span className="text-slate-400 text-[11px]">Tenure</span>
            <div className="text-xs font-bold text-slate-900 dark:text-white mt-1">
              Since {currentUser.joinDate}
            </div>
          </div>
        </div>
      </div>

      {/* Security Governance Notice */}
      <div className="p-5 rounded-2xl bg-indigo-50/70 border border-indigo-200/70 dark:bg-indigo-950/20 dark:border-indigo-900/40 text-xs space-y-2">
        <div className="flex items-center gap-2 font-bold text-indigo-900 dark:text-indigo-200">
          <Lock className="h-4 w-4 text-indigo-600 dark:text-indigo-400" />
          <span>Internal Security & Credential Protection Protocol</span>
        </div>
        <p className="text-indigo-800/80 dark:text-indigo-300/80 leading-relaxed">
          To maintain confidentiality and prevent unauthorized alterations, sensitive account attributes (including email addresses, usernames, and role scopes) require Founder & CEO verification. Submitting a modification request routes the change directly into Manuja Rathnayake’s approval queue with audit logging.
        </p>
      </div>

      {/* Account Change Request Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-md animate-in fade-in duration-100">
          <div className="w-full max-w-md rounded-2xl border border-slate-200/90 bg-white p-6 shadow-2xl dark:border-slate-800 dark:bg-slate-900 text-xs">
            {submittedFeedback ? (
              <div className="text-center py-6 space-y-2">
                <CheckCircle2 className="h-10 w-10 text-emerald-500 mx-auto" />
                <h3 className="text-sm font-bold text-slate-900 dark:text-white">
                  Request Dispatched to CEO
                </h3>
                <p className="text-slate-500 dark:text-slate-400 text-xs">
                  Your modification proposal has been securely logged in the CEO approval queue. You will receive an in-app alert once reviewed.
                </p>
              </div>
            ) : (
              <form onSubmit={handleSubmitRequest} className="space-y-3.5">
                <div>
                  <h3 className="text-sm font-bold text-slate-900 dark:text-white">
                    Submit Sensitive Account Change
                  </h3>
                  <p className="text-slate-400 text-[11px]">
                    Requires review and digital sign-off by Manuja Rathnayake
                  </p>
                </div>

                <div>
                  <label className="block text-[11px] font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    Modification Type
                  </label>
                  <select
                    value={requestType}
                    onChange={(e) => {
                      const val = e.target.value as any;
                      setRequestType(val);
                      if (val === 'Email Change') setTargetField('email');
                      else if (val === 'Username Change') setTargetField('username');
                      else setTargetField('jobTitle');
                    }}
                    className="w-full rounded-xl border border-slate-200 bg-white px-3 py-2 text-xs text-slate-900 focus:outline-hidden dark:border-slate-700 dark:bg-slate-800 dark:text-white"
                  >
                    <option value="Email Change">Update Company Contact Email</option>
                    <option value="Username Change">Update System Username</option>
                    <option value="Profile Update">Update Profile Details</option>
                  </select>
                </div>

                <div>
                  <label className="block text-[11px] font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    Proposed New Value *
                  </label>
                  <input
                    type="text"
                    placeholder="Enter requested value..."
                    value={newValue}
                    onChange={(e) => setNewValue(e.target.value)}
                    required
                    className="w-full rounded-xl border border-slate-200 bg-white px-3 py-2 text-xs text-slate-900 focus:outline-hidden dark:border-slate-700 dark:bg-slate-800 dark:text-white"
                  />
                </div>

                <div>
                  <label className="block text-[11px] font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    Operational Justification / Reason *
                  </label>
                  <textarea
                    rows={3}
                    placeholder="Provide context for this account change..."
                    value={reason}
                    onChange={(e) => setReason(e.target.value)}
                    required
                    className="w-full rounded-xl border border-slate-200 bg-white px-3 py-2 text-xs text-slate-900 focus:outline-hidden dark:border-slate-700 dark:bg-slate-800 dark:text-white"
                  />
                </div>

                <div className="pt-2 border-t border-slate-100 dark:border-slate-800 flex items-center justify-end gap-2">
                  <button
                    type="button"
                    onClick={() => setIsModalOpen(false)}
                    className="rounded-xl border border-slate-200 px-3.5 py-2 text-slate-600 hover:bg-slate-100 dark:border-slate-700 dark:text-slate-300"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="flex items-center gap-1.5 rounded-xl bg-blue-600 px-4 py-2 font-semibold text-white hover:bg-blue-700 shadow-xs"
                  >
                    <Send className="h-3.5 w-3.5" />
                    <span>Submit to CEO</span>
                  </button>
                </div>
              </form>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
