import React, { useState } from 'react';
import {
  Lock,
  User as UserIcon,
  X,
  ShieldCheck,
  AlertCircle,
  KeyRound,
  CheckCircle2,
  Sparkles,
} from 'lucide-react';
import { User } from '../../types';

interface LoginModalProps {
  isOpen: boolean;
  onClose: () => void;
  users: User[];
  onLoginSuccess: (userId: string) => void;
  onRequestPasswordReset: (username: string) => void;
}

export const LoginModal: React.FC<LoginModalProps> = ({
  isOpen,
  onClose,
  users,
  onLoginSuccess,
  onRequestPasswordReset,
}) => {
  if (!isOpen) return null;

  const [usernameOrEmail, setUsernameOrEmail] = useState('');
  const [password, setPassword] = useState('');
  const [failedAttempts, setFailedAttempts] = useState(0);
  const [errorMsg, setErrorMsg] = useState('');
  const [isLocked, setIsLocked] = useState(false);
  const [showForgot, setShowForgot] = useState(false);
  const [forgotUsername, setForgotUsername] = useState('');
  const [forgotSubmitted, setForgotSubmitted] = useState(false);

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (isLocked) return;

    const term = usernameOrEmail.trim().toLowerCase();
    const matchedUser = users.find(
      (u) =>
        u.username.toLowerCase() === term ||
        u.email.toLowerCase() === term
    );

    if (!matchedUser) {
      const attempts = failedAttempts + 1;
      setFailedAttempts(attempts);
      if (attempts >= 5) {
        setIsLocked(true);
        setErrorMsg('Security lockout triggered: 5 failed attempts. Account locked.');
      } else {
        setErrorMsg(`Invalid credentials. Attempt ${attempts} of 5 before temporary lockout.`);
      }
      return;
    }

    if (matchedUser.status === 'suspended') {
      setErrorMsg('This account is suspended. Contact CEO Manuja Rathnayake.');
      return;
    }

    // Authentic demo password verification:
    // Any password with length >= 4 is accepted in simulation, but passwords are never stored in plaintext
    if (password.length < 4) {
      setErrorMsg('Password must be at least 4 characters.');
      return;
    }

    onLoginSuccess(matchedUser.id);
    onClose();
  };

  const handleForgotSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!forgotUsername.trim()) return;
    onRequestPasswordReset(forgotUsername);
    setForgotSubmitted(true);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-md animate-in fade-in duration-100">
      <div className="w-full max-w-md rounded-2xl border border-slate-200/90 bg-white p-6 shadow-2xl dark:border-slate-800 dark:bg-slate-900">
        <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800">
          <div className="flex items-center gap-2">
            <div className="flex h-7 w-7 items-center justify-center rounded-lg bg-blue-600 text-white font-bold text-xs">
              BS
            </div>
            <div>
              <h3 className="text-sm font-bold text-slate-900 dark:text-white">
                Secure Terminal Login
              </h3>
              <p className="text-[11px] text-slate-400">Bluesky Networks Internal Portal</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-slate-600 dark:hover:text-slate-200"
          >
            <X className="h-4 w-4" />
          </button>
        </div>

        {errorMsg && (
          <div className="mt-4 p-3 rounded-xl bg-rose-50 border border-rose-200 text-rose-700 dark:bg-rose-950/40 dark:border-rose-900 dark:text-rose-300 text-xs flex items-center gap-2">
            <AlertCircle className="h-4 w-4 shrink-0" />
            <span>{errorMsg}</span>
          </div>
        )}

        {!showForgot ? (
          <form onSubmit={handleLogin} className="mt-4 space-y-3.5 text-xs">
            <div>
              <label className="block text-[11px] font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Username or Company Email
              </label>
              <input
                type="text"
                placeholder="e.g. manuja or kaveen"
                value={usernameOrEmail}
                onChange={(e) => setUsernameOrEmail(e.target.value)}
                disabled={isLocked}
                required
                className="w-full rounded-xl border border-slate-200 bg-white px-3 py-2 text-xs text-slate-900 focus:outline-hidden dark:border-slate-700 dark:bg-slate-800 dark:text-white"
              />
            </div>

            <div>
              <div className="flex items-center justify-between mb-1">
                <label className="text-[11px] font-semibold text-slate-700 dark:text-slate-300">
                  Password
                </label>
                <button
                  type="button"
                  onClick={() => setShowForgot(true)}
                  className="text-[11px] text-blue-600 dark:text-blue-400 hover:underline"
                >
                  Forgot?
                </button>
              </div>
              <input
                type="password"
                placeholder="••••••••"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                disabled={isLocked}
                required
                className="w-full rounded-xl border border-slate-200 bg-white px-3 py-2 text-xs text-slate-900 focus:outline-hidden dark:border-slate-700 dark:bg-slate-800 dark:text-white font-mono"
              />
            </div>

            <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/40 border border-slate-100 dark:border-slate-800 text-[11px] text-slate-500 dark:text-slate-400 space-y-1">
              <div className="font-semibold text-slate-700 dark:text-slate-300 flex items-center gap-1.5">
                <ShieldCheck className="h-3.5 w-3.5 text-emerald-500" />
                <span>Zero Plain-Text Policy</span>
              </div>
              <p>Passwords are never rendered in dashboards. 5 failed attempts locks session.</p>
            </div>

            <button
              type="submit"
              disabled={isLocked}
              className="w-full rounded-xl bg-blue-600 py-2.5 font-semibold text-white hover:bg-blue-700 disabled:opacity-40 shadow-xs transition-colors"
            >
              Authenticate Session
            </button>
          </form>
        ) : (
          <div className="mt-4 space-y-3 text-xs">
            {forgotSubmitted ? (
              <div className="p-4 rounded-xl bg-emerald-50 dark:bg-emerald-950/40 text-emerald-800 dark:text-emerald-300 text-center space-y-2">
                <CheckCircle2 className="h-8 w-8 text-emerald-500 mx-auto" />
                <div className="font-bold">Reset Request Dispatched</div>
                <p className="text-[11px]">
                  Your password reset request has been securely queued in the CEO Approvals Console. CEO Manuja will generate a single-use token.
                </p>
                <button
                  onClick={() => {
                    setShowForgot(false);
                    setForgotSubmitted(false);
                  }}
                  className="mt-2 text-xs text-blue-600 font-semibold hover:underline"
                >
                  Back to Login
                </button>
              </div>
            ) : (
              <form onSubmit={handleForgotSubmit} className="space-y-3">
                <p className="text-slate-500 text-xs">
                  Enter your username or email. A sensitive credential change request will be submitted for CEO verification.
                </p>
                <div>
                  <input
                    type="text"
                    placeholder="Enter your username or email..."
                    value={forgotUsername}
                    onChange={(e) => setForgotUsername(e.target.value)}
                    required
                    className="w-full rounded-xl border border-slate-200 bg-white px-3 py-2 text-xs text-slate-900 focus:outline-hidden dark:border-slate-700 dark:bg-slate-800 dark:text-white"
                  />
                </div>
                <div className="flex items-center justify-between pt-2">
                  <button
                    type="button"
                    onClick={() => setShowForgot(false)}
                    className="text-xs text-slate-500 hover:text-slate-700"
                  >
                    Back
                  </button>
                  <button
                    type="submit"
                    className="rounded-xl bg-blue-600 px-4 py-2 font-semibold text-white hover:bg-blue-700"
                  >
                    Submit Reset Request
                  </button>
                </div>
              </form>
            )}
          </div>
        )}
      </div>
    </div>
  );
};
